from setuptools import setup

# Configuration is in setup.cfg
setup()