S3Sync.py - Aggregated Live Feed routine v1.0.0
----------------------------------------------------------------

The S3Sync.py Python script is an Aggregated Live Feed wrapper routine
designed to synchronize Local file system content with Amazon's S3 storage
services. S3Sync leverages the 's3cmd.py' script from S3tools.org to
manage content transfer to and from S3 while adding the ability to log
activity and provide easy configuration. S3Sync also limits unnecessary
interactions with S3 by scanning local content for changes before invoking
transfer logic. This allows you to run S3Sync as often as needed without
incurring needless cost from Amazon administration overhead.

Use the accompanying 'S3Sync.cfg' configuration file to alter default
behavior and to specify content to synchronize.

Setup a schedlued task to launch script as often as needed. Using Lock file
logic, S3Sync will terminate without performing any action if it detects
that another instance of the same S3Sync routine is still running.

Storage Layout:
---------------

<Home>
|   ALFlib.py      (can be stored elsewhere, see import_path option in configuration file)
|   s3cmd.py       (can be stored elsewhere, see import_path option in configuration file)
|   S3Sync.cfg
|   S3Sync.py
\---Logs           (can be stored elsewhere, see log_path option in configuration file)
    |   S3Sync_<YYYYMM>.txt        (Summary of activity for month)
    |   S3Sync_LastRun.txt                  (Details for Last Run)
    \---S3Sync_Errors
            <YYYYMMDD_HHMI>.txt               (Details for Run if error detected)
            <YYYYMMDD_HHMI>_activity.txt      (Details for Run when keep_activity enabled)

Process Workflow:
-----------------

- Read (or create) 'S3Sync.cfg' file, apply options
- Setup/Manage Logging, handled by 'ALFlib.py'
- Import s3cmd and other components
- Looping through each synchroization section within configuration file
  - When local content transfer to S3 is detected, script scans local file system
    for changes, skipping sync process if no updates are found. If updates
    are found, script notes the change as (waiting for lull), at which time
    the next run will actually perform a sync if no additional updates are found.
  - Invoke s3cmd routines to transfer requested content
  - Update configuration file with details of lastest tranfer
  - Process next section

Command-line usage:
-------------------

Simply enter 'S3Sync.py' or 'python S3Sync.py' from a command-line console to launch.

Tested on:
----------

- Windows
- Unix (Ubuntu)

Depenancies:
------------

- ALFlib.py v1.1.0+ helper script available from:
  http://www.arcgis.com/home/item.html?id=b01b18bbf0e34338b6a2c71609ea1373
- Properly configured and Functioning s3cmd v1.0.1 script install, available from:
  http://s3tools.org/s3cmd
- s3cmd.py v1.0.2 patch (included with S3Sync!)
- Python v2.6+
