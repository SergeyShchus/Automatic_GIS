
################################################################################
# ALFdeployer.py - Aggregated Live Feed content Deployer                       #
#                                                                              #
# Originally designed to synchronize multiple File Geodatabase folders with    #
# content from Zipped archives located on a remote data store, to write over   #
# an in-use or 'Live' File Geodatabase.                                        #
#                                                                              #
# Version 2 can synchronize any specified file and expand/extract its content  #
# if needed. It also has the ability to clear the REST cache for, restart, or  #
# refresh active ArcGIS Server services.                                       #
#                                                                              #
# Created by: Paul Dodd - esri, Software Product Release Team                  #
#    Contact: pdodd@esri.com                                                   #
#                                                                              #
#      Build: 2.2.1, April 2018                                                #
#          - Patched 'refreshService' logic to correct an intermittent issue.  #
#                                                                              #
#      Build: 2.2.0, February 2018                                             #
#          - Config Version 4                                                  #
#          - Updated to honor KeepActivity log setting, dropping logs when no  #
#            updates available.                                                #
#          - Added 'refresh_service' option to Configuration File. Service is  #
#            'refreshed' if STARTED, otherwise it is Started Automatically!    #
#          - Added 'extract_area' option to Configuration File.                #
#          - Altered specification of Service Type. Now optional, will start/  #
#            stop/restart/refresh or clear cache for all services that match   #
#            specified service name regardless of service type.                #
#                                                                              #
#      Build: 2.1.0, December 2016                                             #
#          - Config Version 3                                                  #
#          - Updated ALFlib version depenancy to v2.3.0                        #
#          - Updated default ArcGIS Server connection string to:               #
#            'https://localhost:6443/arcgis'                                   #
#          - Updated to support dynamic network detail substitution for        #
#            connections, cache, and service options.                          #
#          - Updated to support HTTP fallback for SSL token authentication.    #
#          - Enhanced SSL support for Python v2.7.9+ with ssl.SSLContext       #
#          - Added 'source_ssl_context' option to Configuration File.          #
#          - Added 'ags_ssl_context' option to Configuration File.             #
#          - Added 'post_process_command' option to Configuration File.        #
#          - Added 'process_timeout' option to Configuration File.             #
#                                                                              #
#      Build: 2.0.0, April 2015                                                #
#          - Config Version 2                                                  #
#          - Added 'version' option to Configuration File, to identify version #
#            of configuration file. Triggers automatic config file upgrade     #
#            when version differs from current version support by script.      #
#          - Added 'workers' option to Configuration File, to support new      #
#            Multiprocessing capability.                                       #
#          - Added 'do_not_extract' option to Configuration File.              #
#          - Added 'no_intermediate' option to Configuration File.             #
#          - Added 'do_not_keep' option to Configuration File.                 #
#          - Added 'scrub_destination' option to Configuration File.           #
#          - Added 'stop_service' option to Configuration File.                #
#          - Added 'start_service' option to Configuration File.               #
#          - Updated 'source', 'destination', and 'work_area' options to allow #
#            values relative to Default when absolute path not specified.      #
#                                                                              #
#      Build: 1.1.0, May 2013, internal release only, requires ALFlib v1.6.0+  #
#          - Updated to handle Ordered Processing of Configuration file.       #
#          - Added 'download_timeout' option.                                  #
#          - Added ArcGIS Server administration support by leveraging new      #
#            AGSadmin library.                                                 #
#          - Added support for clearing rest cache.                            #
#          - Added 'clear_rest_cache' option to Configuration File.            #
#          - Added support for restarting services.                            #
#          - Added 'restart_service' option to Configuration File.             #
#          - Updated Unzip and Copy Live routines to allow extraction of all   #
#            content, not just FileGDBs. By leveraging new ALFlib routines.    #
#          - Updated logError function to handle logging issues to error log   #
#            if log failure detected.                                          #
#                                                                              #
#      Build: 1.0.1, October 2012                                              #
#          - Patched Path resolution logic to resolve mixed separators in ALL  #
#            paths.                                                            #
#          - Added console message when 7Zip unavailable.                      #
#                                                                              #
#      Build: 1.0.0, September 2012                                            #
#          - Initial Release                                                   #
#                                                                              #
# Depends on: Python v2.6+, ALFlib.py v1.6+                                    #
################################################################################

#########################
# Import base libraries #
#########################

import datetime, fnmatch, os, shutil, ssl, subprocess, sys, time, zipfile
import cookielib, json, platform, socket, urllib, urllib2
import ConfigParser as configparser
from urllib2 import URLError

# Setup initial variables

version = "v2.2.1"
creation = "Apr 2018"
agsDefault = "https://localhost:6443/arcgis" # Default ArcGIS Server for Clear Rest Cache option
home, scriptName = os.path.split( os.path.realpath(__file__))
showUsage = False

# Initially use Script name to identify Configuration file
configName = scriptName

# Check for input Argument
if len(sys.argv) > 1:
    showUsage = True
    if sys.argv[1].startswith("-"):
        if not sys.argv[1].lower() == "-h":
            print( "\n\a * Invalid option '{0}' *".format( sys.argv[1]))
    elif not sys.argv[1].lower().endswith( ".cfg"):
        print( "\n\a * Invalid <configFile> extension '{0}' *".format( sys.argv[1]))
    else:
        showUsage = False

        # Use Argument 1 to define Configuration file to use
        home, configName = os.path.split( os.path.realpath( sys.argv[1]))

        # Navigate to config file location as root starting point
        if os.access( home, os.F_OK):
            os.chdir( home)
        else:
            print( " * Specified Config file path is NOT accessible...")

# Setup usage

verText = "{0}, {1}, {2}, Paul Dodd - esri".format( scriptName, version, creation)

usage = """
{0}
{1}

File Geodatabase archive download and deployment tool.

Usage: {2} [-h | <configFile>]

              -h = Show this usage.
    <configFile> = Configuration file path and/or name + '.cfg' extension.
                   New file is generated if not found or specified.
                   Default is the name of this script + '.cfg'
""".format( verText, "-" * len( verText), scriptName)

if showUsage:
    print( usage)
    sys.exit()

# Setup Config File verbage

verText = "{0}, {1}".format( scriptName, version)
headerComments = """
###################################################
# Configuration for: {0}{1}#
#                                                 #
# Use to synchronize local Data Sets with content #
# from a Remote Data Store. Source can be a file  #
# or an archive containing a folder of content.   #
###################################################

""".format( verText, " " * ( 51 - len( verText) - 22))

footerComments = \
"""#######################################################################################
# Add or modify sections above to control what content will be Synchronized.          #
# Any section name other than 'DEFAULT' will initiate a sync operation.               #
#                                                                                     #
# Settings found in 'DEFAULT' section will apply to all sections.                     #
# Settings found in other sections override default settings for that section.        #
#                                                                                     #
# Uniquely name each section by including text between brackets. Add desired          #
# 'options' as needed. Ex:                                                            #
#                                                                                     #
# [Local data source]                                                                 #
# source = D:\MyTestData\FGDB_Data.zip                # Windows - Explicit path       #
# source = MyTestData\FGDB_Data.zip                   # Windows - Relative path       #
# source = /usr/data/FGDB_Data.zip                    # Unix    - Explicit path       #
# source = data/FGDB_Data.zip                         # Unix    - Relative path       #
# <option> = <value>                                                                  #
# <option> = <value>                                                                  #
#                                                                                     #
# [Remote data source]                                                                #
# source = \\\\MyServer\\TestShare\\FGDB_Data.zip         #   UNC path                    #
# source = http://my.server.com/data/FGDB_Data.zip    #  HTTP path                    #
# source = https://my.server.com/data/FGDB_Data.zip   # HTTPS path                    #
# source = ftp://my.server.com/data/FGDB_Data.zip     #   FTP path                    #
# <option> = <value>                                                                  #
# <option> = <value>                                                                  #
#                                                                                     #
# Available options for DEFAULT section (ignored by other sections):                  #
# ----------------------------------------------------------------------------------- #
#          nickname = (optional) Name of process, recorded in log files and general   #
#                     feedback.                                                       #
#                                                                                     #
#                     Default: name of script less file extension.                    #
#                                                                                     #
#     log_retention = (optional) Number of log file months to keep on-hand.           #
#                                                                                     #
#                     Default: 3.                                                     #
#                                                                                     #
#          log_path = (optional) File system path where log files will be stored.     #
#                                                                                     #
#                     Default: 'Logs', relative to location of script.                #
#                                                                                     #
#       import_path = (optional) Additional file system path to aid search for        #
#                     'ALFlib.py' and other common routines.                          #
#                                                                                     #
#                     Default search path is the location of script, followed by      #
#                     Python 'sys.path' folder list.                                  #
#                                                                                     #
#     sync_interval = (optional) Update cycle time in minutes. A value other than 0   #
#                     (Zero), execution will repeat using a timed cycle.              #
#                                                                                     #
#                     Default: 0 (off, one cycle then exit). Supports fractional      #
#                     minutes. Ex: '2.5'                                              #
#                                                                                     #
#    ags_connection = (optional) If there is a need to interact with ArcGIS Server,   #
#    * Added v1.1.0 * use this option to specify admin connection details for one or  #
#                     more ArcGIS servers. Then, use the <clear_rest_cache> and/or    #
#                     <restart_service> options to schedule these actions for one or  #
#                     more services. Supports a comma separated list of connection    #
#                     details that include: '<site>|<username>|<password>'            #
#                     <site>: (optional) ArcGIS Server site URL.                      #
#                             Ex: 'http://my.server.domain/arcgis'                    #
#                             Default: '{0}'                #
#                     <username>: Username of ArcGIS Server administrator             #
#                     <password>: Password matching 'username'                        #
#                                                                                     #
#   * v2.1.0 Update * Now supports dynamic substitution of a mask value for that of a #
#                     network detail. Include any of the following masks within a     #
#                     connection string to replace text at run time with the          #
#                     appropriate local machine's network detail value:               #
#                     '{1}localName{2}' = Machine's Local DNS name                        #
#                     '{1}localAddr{2}' = Machine's Local IP Address                      #
#                     '{1}externalName{2}' = Machine's External DNS Name                  #
#                     '{1}externalAddr{2}' = Machine's External IP Address                #
#                     Ex: 'http://{1}localAddr{2}:6080/arcgis'                            #
#                     * Also supported by Cache and Service functions *               #
#                     * SSL connection issues will fallback to http when connection   #
#                     specified as http, even when token support uses an SSL endpoint #
#                     for authentication *                                            #
#                                                                                     #
#                     Default: blank or empty string (no connection)                  #
#                                                                                     #
#   ags_ssl_context = (optional) One or more pipe '|' separated strings that evaluate #
#    * Added v2.1.0 * to valid Python 'ssl.SSLContext' Objects. The order of each     #
#                     string should match that of the above <ags_connection> entries. #
#                     This can include multiple pipe '|' values in order to line up   #
#                     with connections. Used to support SSL security access to ArcGIS #
#                     Server.                                                         #
#                                                                                     #
#                     Ignored for Python v2.7.8 and below.                            #
#                     Default for Python v2.7.12 and below:                           #
#                             'ssl.SSLContext( ssl.PROTOCOL_SSLv23)'                  #
#                     Default for Python v2.7.13 and above:                           #
#                             'ssl.SSLContext( ssl.PROTOCOL_TLS)'                     #
#                                                                                     #
#                     For details and additional options, please see:                 #
#                     * https://docs.python.org/library/ssl.html#ssl.SSLContext *     #
#                                                                                     #
#                     Ex: 'ssl.SSLContext( ssl.PROTOCOL_TLSv1_2)'                     #
#                                                                                     #
#           workers = (optional) Number of 'worker' processes to create, to handle    #
#    * Added v2.0.0 * processing sections asynchronously.                             #
#                                                                                     #
#                     Default: 1, use a single synchronous process.                   #
#                                                                                     #
#           version = (optional) Defines the Configuration File format version.       #
#    * Added v2.0.0 * Supports automatic config file upgrade process.                 #
#                                                                                     #
#                     * CAUTION * Automatically managed, please do not alter!         #
#                                                                                     #
# Available options for ALL sections:                                                 #
# ----------------------------------------------------------------------------------- #
#               source = (required) String containing file path to synchronize.       #
#                        A file, or file archive (Zip) containing a folder of         #
#                        contents. Like a File Geodatabase...                         #
#                                                                                     #
#                        For non-DEFAULT sections, value can be relative to the       #
#                        DEFAULT section value.                                       #
#                                                                                     #
#   source_ssl_context = (optional) String that will evaluate to a valid Python       #
#       * Added v2.1.0 * 'ssl.SSLContext' Object used for SSL security access to      #
#                        <source> endpoint.                                           #
#                                                                                     #
#                        Ignored for Python v2.7.8 and below.                         #
#                        Default for Python v2.7.12 and below:                        #
#                                'ssl.SSLContext( ssl.PROTOCOL_SSLv23)'               #
#                        Default for Python v2.7.13 and above:                        #
#                                'ssl.SSLContext( ssl.PROTOCOL_TLS)'                  #
#                                                                                     #
#                        For details and additional options, please see:              #
#                        * https://docs.python.org/library/ssl.html#ssl.SSLContext *  #
#                                                                                     #
#                        Ex: 'ssl.SSLContext( ssl.PROTOCOL_TLSv1_2)'                  #
#                                                                                     #
#          destination = (optional) String containing Relative, Absolute, or UNC file #
#                        system path where content will be synchronized to.           #
#                                                                                     #
#                        For non-DEFAULT sections, value can be relative to the       #
#                        DEFAULT section value.                                       #
#                                                                                     #
#                        Default: 'Live', relative to location of script.             #
#                                                                                     #
#            work_area = (optional) File system path where downloaded files will be   #
#                        stored.                                                      #
#                                                                                     #
#                        For non-DEFAULT sections, value can be relative to the       #
#                        DEFAULT section value.                                       #
#                                                                                     #
#                        Default: 'Work', relative to location of script.             #
#                                                                                     #
#         extract_area = (optional) File system path where archive files will be      #
#       * Added v2.2.0 * unpacked.                                                    #
#                                                                                     #
#                        For non-DEFAULT sections, value can be relative to the       #
#                        DEFAULT section value.                                       #
#                                                                                     #
#                        Default: Same location as 'work_area' option.                #
#                                                                                     #
# post_process_command = (optional) Command line command text used to execute custom  #
#       * Added v2.1.0 * process after data download, expansion, and copy has been    #
#                        completed. Execution is launched prior to any other service  #
#                        action. Can be used to perform additional operation on data  #
#                        before it should be used. The ALFdeployer will execute the   #
#                        command after setting the current directory to the           #
#                        <destination> folder.                                        #
#                                                                                     #
#                        Ex: 'Python ../MyPostCommand.py' execute a script.           #
#                        Ex: 'chmod 777 *' alter permission for all files.            #
#                                                                                     #
#      process_timeout = (optional) Number of seconds to wait for                     #
#       * Added v2.1.0 * <post_process_command> to run before issuing a timeout       #
#                        condition, skipping section.                                 #
#                                                                                     #
#                        Default: 300.                                                #
#                                                                                     #
#          do_not_sync = (optional) True or False. Setting this to True will skip the #
#                        sync process for a given section.                            #
#                                                                                     #
#                        Default: False.                                              #
#                                                                                     #
#       do_not_extract = (optional) True or False. Setting this to True will skip the #
#       * Added v2.0.0 * Archive File expansion/extract process, leaving the          #
#                        downloaded file as it was received.                          #
#                                                                                     #
#                        Default: False.                                              #
#                                                                                     #
#      no_intermediate = (optional) True or False. Setting this to True will skip the #
#       * Added v2.0.0 * use of the intermediate <work_area> for:                     #
#                        a) If <do_not_extract> is False, archive file downloads will #
#                           be expanded/extracted directly to the <destination>       #
#                           location. Eliminating the need to perform the             #
#                           intermediate copy process.                                #
#                        b) If <do_not_extract> is True, files will be downloaded     #
#                           directly to <destination> location. Eliminating the       #
#                           <work_area> use altogether.                               #
#                                                                                     #
#                        Default: False.                                              #
#                                                                                     #
#                        * WARNING * NOT Recommended for updating IN-USE File         #
#                                    Geodatabase folders!                             #
#                                                                                     #
#          do_not_keep = (optional) True or False. Setting this to True will discard  #
#       * Added v2.0.0 * downloaded file after final processing, but only when NOT    #
#                        downloading directly to <destination>.                       #
#                                                                                     #
#                        Default: False.                                              #
#                                                                                     #
#                        * CAUTION * Setting to True will cause subsequent runs to    #
#                                    download file again regardless of source age!    #
#                                                                                     #
#    scrub_destination = (optional) True or False. Setting this to True will discard  #
#       * Added v2.0.0 * ALL content in the <destination> location under the          #
#                        following conditions:                                        #
#                                                                                     #
#                        For DEFAULT section, content will be discarded prior to      #
#                        processing other SECTIONS and only after any DEFAULT         #
#                        <stop_service> actions are processed.                        #
#                                                                                     #
#                        For Non-DEFAULT sections, discard action will be:            #
#                        a) IGNORED when the options <no_intermediate> and            #
#                           <do_not_extract> are both True. Because file downloads    #
#                           will go directly to <destination>.                        #
#                        b) Performed immediately following a successful download and #
#                           after any <stop_service> actions are processed. No need   #
#                           to scrub if nothing has changed.                          #
#                                                                                     #
#                        Default: False.                                              #
#                                                                                     #
#                        * WARNING * NOT Recommended for updating IN-USE File         #
#                                    Geodatabase folders!                             #
#                                                                                     #
#       unzip_password = (optional) Password used to extract files from Archive.      #
#                                                                                     #
#                        Default is blank (no password).                              #
#                                                                                     #
#     download_timeout = (optional) Number of seconds to wait for data transfer       #
#       * Added v1.1.0 * before issuing a timeout condition, skipping section.        #
#                                                                                     #
#                        Default: 300.                                                #
#                                                                                     #
#     clear_rest_cache = (optional) Comma separated list containing the optional      #
#       * Added v1.1.0 * <ags_connection> reference; and pipe symbol '|' + the        #
#                        optional Service Folder, or Service Folder, Service name,    #
#                        and optional Service Type to clear cache on.                 #
#                                                                                     #
#                        Ex: <ags_connection ref>                                     #
#                        Ex: <ags_connection ref>|<folder>                            #
#                        Ex: <ags_connection ref>|<folder/service/>                   #
#                        Ex: <ags_connection ref>|<folder/service/type>               #
#                        Ex: <folder>                                                 #
#                        Ex: <folder/service/>                                        #
#                        Ex: <folder/service/type>                                    #
#                                                                                     #
#                        (optional) <ags_connection ref> is any unique partof the     #
#                        <ags_connection> site URL used to define the connection.     #
#                        Like 'localhost' or 'my.server'.                             #
#                        Default connection will be the <ags_connection> if only one  #
#                        connection specified, or it will be 'localhost' if more than #
#                        one or no connection has been specified.                     #
#                                                                                     #
#                        (optional) <folder/service/type> is the folder name or the   #
#                        folder name, service name and optional service type.         #
#                        Like:                                                        #
#                        - 'MyData/MyService/MapServer' for the 'MyData' folder,      #
#                          'MyService' service, and 'MapServer' for the service type. #
#                        - '/MyService/GpServer' for the Root folder, 'MyService'     #
#                          service, and 'GpServer' for the service type.              #
#                        - '/MyService/' for the Root folder, 'MyService' service,    #
#                          and NO specific service type to act on (any available).    #
#                        - Or just '/' for the Root folder.                           #
#                                                                                     #
#                        - If no pipe symbol and no forward slash is found, item is   #
#                        compared to ags_connections, if not found, it is assumed to  #
#                        be a Service Folder.                                         #
#                                                                                     #
#                        - If only an <ags_connection> reference included: The entire #
#                        site cache will be cleared!                                  #
#                                                                                     #
#                        - If no service name and type included: The entire folder    #
#                        cache will be cleared!                                       #
#                                                                                     #
#                        For DEFAULT section, specified items will have their REST    #
#                        caches cleared when at least one source has been updated.    #
#                        The clear cache action is triggered immediately after        #
#                        processing the last source.                                  #
#                                                                                     #
#                        For Non-DEFAULT sections, specified items will have their    #
#                        REST caches cleared when the source is updated and           #
#                        processing is complete.                                      #
#                                                                                     #
#                        Default: blank or empty string.                              #
#                                                                                     #
#      refresh_service = (optional) Comma separated list containing the optional      #
#       * Added v2.2.0 * <ags_connection> reference; pipe symbol '|' + the optional   #
#                        details for which service(s) to refresh.                     #
#                                                                                     #
#                        See <clear_rest_cache> for allowed values.                   #
#                                                                                     #
#                        Leverages: '../System/PublishingTools/GPServer' service.     #
#                        Requires: 'hasLiveData' property on service set to 'true'.   #
#                        Service is Started if in a Stopped state!                    #
#                                                                                     #
#                        Default: blank or empty string.                              #
#                                                                                     #
#                        * NOTE * Only available for ArcGIS Server 10.3 or newer!     #
#                                 Initial support for Image Services ONLY at 10.3!    #
#                                 Initial support for 'Specific Service' ONLY!        #
#                                                                                     #
#      restart_service = (optional) Comma separated list containing the optional      #
#       * Added v1.1.0 * <ags_connection> reference; pipe symbol '|' + the optional   #
#                        details for which service(s) to restart.                     #
#                                                                                     #
#                        See <clear_rest_cache> for allowed values.                   #
#                                                                                     #
#                        Default: blank or empty string.                              #
#                                                                                     #
#                        * NOTE * Only available for ArcGIS Server 10.1 or newer!     #
#                                 Initial support for 'Specific Service' ONLY!        #
#                                                                                     #
#         stop_service = (optional) Comma separated list containing the optional      #
#       * Added v2.0.0 * <ags_connection> reference; pipe symbol '|' + the optional   #
#                        details for which service(s) to stop.                        #
#                                                                                     #
#                        See <clear_rest_cache> for allowed values.                   #
#                                                                                     #
#                        For DEFAULT section, services will be stopped prior to       #
#                        processing other SECTIONS.                                   #
#                                                                                     #
#                        For Non-DEFAULT sections, stop action will be:               #
#                        a) Performed prior to download attempt when the options      #
#                           <no_intermediate> and <do_not_extract> are both True.     #
#                           Because file downloads will go directly to <destination>. #
#                        b) Performed immediately following a successful download and #
#                           before the <scrub_destination> action. No need to stop a  #
#                           service if nothing has changed!                           #
#                                                                                     #
#                        Default: blank or empty string.                              #
#                                                                                     #
#                        * NOTE * Only available for ArcGIS Server 10.1 or newer!     #
#                                 Initial support for 'Specific Service' ONLY!        #
#                                                                                     #
#        start_service = (optional) Comma separated list containing the optional      #
#       * Added v2.0.0 * <ags_connection> reference; pipe symbol '|' + the optional   #
#                        details for which service(s) to start.                       #
#                                                                                     #
#                        See <clear_rest_cache> for allowed values.                   #
#                                                                                     #
#                        For DEFAULT section, services will be started after          #
#                        processing all other SECTIONS.                               #
#                                                                                     #
#                        For Non-DEFAULT sections, start action will be:              #
#                        a) Performed after processing when the options               #
#                           <no_intermediate> and <do_not_extract> are both True.     #
#                           Because file downloads had to go directly to              #
#                           <destination>.                                            #
#                        b) Performed after processing a successful download. No need #
#                           to start a service if nothing has changed!                #
#                                                                                     #
#                        Default: blank or empty string.                              #
#                                                                                     #
#                        * NOTE * Only available for ArcGIS Server 10.1 or newer!     #
#                                 Initial support for 'Specific Service' ONLY!        #
#                                                                                     #
#######################################################################################
""".format( agsDefault, "{", "}")

############################################
# Setup config file definition and options #
############################################

configFilename = os.path.realpath( os.path.splitext( configName)[0] + '.cfg')
errLogFilename = os.path.realpath( os.path.splitext( configName)[0] + '.err')
ConfigFile = configparser.SafeConfigParser()

# OPTIONS, list of all accepted options
# <option name>: [ <is this a section default option (True or False)>, <default value>, <get function>, <format function>, <is required>]

options = {
    'version': [False, 'orig', ConfigFile.get, None, False],
    'nickname': [False, configName.split( '.')[0], ConfigFile.get, None, False],
    'log_retention': [False, 3, ConfigFile.getint, None, False],
    'log_path': [False, 'Logs', ConfigFile.get, os.path.realpath, False],
    'import_path': [False, '', ConfigFile.get, os.path.realpath, False],
    'do_not_sync': [True, False, ConfigFile.getboolean, None, False],
    'do_not_extract': [True, False, ConfigFile.getboolean, None, False],
    'no_intermediate': [True, False, ConfigFile.getboolean, None, False],
    'do_not_keep': [True, False, ConfigFile.getboolean, None, False],
    'scrub_destination': [False, False, ConfigFile.getboolean, None, False],
    'unzip_password': [True, '', ConfigFile.get, None, False],
    'sync_interval': [False, 0, ConfigFile.getfloat, None, False],
    'work_area': [True, 'Work', ConfigFile.get, None, True],
    'extract_area': [True, '', ConfigFile.get, None, False],
    'source': [True, '', ConfigFile.get, None, True],
    'source_ssl_context': [True, '', ConfigFile.get, None, False],
    'destination': [True, 'Live', ConfigFile.get, None, True],
    'ags_connection': [False, '', ConfigFile.get, None, False],
    'ags_ssl_context': [False, '', ConfigFile.get, None, False],
    'clear_rest_cache': [False, '', ConfigFile.get, None, False],
    'stop_service': [False, '', ConfigFile.get, None, False],
    'start_service': [False, '', ConfigFile.get, None, False],
    'restart_service': [False, '', ConfigFile.get, None, False],
    'refresh_service': [False, '', ConfigFile.get, None, False],
    'download_timeout': [True, 300, ConfigFile.getint, None, False],
    'process_timeout': [True, 300, ConfigFile.getint, None, False],
    'workers': [False, 1, ConfigFile.getint, None, False],
    'post_process_command': [True, '', ConfigFile.get, None, False],
}
configVersion = "v4"    # Based on the changes to the 'options' above, what
                        # should the current version of the configuration file be?

# Get Option

def getOption( option, section="DEFAULT", checkRequired=False):
    global haveRequired

    sectionDefault, defaultValue, getFunc, formatFunc, required = options[ option]

    try:
        value = getFunc( section, option)
    except:
        # Set as default if not present
        value = defaultValue

    if formatFunc and callable( formatFunc):
        # Format value if function provided
        try:
            value = formatFunc( value)
        except:
            pass

    if not sectionDefault:
        # Remove item if not a Section Default item
        ConfigFile.remove_option( section, option)

    if checkRequired:
        if not value:
            logError( " * Required option '{0}' cannot be empty! *".format( option))
            haveRequired = False

    return value

# Set Defaults in ConfigFile

def setDefaults():
    for option, value in options.iteritems():
        if not ConfigFile.has_option( "DEFAULT", option):
            ConfigFile.set( "DEFAULT", option, str(value[1]))

# Config Option save routine

def createConfig( upgrade=False):
    if upgrade:
        print( "\n * Detected an old configuration file, upgrading...")
    else:
        # Config file does not exist, create it!
        logError( "\n * Missing configuration file, generating initial file at:\n '{0}'\n".format( configFilename))

    setDefaults()

    oFP = open( configFilename, 'wb')
    if headerComments:
        oFP.write( headerComments)

    ConfigFile.write( oFP)

    if footerComments:
        oFP.write( footerComments)
    oFP.close()

    if not upgrade:
        print( "Done!")
        sys.exit()

# Validate Config Option routine

def validateConfig( section):
    for option, value in ConfigFile.items( section):
        if option in options:
            sectionDefault, defaultValue, getFunc, formatFunc, required = options[ option]

            # Validate option
            try:
                testValue = getFunc( section, option)
            except:
                if not value == '':
                    logError( " * Failed to validate Option: '{0}' in Section: '{1}'.\n   Using default value *".format( option, section))
                if section == "DEFAULT":
                    # Override user default setting with option default
                    ConfigFile.set( section, option, str( defaultValue))
                else:
                    # Remove user section setting, fallback to default if available
                    ConfigFile.remove_option( section, option)
        else:
            logError( " * Ignoring invalid Option: '{0}' in Section: '{1}' *".format( option, section))
            ConfigFile.remove_option( section, option)

#############################
# Multiprocessing functions #
#############################

def initializeWorker( connections):   # Optional, can also include arguments!
    # Called by Pool worker process during process initialization
    # Initialize process-specific environment
    global agsConnections, ALFlib, ALFlog, outcome

    import ALFlib
    outcome = ""

    def archive( message, echo=False):
        global outcome
        sep = ""
        if outcome:
            sep = "\n"
        outcome += "{0}{1}".format( sep, message)

    ALFlog = ALFlib.dummyLogger()
    # Override archive function, record locally to 'outcome', so callback can handle it!
    ALFlog.archive = archive

    if connections:
        print( "\nSetting AGS connection details...")

    agsConnections = connections

def processItem( section, sectionOptions):
    # Called by Pool worker process for each item in work queue
    global outcome

    outcome = ""
    totErrors, totSkipped, totChanges, totUpdated = 0, 0, 0, 0

    print( "\nProcessing: '{0}'".format( section))

    try:
        results = processSection( section, sectionOptions)
        totErrors += results[0]
        totSkipped += results[1]
        totChanges += results[2]
        totUpdated += results[3]

    except URLError as e:
        print( "   {0}".format( e))
        if hasattr( e, 'reason') and e.reason[0] == 11001:
            print( "   <Server not found - Check URL!>")
        outcome += "    Error: '{0}', see log...".format( section)
        totErrors += 1

    except Exception as e:
        print( " * Encountered exception: {0}".format( e))
        outcome += "    Error: '{0}', see log...".format( section)
        totErrors += 1
        totUpdated = 0

    # return Tuple of arguments for Callback (if required)
    return (totErrors, totSkipped, totChanges, totUpdated, outcome)

def callback( errors, skipped, changes, updated, outcome):     # Optional when 'callback' specified on apply_async method
    # Called by main process thread after each item is processed
    # The only item details accessible will be the arguments passed in here
    global totErrors, totSkipped, totChanges, totUpdated

    totErrors += errors
    totSkipped += skipped
    totChanges += changes
    totUpdated += updated

    if outcome:
        ALFlog.archive( outcome)
        ALFlog.log( outcome)

#####################
# General Functions #
#####################

def logError( message, showError=True):
    # Record Errors to Non-ALFlib Log file when ALFlog not available!

    error = None

    try:
        if showError:
            print( message)

    except Exception as e:
        error = e

    try:
        if 'ALFlog' not in globals() or error:
            with open( errLogFilename, 'ab') as oFP:
                oFP.write( "{0} : {1}\n".format( datetime.datetime.now().strftime( "%c"), message))
                if error:
                    oFP.write( "{0} : Showing error above through Error: {1}\n".format( datetime.datetime.now().strftime( "%c"), error))

    except Exception as e:
        print( " * Failed to write Error Log:\n   '{0}' *".format( e))

def waitInterval( startCycle, intervalMinutes):
    # Wait for interval time to elapse

    td = datetime.datetime.now() - (startCycle - datetime.timedelta( microseconds=startCycle.microsecond))  # Compute elapsed time less microseconds
    interval = float( intervalMinutes) * 60                                                                 # Convert interval minutes to seconds
    seconds = float((td.days * 86400) + td.seconds) / interval                                              # Compute seconds as ratio of interval
    waitSeconds = int( interval - ((seconds - int( seconds)) * interval))                                   # Compute remaining seconds to next interval

    message = ""

    while (waitSeconds > 0):
        message = "Next cycle in {0} seconds...".format( waitSeconds)
        sys.stdout.write( message + " \r")
        try:
            sys.stdout.flush()
        except:
            pass

        if (waitSeconds - 10) > 10:
            delay = 10
        elif waitSeconds > 10:
            delay = waitSeconds - 10
        else:
            delay = 1

        time.sleep( delay)
        waitSeconds -= delay

    # Clear last message text
    if message:
        sys.stdout.write( " " * len( message) + "\r")
        try:
            sys.stdout.flush()
        except:
            pass

def checkRealPaths( default, section):
    # Test default and section paths to see if same or relative to one another
    # Returning a joined 'real' path for web or file system.

    if not default or default == section:
        # Paths are the same, return
        return section

    if ":\\" in section or "://" in section or section.startswith( "//") or section.startswith( "\\\\"):
        # Already a real path
        return section

    if "://" in default or ":\\\\" in default:
        # Web address?
        #return os.path.relpath( os.path.join( default, section)).replace( "\\", "/").replace( ":/", "://")
        return os.path.join( default, section).replace( "\\", "/").replace( "//", "/").replace( ":/", "://")

    # Assume File path
    return os.path.realpath( os.path.join( default, section))

def substitute( string, dictMasks):
    # Substitue content for mask in value, if present
    if isinstance( dictMasks, dict) and isinstance( string, basestring):
        for mask, value in dictMasks.iteritems():
            mask = "{" + mask + "}"
            if mask in string:
                string = string.replace( mask, value)

    return string

def setupEnvironment():
    # Setup working environment based on configuration read.

    global ConfigFile, configVersion, workers
    global defaultSource, defaultDestination, defaultWorkArea, defaultExtractArea, defaultClearRestCacheList, defaultScrubDestination
    global defaultRestartServiceList, defaultStopServiceList, defaultStartServiceList, defaultRefreshServiceList
    global nickName, logRetention, logPath, importPath, syncInterval, agsConnections, downloadTimeout

    if os.access( configFilename, os.F_OK):
        # Clean out Default section
        for option in ConfigFile.defaults().keys():
            ConfigFile.remove_option( "DEFAULT", option)

        # Clean out other sections
        for section in ConfigFile.sections():
            ConfigFile.remove_section( section)

        # Load current configuration
        ConfigFile.read( configFilename)

        # Check for Defaults
        if len(ConfigFile.defaults()) == 0:
            logError( " * Config is Missing 'DEFAULT' section or content, using default values *")

        setDefaults()

        validateConfig( "DEFAULT")

        # Configuration File check, save, and upgrade if file version differs from current
        configFileVersion = getOption( 'version')
        if not configFileVersion == configVersion:
            # Discrepency in file versions, time to upgrade!
            # Save old...
            saveFile = "_{0}".format( configFileVersion).join( os.path.splitext( configFilename))
            if os.access( saveFile, os.F_OK):
                saveMsg = "   Saved old config to file: '{0}'...".format( saveFile)
                shutil.copy2( configFilename, saveFile)
            else:
                saveMsg = "   Renamed old config file to: '{0}'...".format( saveFile)
                os.rename( configFilename, saveFile)

            # Upgrade version details
            ConfigFile.set( "DEFAULT", "version", configVersion)

            # Re-create file...
            createConfig( True)
            print( "{0}\n   * Note * User-specified comments were NOT carried forward!".format( saveMsg))

        # Set working variables
        nickName = getOption( 'nickname')
        logRetention = getOption( 'log_retention')
        logPath = getOption( 'log_path')
        importPath = getOption( 'import_path')
        syncInterval = getOption( 'sync_interval')
        connections = getOption( 'ags_connection')
        sslContexts = getOption( 'ags_ssl_context')
        defaultSource = getOption( 'source')
        defaultDestination = getOption( 'destination')
        defaultScrubDestination = getOption( 'scrub_destination')
        defaultWorkArea = getOption( 'work_area')
        defaultExtractArea = getOption( 'extract_area')
        defaultExtractArea = defaultExtractArea if defaultExtractArea else defaultWorkArea
        defaultClearRestCacheList = getOption( 'clear_rest_cache')
        defaultStopServiceList = getOption( 'stop_service')
        defaultStartServiceList = getOption( 'start_service')
        defaultRestartServiceList = getOption( 'restart_service')
        defaultRefreshServiceList = getOption( 'refresh_service')
        downloadTimeout = getOption( 'download_timeout')
        workers = getOption( 'workers')
        nil = getOption( 'version')

        # Prep connections dictionary
        agsConnections = {}

        # Validate ArcGIS Server connection details for Clear Rest Cache option
        if connections:
            sslContexts = sslContexts.split("|")
            connections = connections.split( ",")
            sslContexts += [""] * (len( connections) - len( sslContexts))
            # Pre-Process comma separated connections
            for index, connection in enumerate( connections):
                if connection:
                    details = connection.strip("|").split( "|")

                    if len( details) < 2:
                        logError( " * Ignoring connection - Insufficient details for 'ags_connection': '{0}', requires username and password *".format( connection))
                    else:
                        # Insert default server
                        details.insert( 0, agsDefault)

                        agsConnections[ details[-3].replace( "\\", "/")] = { "username": details[-2], "password": details[-1], "sslContext": sslContexts[ index]}

        # Setup ordered list to process Sections
        ConfigFile.orderedSections = []

        with open( configFilename, "r") as iFP:
            for row in iFP.readlines():
                split = row.strip().split("[")
                if len( split) > 1 and not split[0]:
                    section = split[1].split( "]")[0]
                    if section <> "DEFAULT":
                        ConfigFile.orderedSections.append( section)

    else:
        logError( " * Missing Config file:\n   '{0}'\n   Using cached Config! *".format( configFilename))

    # Import ALFlib
    if 'ALFlib' not in globals():
        global ALFlib, ALFlog

        if importPath:
            importPath = os.path.realpath( importPath)
            if os.access( importPath, os.F_OK):
                sys.path.insert( 0, importPath)
            else:
                raise Exception( "Invalid 'import_path', please correct! *")

        try:
            import ALFlib
        except Exception as e:
            raise Exception( "Unable to locate 'ALFlib.py' in Import Path *")

        # Verify ALFlib version, need at least v1.7.0
        if not (hasattr( ALFlib, "minVersion") and ALFlib.minVersion( 2, 3, 0)):
            del ALFlib
            raise Exception( "Found incompatible version of 'ALFlib.py' script, need at least v2.3.0")

    # Setup Logging
    ALFlog = ALFlib.Logger( nickName, logPath, logRetention, singleton=True)
    if 'version' in globals():
        ALFlog.log( "Running: {0}, {1}".format( scriptName, version))

    ALFlog.log( "Library: ALFlib.py, v{0}.{1}.{2}".format( ALFlib.major, ALFlib.minor, ALFlib.bug))

#def processSection( sectionName, src, liveLocation, work, password, clearRestCacheList, restartServiceList):
def processSection( sectionName, options):
    # Handle download, unzip, and deploy steps for section
    totErrors, totSkipped, totChanges, totUpdated = 0, 0, 0, 0

    # Get Section options
    doNotExtract = options[ "do_not_extract"]
    noIntermediate = options[ "no_intermediate"]
    doNotKeep = options[ "do_not_keep"]
    unzipPassword = options[ "unzip_password"]
    workArea = options[ "work_area"]
    extractArea = options[ "extract_area"]
    source = options[ "source"]
    sslContext = options[ "source_ssl_context"]
    destination = options[ "destination"]
    scrubDestination = options.get( "scrub_destination", False)     # Not a default option for all sections
    clearRestCacheList = options.get( "clear_rest_cache", False)    # Not a default option for all sections
    stopServiceList = options.get( "stop_service", False)           # Not a default option for all sections
    startServiceList = options.get( "start_service", False)         # Not a default option for all sections
    restartServiceList = options.get( "restart_service", False)     # Not a default option for all sections
    refreshServiceList = options.get( "refresh_service", False)     # Not a default option for all sections
    downloadTimeout = options[ "download_timeout"]
    processTimeout = options[ "process_timeout"]
    postProcessCommand = options[ "post_process_command"]

    # Create Output folders if they don't already exist!
    for (folder, isDest) in [ (workArea, False), (extractArea, False), (destination, True)]:
        if folder and not os.access( folder, os.F_OK):
            os.makedirs( folder)
            if isDest:
                scrubDestination = False

    # Should we save directly to Destination!
    if noIntermediate and doNotExtract:
        print( "  Setting Download to Live folder...")
        workArea = destination
        doNotKeep = False
        scrubDestination = False

    # Get download
    if ALFlib.getDownload( source, workArea, timeout=downloadTimeout, sslContext=sslContext):
        sourceFile = os.path.join( workArea, os.path.split( source)[1])
        totChanges += 1
        zipFolder = ""
        copyFrom = ""
        copyExclude = ""
        copyRecurse = False

        # Check for Stop Service action required
        if agsConnections and stopServiceList:
            totErrors += restartService( sectionName, stopServiceList, "stop")

        # Check if Scrubbing destination required
        if scrubDestination:
            try:
                shutil.rmtree( destination)
                os.makedirs( destination)

            except Exception as e:
                print( "\n * Failed to Scrub destination folder following download: '{0}'\n".format( e))

        # Check for and start extraction
        if doNotExtract:
            # Skip extract!
            if not noIntermediate:
                # Still need to copy to Destination!
                copyFrom = sourceFile
            # Otherwise, Skip copy because we already saved directly to Destination!
        else:
            # Prep for unzip and test
            sys.stdout.write( "\n  Checking for Zip file...")
            if zipfile.is_zipfile( sourceFile):
                print( "Success")

                if noIntermediate:
                    # Skip copy, extract directly to Destination!
                    print( "  Setting Extract to Live folder...")
                    zipFolder = destination
                else:
                    zipFolder = os.path.splitext( sourceFile)[0] + ".extract"  # v2.1.0
                    zipFolder = os.path.join( extractArea, os.path.split( zipFolder)[-1])    # v2.2.0
                    copyFrom = os.path.join( zipFolder, "*")
                    copyExclude = "*.lock"
                    copyRecurse = True

                    # Check if extract path exists
                    if os.path.exists( zipFolder):
                        # Yes, delete it
                        shutil.rmtree( zipFolder)

                    # Create a clean extract location
                    os.mkdir( zipFolder)

                if not ALFlib.unzipIt( sourceFile, zipFolder, unzipPassword):
                    # Failure, skip copy and report error!
                    copyFrom = ""
                    print( " * One or more files FAILED to Unzip, processing skipped! *")
                    ALFlog.archive( "  Skipped: '{0}', error in Unzip...".format( sectionName))
                    totSkipped += 1
            else:
                print( "nothing to extract!")
                copyFrom = sourceFile

        if copyFrom:
            # Need to copy to Live location?
            print( "\n  Deploying to Live folder...")
            if ALFlib.copyFiles( copyFrom, destination, exclusions=copyExclude, overwrite=True, recurse=copyRecurse):
                ALFlog.archive( "  Updated: '{0}'".format( sectionName))
            else:
                ALFlog.archive( "    Error: '{0}', see log...".format( sectionName))
                totErrors += 1

        if doNotKeep:
            # Delete download?
            print( "\n  Discarding Download...")
            os.remove( sourceFile)

        # Custom command execution
        if postProcessCommand:
            outcome = 1
            cwd = os.getcwdu()
            try:
                os.chdir( destination)
                outcome, results = ALFlib.callCommandLine( postProcessCommand, "Post Processing Command", processTimeout)
            except Exception as e:
                print( " * Failed to call 'post_process_command', error: {0}".format( e))

            os.chdir( cwd)

            if outcome:
                print( " * Call to 'post_process_command' returned a bad outcome, error outcome: {0}".format( outcome))
                totErrors += 1

        if agsConnections and startServiceList:
            # Check for Start Servce action required
            totErrors += restartService( sectionName, startServiceList, "start")

        if not (totErrors or totSkipped):
            # No errors, mark data set as Updated!
            totUpdated += 1

            # Cleanup intermediate workspace on success
            if os.path.splitext( zipFolder)[1] == ".extract" and os.path.exists( zipFolder):
                print( "\n  Discarding Intermediate Workspace...")
                shutil.rmtree( zipFolder)

            if agsConnections:
                # Check for Clear Rest Cache directive and Reset if needed
                if clearRestCacheList:
                    totErrors += clearCache( sectionName, clearRestCacheList)

                # Check for Restart Service directive and Reset if needed
                if restartServiceList:
                    totErrors += restartService( sectionName, restartServiceList)

                # Check for Refresh Service directive and Refresh if needed
                if refreshServiceList:
                    totErrors += restartService( sectionName, refreshServiceList, "refresh")

    return (totErrors, totSkipped, totChanges, totUpdated)

def parseServiceActions( serviceList, section):
    # Parse comma separated list of  Connection|Service(s) to act on
    # Return List containing 'action', 'connection key', 'folder', 'service', 'service type', 'service endpoint'
    # Normalize slashes

    serviceList = str( serviceList).replace( "\\", "/")
    actions = []

    # Process action list
    for item in serviceList.split( ","):
        if item:
            errors = 0
            details = item.split( "|")

            action = ""
            server = ""
            folder = ""
            service = ""
            serviceType = ""
            serviceEndpoint = ""

            details[0] = details[0].strip()

            if len( details) == 1:
                if not details[0]:
                    # Empty, skip it
                    continue

                # Check for service
                if "/" in details[0]:
                    service = details[0]
                else:
                    # Nope, check for server
                    for connection in agsConnections:
                        if connection.lower().find( details[0].lower()) > -1:
                            server = connection
                            break
                    else:
                        # Assume its a folder!
                        folder = details[0]
            else:
                server = details[-2]
                # Is right side a service?
                if "/" in details[-1]:
                    service = details[-1]
                elif details[-1]:
                    # Nope, must be a folder!
                    folder = details[-1]

            # Setup Server
            if not server:
                if len( agsConnections) == 1:
                    # No Server specified, get the only one specified!
                    server = agsConnections.keys()[0]
                else:
                    server = agsDefault

            # Setup Folder, Service, and Service Type
            if service:
                details = service.split( "/")
                details.insert( 0, "")  # Pad front with empty string, for root folder
                if len( details) >= 3:
                    serviceType = details[-1]
                    service = details[-2]
                    folder = details[-3]

                    if not folder:
                        folder = "/"

                    #if service and not serviceType:    # v2.2.0 Commented out
                    #    serviceType = "MapServer"      # v2.2.0 Commented out

                if not folder:
                    action = "Malformed service definition"

            foundType = ""
            if not action:
                # Lookup server connection
                for key, value in agsConnections.items():
                    if key.lower().find( server.lower()) > -1:
                        server = key
                        # Assemble Serivce URL for display
                        serviceEndpoint = key.strip( "/") + "/rest/services"
                        if folder:
                            if folder <> "/":
                                serviceEndpoint += "/" + folder

                            if service:
                                serviceEndpoint += "/" + service + "/" + serviceType
                                action = "Service"
                            elif folder == "/":
                                action = "Root"
                            else:
                                action = "Folder"
                        else:
                            action = "Site"

                        # Check for existing connection
                        if isinstance( value, dict):
                            # Check for skip flag
                            if "skip" in value:
                                action = value[ "skip"]
                                break

                            # Need to make connection
                            try:
                                ags = AGSadmin( key, value[ "username"], value[ "password"], expiration=1)
                                # Success, save connection
                                agsConnections[ key] = ags
                                #ags.debug = True

                            except Exception as e:
                                print( "\n * Failed to establish ArcGIS Server connection: '{0}' while processing section: {1}, skipping further actions on this connection *\n   Error: {2}".format( key, section, e))
                                action = "Connection Failure"
                                agsConnections[ key][ "skip"] = action
                                errors += 1

                        # Check for valid Folder, Service Name, and Type
                        if isinstance( agsConnections[ key], AGSadmin) and ( service or folder <> "/"):
                            try:
                                # Lookup folder
                                #response = agsConnections[ key].getResponse( "services")
                                #if isinstance( response, dict) and "folders" in response:
                                if folder not in agsConnections[ key].services:
                                    action = "Folder does not exist"
                                    break

                                # Verify Service
                                for item in agsConnections[ key].services[ folder]:
                                    if isinstance( item, dict) and "serviceName" in item and "type" in item:
                                        if item[ "serviceName"].endswith( service):
                                            if serviceType:
                                                if item[ "type"] == serviceType:
                                                    # Found Specified Service and Type
                                                    break
                                            else:
                                                # Found Servie and non-specified Service Type, add to list
                                                foundType = item[ "type"]
                                                actions.append( [ action, server, folder, service, foundType, serviceEndpoint + foundType, errors])
                                else:
                                    if not foundType:   # v2.2.0 Only alert if service type not found
                                        action = "Service Name and Type does not exist or is not available"
                            except:
                                pass
                        break
                else:
                    action = "No matching connection"

            # Set results
            if not foundType:   # v2.2.0 Only add if not already found
                actions.append( [ action, server, folder, service, serviceType, serviceEndpoint, errors])

    return actions

def clearCache( section, cacheList):
    # Clear Rest Cache for items in list
    totErrors = 0

    print( "\n - Clear Rest Cache initiated...")

    for action, server, folder, service, serviceType, serviceEndpoint, errors in parseServiceActions( cacheList, section):
        totErrors += errors
        if action == "Site":
            verbage = "Entire Site..."
        elif action == "Root":
            verbage = "Root Folder..."
        elif action == "Folder":
            verbage = "Specified Folder..."
        elif action == "Service":
            verbage = "Specified Service..."
        else:
            if serviceEndpoint:
                print( " * Skipping 'clear_rest_cache' operation for endpoint: '{0}', section: {1}, reason: {2} *\n".format( serviceEndpoint, section, action))
            else:
                print( " * Skipping 'clear_rest_cache' operation for server: '{0}', service: '{1}', section: {2}, reason: {3} *\n".format( server, service, section, action))
            totErrors += 1
            continue

        try:
            print( " - Clearing Rest Cache for {0}".format( verbage))
            print( "Endpoint: {0}".format( serviceEndpoint))

            # All set, clear the cache!
            if agsConnections[ server].clearRestCache( folder, service, serviceType):
                print( "Success!\n")
            else:
                print( "Failed, see log!\n")
                totErrors += 1

        except Exception as e:
            print( "\n * Failed to clear rest cache for ArcGIS Server endpoint: '{0}', section: {1} *\n   Error: {2}".format( serviceEndpoint, section, e))
            totErrors += 1

    if totErrors:
        ALFlog.archive( "           * Failed to Clear REST Cache, see log!")
    else:
        ALFlog.archive( "           - Clear REST Cache Successful!")

    return totErrors

def restartService( section, serviceList, serviceAction="restart" or "start" or "stop" or "refresh"):
    # Stop, Start, Restart, or Refresh Service for items in list
    totErrors = 0

    actions = {
        "restart": [ "Restarting", "Restart"],
        "start": [ "Starting", "Start"],
        "stop": [ "Stopping", "Stop"],
        "refresh": [ "Refreshing", "Refresh"]
    }

    print( "\n - {0} Service initiated...".format( actions[serviceAction][1]))

    if isinstance( serviceAction, basestring):
        serviceAction = serviceAction.lower()

    if serviceAction not in actions:
        raise Exception( " * Invalid Service Action: '{0}' *".format( serviceAction))

    actions = actions[ serviceAction]

    for action, server, folder, service, serviceType, serviceEndpoint, errors in parseServiceActions( serviceList, section):
        totErrors += errors
        if action == "Site":
            action = "{0} Entire Site not yet supported!".format( actions[0])
            totErrors -= 1
        elif action in ["Root", "Folder"]:
            action = "{0} Specified Folder not yet supported!".actions[1]
            totErrors -= 1

        if server in agsConnections and isinstance( agsConnections[ server], AGSadmin) and agsConnections[ server].apiVersion < 10.1:
            action = "Unsupported by connection"
            totErrors -= 1

        if action == "Service":
            verbage = "Specified Service..."
        else:
            if serviceEndpoint:
                print( " * Skipping '{0}_service' operation for endpoint: '{1}', section: {2}, reason: {3} *\n".format( serviceAction, serviceEndpoint, section, action))
            else:
                print( " * Skipping '{0}_service' operation for server: '{1}', service: '{2}', section: {3}, reason: {4} *\n".format( serviceAction, server, service, section, action))
            totErrors += 1
            continue

        try:
            print( " - {0} a {1}".format( actions[0], verbage))
            print( "Endpoint: {0}".format( serviceEndpoint))

            # Get Current Status of Service
            status = agsConnections[ server].serviceStatus( folder, service, serviceType)

            if serviceAction == "refresh" and status == "STARTED":
                # Refresh the Service!
                sys.stdout.write( "Refreshing service...")

                result = agsConnections[ server].refreshService( folder, service, serviceType)
                if result and isinstance( result, basestring):
                    print( " * " + result + "\n")
                    result = result.startswith( "Succeeded")
                else:
                    print( "Failed, see log!\n")
                    totErrors += 1
            else:
                if serviceAction != "start" and status == "STARTED":
                    # Stop the Service if it's not already Stopped!
                    sys.stdout.write( "Stopping service...")

                    if agsConnections[ server].stopService( folder, service, serviceType):
                        print( "Success!\n")
                        status = "STOPPED"
                    else:
                        print( "Failed, see log!\n")
                        totErrors += 1

                if serviceAction != "stop" and status == "STOPPED":
                    # Now start the Service!
                    sys.stdout.write( "Starting service...")

                    if agsConnections[ server].startService( folder, service, serviceType):
                        print( "Success!\n")
                    else:
                        print( "Failed, see log!\n")
                        totErrors += 1

        except Exception as e:
            print( "\n * Failed to {0} service for ArcGIS Server endpoint: '{1}', section: {2} *\n   Error: {3}\n".format( serviceAction, serviceEndpoint, section, e))
            totErrors += 1

    if totErrors:
        ALFlog.archive( "           * Failed Service {0}, see log!".format( actions[1]))
    else:
        ALFlog.archive( "           - Service {0} Successful!".format( actions[1]))

    return totErrors

class AGSadmin( object):
    """ArcGIS Server Rest administration API v0.1.0 for Python.

Handles basic REST administration for ArcGIS versions less than 10.1 and
more advanced administration for versions greater than or equal to 10.1."""

    global traceback
    import traceback

    _name = traceback.extract_stack()[-1][-2]

    def __init__( self, siteUrl="http://localhost:6080/arcgis", username="", password="", token="", referer="", ip="", expiration=0, sslContext=None):
        """Class initialization.

Initialization can acquire initial connection when siteURL +, User/Password or Token is provided.

See 'setConnection' function for details."""
        # Initialize variables
        self.rootUrl = siteUrl
        self.adminUrl = ""
        self.tokenUrl = ""
        self.token = None
        self.expirationDate = datetime.datetime.now()
        self.expirationMinutes = 0
        self.apiVersion = 0.0
        self.username = None
        self.password = None
        self.client = None
        self.referer = None
        self.ip = None
        self.cookies = None
        self.debug = False
        self.isAdmin = False
        self.services = {}

        if siteUrl and ((username and password) or token):
            self.setConnection( siteUrl, username, password, token, referer, ip, expiration, sslContext)

    ########################
    # Check API compliance #
    ########################

    def fullySupported( self, option, admin=False, min=-9999, max=9999):
        """Test API supported level required by option and display message if out of compliance

 option: string containing name of source function requesting the test
   admin: boolean, True if Admin access required, False if not required
     min: integer containing minimum Server API version required for compliance
     max: integer containing maximum Server API version required for compliance

Return:
    True if in compliance,
    False if not
Exception thrown on failure"""

        # Is administrative access required and available?
        if admin and not self.isAdmin:
            sys.stderr.write( "\n * '{0}' option requires Administrative privileges *\n".format( option))
            return False

        # Is API Version within requirements?
        if self.apiVersion < min or self.apiVersion > max:
            sys.stderr.write( "\n * '{0}' option is not supported by current connection *\n".format( option))
            return False

        # Passed all compliance checks!
        return True

    ##########################
    # Generate Login Cookies #
    ##########################

    def generateCookies( self, username, password, adminUrl, defaultExpiration=60):
        """Generate Login Cookies using credentials.

         username: string containing name of user to be authenticated.
         password: string containing password for 'username'.
         adminUrl: string containing Url of Token generation page for request.
defaultExpiration: integer containing default number of minutes that the new token is good for.
                   Ideally, this should be set to the site's short-Lived-Token-Validity value, when available.
                   Default is 60 minutes.

Returns:
    Dictionary of { "cookies": "<cookie 'key=value;' pairs>", "expirationMinutes": <minutes>, "expirationDate": datetime object}
Exception thrown on failure"""
        me = self._name + "." + traceback.extract_stack()[-1][-2]

        sys.stderr.write( "\n * Requesting Login Cookies...")

        cookieJar = cookielib.CookieJar()
        cookieOpener = urllib2.build_opener( urllib2.HTTPCookieProcessor( cookieJar))

        data = {
            "username": username,
            "password": password,
            "redirect": adminUrl
        }

        response = cookieOpener.open( adminUrl + "/login", urllib.urlencode( data))
        status = response.getcode()
        responseText = response.read()
        response.close()

        cookies = ""
        for cookie in cookieJar:
            cookies += "{0}={1};".format( cookie.name, cookie.value)

        if cookies:
            sys.stderr.write( "Success *\n")
            sys.stderr.write( " - Cookies: '{0}'\n".format( cookies))
        else:
            # Login Failure!
            sys.stderr.write( "Failure! *\n")

            message = []
            for line in responseText.split( "\n"):
                if line.endswith( "<br/>") and line[:-5]:
                    message.append( line[:-5])
            if not message:
                message = responseText
            raise Exception( "'{0}' FAILED, Status: {1}, Response: {2}".format( me, status, message))

        if defaultExpiration:
            expiration = int( defaultExpiration)
        else:
            expiration = 60

        expirationDate = datetime.datetime.now() + datetime.timedelta( minutes=expiration)
        expirationDate -= datetime.timedelta( microseconds=expirationDate.microsecond)

        sys.stderr.write( " - Expires: {0} (~{1} minutes)\n".format( expirationDate, expiration))

        return { "cookies": cookies, "expirationMinutes": expiration, "expirationDate": expirationDate}

    ####################
    # Generate a Token #
    ####################

    def generateToken( self, username, password, tokenUrl, referer="", ip="", expiration=15):
        """Generate a new Token and Expiration date from ArcGIS Server admin/generateToken endpoint

  username: string containing name of user to be authenticated.
  password: string containing password for 'username'.
  tokenUrl: string containing Url of Token generation page for request.
   referer: string containing application Url to reference token to.
        ip: string containing IP address to associate token to.
expiration: integer containing number of minutes to keep new token valid for. Default is 15 minutes.

Returns:
    Dictionary = { token: <string>, client: <string>, referer: <string>,
                      ip: <string>, expiration: <int>, expires: <datetime>}
    or False if no token received
Exception thrown on failure"""
        me = self._name + "." + traceback.extract_stack()[-1][-2]

        # Check User and Password
        if not (username and password):
            raise Exception( "Invalid Username or Password, cannot be blank")

        if not tokenUrl:
            raise Exception( "Invalid Admin URL, cannot be blank")

        viaSSL = "https:" in tokenUrl.lower()
        sys.stderr.write( "\n * Requesting Token{0}...".format( " via SSL" if viaSSL else ""))

        # Build data based on inputs
        data = {
            "f": "json",
            "username": username,
            "password": password
        }

        # Check for Expiration time in minutes
        if expiration:
            data[ "expiration"] = expiration

        # Check for Referer string
        if referer:
            data[ "referer"] = referer
            client = "referer"
        # Check for Ip
        elif ip:
            data[ "ip"] = ip
            client = "ip"
        else:
            client = "requestip"

        data[ "client"] = client

        # Encode URL data
        data = urllib.urlencode( data)

        # Get token
        try:
            response = urllib2.urlopen( tokenUrl + "/generateToken", data)
            status = response.getcode()
            result = response.read()
            response.close()
            response = json.loads( result)

            # Initialize Token and Expiration Date
            token = None
            expirationDate = datetime.datetime.now()

            if isinstance( response, dict):
                if "token" in response:
                    token = response[ "token"]
                    sys.stderr.write( "Success *\n")

                    sys.stderr.write( " -   Token: {0}\n".format( token))
                    sys.stderr.write( " -  Client: {0}\n".format( client))

                    if client == "referer":
                        sys.stderr.write( " - Referer: {0}\n".format( referer))
                    elif client == "ip":
                        sys.stderr.write( " -      IP: {0}\n".format( ip))

                    if "expires" in response:
                        expirationDate = datetime.datetime.fromtimestamp( int( response[ "expires"]) / 1000)
                        expirationDate -= datetime.timedelta( microseconds=expirationDate.microsecond)
                        expiration = expirationDate - datetime.datetime.now()

                        expirationSeconds = 0
                        if hasattr( expiration, "days"):
                            expirationSeconds += expiration.days * 86400
                        if hasattr( expiration, "seconds"):
                            expirationSeconds += expiration.seconds
                        expiration = int( round( float( expirationSeconds) / 60, 0))    # Returning total Minutes

                        sys.stderr.write( " - Expires: {0} (~{1} minutes)\n".format( expirationDate, expiration))

                    return { "token": token, "client": client, "referer": referer, "ip": ip, "expiration": expiration, "expires": expirationDate}

                elif "error" in response:
                    raise urllib2.URLError( response[ "error"])

        except Exception as e:
            sys.stderr.write( "FAILED *\n")
            sys.stderr.write( " * Error: {0}\n".format( e))
            raise

        sys.stderr.write( "No Token received,\n     Status: {0},\n   Response: '{1}' *\n".format( status, response))

    ####################
    # Clear Rest Cache #
    ####################

    def clearRestCache( self, folderName="", serviceName="", serviceType=""):
        """Clear Rest Cache.

To clear entire Rest cache, specify no parameters.

For AGS versions >= 10.1, you may also:
To clear the Rest cache for a specific service folder, specify the 'folderName'.
To clear the Rest cache for a specific service, include the 'serviceName' and optional service 'serviceType'. Service type will default to 'MapServer' if not specified.

Return:
    True if Successful
    or False when not supported or user is not an administrator
Exception thrown on failure"""
        me = self._name + "." + traceback.extract_stack()[-1][-2]

        if not self.fullySupported( me, admin=True, min=9.3):
            return False

        if self.apiVersion < 10.1:
            if folderName or serviceName:
                sys.stderr.write( "\n * '{0}' - Ignoring specified 'folder/service' input, not supported by current connection *\n".format( me))

            response = self.getResponse( "cache/clear", data={"f": "html"})
            if isinstance( response, dict) and "html" in response:
                if response[ "html"].lower().find( "cache cleared") > -1:
                    return True
        else:
            if serviceName and not serviceType:
                serviceType = "MapServer"

            data = {
                "folderName": folderName,
                "serviceName": serviceName,
                "type": serviceType}

            response = self.getResponse( "system/handlers/rest/cache/clear", data)

            if isinstance( response, dict):
                if response.get( "status", "") == "success" or response.get( "success", ""):
                    return True

        raise Exception( "'{0}' Failed, Response: {1}".format( me, response))

    ################
    # Stop Service #
    ################

    def stopService( self, folderName="", serviceName="", serviceType=""):
        """Stop Service.

Use to stop a running service.

Returns:
    True if Successful
    or False when not supported or user is not an administrator
Exception thrown on failure"""
        me = self._name + "." + traceback.extract_stack()[-1][-2]

        if not self.fullySupported( me, admin=True, min=10.1):
            return False

        if serviceName and not serviceType:
            serviceType = "MapServer"

        if folderName == "/":
            restEndpoint = "services/{0}.{1}/stop".format( serviceName, serviceType)
        else:
            restEndpoint = "services/{0}/{1}.{2}/stop".format( folderName, serviceName, serviceType)

        response = self.getResponse( restEndpoint)

        if isinstance( response, dict):
            if response.get( "status", "") == "success" or response.get( "success", ""):
                return True

        raise Exception( "'{0}' Failed, Response: {1}".format( me, response))


    #################
    # Start Service #
    #################

    def startService( self, folderName="", serviceName="", serviceType=""):
        """Start Service.

Use to start a stopped service.

Returns:
    True if Successful
    or False when not supported or user is not an administrator
Exception thrown on failure"""
        me = self._name + "." + traceback.extract_stack()[-1][-2]

        if not self.fullySupported( me, admin=True, min=10.1):
            return False

        if serviceName and not serviceType:
            serviceType = "MapServer"

        if folderName == "/":
            restEndpoint = "services/{0}.{1}/start".format( serviceName, serviceType)
        else:
            restEndpoint = "services/{0}/{1}.{2}/start".format( folderName, serviceName, serviceType)

        response = self.getResponse( restEndpoint)

        if isinstance( response, dict):
            if response.get( "status", "") == "success" or response.get( "success", ""):
                return True

        raise Exception( "'{0}' Failed, Response: {1}".format( me, response))

    ##################
    # Status Service #
    ##################

    def serviceStatus( self, folderName="", serviceName="", serviceType=""):
        """Service Status.

Use to receive the status of a service.

Returns:
    String containing status if Successful
    or False when not supported or user is not an administrator
Exception thrown on failure"""
        me = self._name + "." + traceback.extract_stack()[-1][-2]

        if not self.fullySupported( me, admin=True, min=10.1):
            return False

        if serviceName and not serviceType:
            serviceType = "MapServer"

        if folderName == "/":
            restEndpoint = "services/{0}.{1}/status".format( serviceName, serviceType)
        else:
            restEndpoint = "services/{0}/{1}.{2}/status".format( folderName, serviceName, serviceType)

        response = self.getResponse( restEndpoint)

        if isinstance( response, dict):
            if "realTimeState" in response or "configuredState" in response:
                return response.get( "realTimeState", response.get( "configuredState", False))

        raise Exception( "'{0}' Failed, Response: {1}".format( me, response))

    ###################
    # Refresh Service #
    ###################

    def refreshService( self, folderName="", serviceName="", serviceType="", refreshOptions=""):
        """Refresh Service.

Use to Refresh Service following data updates.

Returns:
    String containing result on Success
    or False when not supported or user is not an administrator
Exception thrown on failure"""
        me = self._name + "." + traceback.extract_stack()[-1][-2]

        if not self.fullySupported( me, admin=True, min=10.3):
            return False

        if serviceName and not serviceType:
            serviceType = "ImageServer"

        if folderName == "/":
            restEndpoint = "services/{0}.{1}".format( serviceName, serviceType)
        else:
            restEndpoint = "services/{0}/{1}.{2}".format( folderName, serviceName, serviceType)

        try:
            # Check for service and properties
            response = self.getResponse( restEndpoint)

            if isinstance( response, dict):
                # Should only have a 'status' if there is an issue
                if not (response.get( "status", response.get( "success", "success")) == "success"):
                    raise Exception( response)

                if not response.get( "properties", {}).get( "hasLiveData", "") == "true":
                    raise Exception( "Required Service Property Missing, set 'hasLiveData=true' and retry!")
            else:
                raise Exception( "Failed to query service: {}".format( response))

        except Exception as e:
            raise Exception( "'{0}' Service Validation Failure, Response: {1}".format( me, e))

        data = {
            "serviceName": "{}".format( serviceName),
            "serviceType": "{}".format( serviceType)
        }
        if folderName.strip( "/"):
            data[ "serviceFolder"] = folderName
        if refreshOptions:
            data[ "refreshOptions"] = refreshOptions

        response = self.getResponse( "/rest/services/System/PublishingTools/GPServer/Refresh%20Service/submitJob", data)

        if isinstance( response, dict):
            if not ("jobId" in response and "jobStatus" in response and response[ "jobStatus"] in ["esriJobSubmitted", "esriJobExecuting"]):
                raise Exception( "'{0}' Job Submit Failure, Response: {1}".format( me, response))
        else:
            raise Exception( "'{0}' Failed, Response: {1}".format( me, response))

        jobUrl = "/rest/services/System/PublishingTools/GPServer/Refresh%20Service/jobs/{}".format( response["jobId"])

        limit = 60
        while limit:
            limit -= 1
            time.sleep( 1)
            response = self.getResponse( jobUrl)
            if isinstance( response, dict) and "jobId" in response and "jobStatus" in response:
                if response[ "jobStatus"] in ["esriJobSubmitted", "esriJobExecuting"]:
                    continue

                if response[ "jobStatus"] == "esriJobSucceeded":
                    result = "Success"
                    for message in response.get( "messages", []):
                        if "Elapsed Time" in message.get( "description", ""):
                            return message[ "description"]
                    return result

            raise Exception( "'{0}' Failed, Response: {1}".format( me, response))

        raise Exception( "'{0}' Timeout, Response: {1}".format( me, response))

    ###############################
    # Get Response to URL request #
    ###############################

    def getResponse( self, folder, data=None, useCache=True):
        """Make Web request and return response.

  folder: string containing Relative (to Admin Url location), Absolute (to Site Url), or Literal web folder or url.
          For example: 'info', 'system/handlers/...', '/rest/services/...', or 'http://www.servername.com/...'
    data: Dictionary of key and value pairs to include in request.
          For example: { "f": "html", "username": "bob", "request": "login"}
useCache: boolean, True if request should include existing connection details, False if not.
          Default is True

Return:
    On Success, a Dictionary of valid results from json response.
    On Error, a Dictionary of { "error": { "code": <error code or text>, { "message": <message text>, "details": <error details>}}"""
        me = self._name + "." + traceback.extract_stack()[-1][-2]

        def checkToken( parent):
            """Test validity of credentials and age of token, refresh if needed"""
            me = parent + ".checkToken"

            if self.username and self.password and self.expirationDate < datetime.datetime.now():
                if self.token:
                    response = self.generateToken( self.username, self.password, self.adminUrl, self.referer, self.ip, self.expirationMinutes)
                else:
                    response = self.generateCookies( self.username, self.password, self.adminUrl, self.expirationMinutes)

                if isinstance( response, dict) and "error" in response:
                    raise Exception( "'{0} - refresh' FAILED, {1}".format( me, response))

                if self.token:
                    self.cookies = ""
                    self.token = response[ "token"]
                    self.client = response[ "client"]
                    self.referer = response[ "referer"]
                    self.ip = response[ "ip"]
                    self.expirationMinutes = response[ "expiration"]
                    self.expirationDate = response[ "expires"]
                else:
                    self.cookies = response[ "cookies"]
                    self.token = ""
                    self.client = ""
                    self.referer = ""
                    self.ip = ""
                    self.expirationMinutes = response[ "expirationMinutes"]
                    self.expirationDate = response[ "expirationDate"]

        def parseHtml( response):
            """Parse HTML response and pull out 'name=value' input parameters.

response: string containing Html response text to be parsed.

Return: Dictionary of: { "html": <html response>, "params": { name: value, name: value, ...}}"""

            responseDict = { "html": response, "params": {}}
            lowerResponse = response.lower()

            lookup = {
                "name=": "name",
                "value=": "value",
                "type=": "type",
                "checked =": "checked",
                "checked=": "checked"}

            fromIndex = 0
            toIndex = -1
            while fromIndex > -1:
                fromIndex = lowerResponse.find( "<input ", toIndex + 1)
                if fromIndex > -1:
                    toIndex = lowerResponse.find( ">", fromIndex)
                    input = { "name": "", "value": "", "type": "", "checked": ""}
                    id = ""
                    for value in response[ fromIndex + 6:toIndex].replace("\'", '"').split( '"'):
                        value = value.strip()
                        if id:
                            # Save value to matching name in input
                            input[ id] = value
                            id = ""
                        elif value.lower() in lookup:
                            # Save next value to this name by id
                            id = lookup[ value.lower()]

                    # Save last index
                    fromIndex = toIndex

                    if input[ "name"] in responseDict[ "params"]:
                        # If input already in params and NOT checked, skip it!
                        if not input[ "checked"]:
                            continue

                    # Insert or Overwrite
                    if input[ "name"]:
                        responseDict[ "params"][ input[ "name"]] = input[ "value"]

            return responseDict

        #################################
        # getResponse logic starts here #
        #################################

        # Set empty 'data' parameter to empty Dict, instead of setting 'data={}' above. Otherwise,
        # the 'data' object will persist from one call to the next, giving you false options!
        if not data:
            data = {}

        # Add format
        if "F" in data:
            data[ "f"] = data[ "F"].lower()
            del data[ "F"]
        elif not "f" in data:
            # Setup data
            if self.debug:
                data["f"] = "pjson"
            else:
                data["f"] = "json"
        else:
            data["f"] = data[ "f"].lower()

        jsonRequest = data[ "f"].endswith( "json")

        # Add cache URL options from self?
        if useCache:
            # Check for expired Token or Cookie, update if so!
            if "token" not in data and (self.cookies or self.token):
                checkToken( me)
                data["token"] = self.token

            # Check for Client string
            if self.client and "client" not in data:
                data[ "client"] = self.client

            # Check for Referer string
            if self.referer and "referer" not in data:
                data[ "referer"] = self.referer

            # Check for IP
            if self.ip and "ip" not in data:
                data[ "ip"] = self.ip

            if folder.startswith( "/"):
                # Use RootURL, relative to site
                baseURL = self.rootUrl
            else:
                # Use AdminURL, relative to administration
                baseURL = self.adminUrl + "/"

            cookies = self.cookies
        else:
            baseURL = ""
            cookies = ""

        # Encode data for URL use
        data = urllib.urlencode( data)

        # Form Request
        request = urllib2.Request( baseURL + folder)

        if self.debug:
            sys.stderr.write( "\n---------\nRequest: {0}\n".format( baseURL + folder))
            sys.stderr.write( "   Data: {0}\n".format( data))

        if cookies:
            if self.debug:
                sys.stderr.write( "Cookies: {0}\n".format( cookies))

            request.add_header( "Cookie", cookies)

        # Open Url request and read response
        try:
            response = urllib2.urlopen( request, data)

        except urllib2.URLError:
            raise

        except Exception as e:
            message = { "error": { "code": e, "message": "Failed to open URL", "details": request}}
            if self.debug:
                sys.stderr.write( "\nResponse: {0}\n".format( message))
                sys.stderr.write( "---------\n")
            return message

        results = response.read()
        response.close()

        if self.debug:
            sys.stderr.write( "\nResponse: {0}\n".format( results))
            sys.stderr.write( "---------\n")

        try:
            if jsonRequest:
                return json.loads( results)
            return parseHtml( results)

        except Exception as e:
            return { "error": { "code": e, "message": "Invalid Json response", "details": results}}

    ##########################
    # Get Server Information #
    ##########################

    def getServerInfo( self):
        """Get Server specific details and Information for AGS versions >= 10.1

Return:
    Dictionary containing Server details
    or False when not supported
Exception thrown on failure"""
        me = self._name + "." + traceback.extract_stack()[-1][-2]

        if not self.fullySupported( me, admin=True, min=10.1):
            return False

        response = self.getResponse( "info")

        if isinstance( response, dict) and "currentversion" in response:
            return response

        raise Exception( "'{0}' Failed, Response: {1}".format( me, response))

    ###################
    # Get SSL Context #
    ###################

    def getContext( self, sslContext=None):
        # Return Dictionary containing SSL Context based on Python Version
        pyVer = [int(x) for x in platform.python_version().split('.')] + [0, 0] # Need a minimum of 3 values to zip with 'sslOptions'
        sslOptions = [
            [[2,7,13],'ssl.SSLContext(ssl.PROTOCOL_TLS)'],
            [[2,7,9],'ssl.SSLContext(ssl.PROTOCOL_SSLv23)']
            # Ignored for Python < v2.7.9
        ]

        # Take first sslOption where Python version is greater than or equal to specified version
        # NOTE # Use of SSLContext Object is not supported by urllib(2) until Python 2.7.9
        for ver, option in sslOptions:
            for zipper in zip( ver, pyVer):
                if zipper[0] > zipper[1]:
                    break
            else:
                supplied = "Supplied"
                if sslContext and isinstance( sslContext, basestring):
                    try:
                        sslContext = eval( sslContext)
                        supplied = "Derived"
                    except Exception as e:
                        sys.stderr.write( " * Unable to create 'ssl.SSLContext' object from Supplied string, using default!\n   Error: '{0}'\n".format( e))
                        sslContext = None

                if sslContext and not isinstance( sslContext, ssl.SSLContext):
                    sys.stderr.write( " * {0} 'sslContext' object is not of type 'ssl.SSLContext' * Using default!\n".format( supplied))
                    sslContext = None

                sys.stderr.write( " * Setting SSL Context to: '{0}'\n".format( "User {0} Object".format( supplied) if sslContext else option))
                return { "context": sslContext if sslContext else eval( option)}
        else:
            return {}

    ##########################
    # Set Connection details #
    ##########################

    def setConnection( self, siteUrl="http://localhost:6080/arcgis", username="", password="", token="", referer="", ip="", expiration=0, sslContext=None):
        """Set up connection and interrogate initial site details.

   siteUrl: string containing URL to ArcGIS Server site in the form of 'http://[<server name>.<domain> | <IP address>][:<TcpPort>]/[<instance name> | <web adapter>]'.
            Default is 'http://localhost:6080/arcgis'
  username: string containing name of user to login with. Anonymous access is used when omitted unless valid 'token' is provided.
  password: string containing password for 'username'.
     token: string containing a previously created token that is valid on this server.
   referer: string containing application URL to reference token to. Used to generate new token or to match 'token'.
        ip: string containing IP address to associate token to. Used to generate new token or to match 'token'.
expiration: integer containing number of minutes to keep new token valid for. Default is 60 (1 hour).
sslContext: 'ssl.SSLContext' Object or Python construction string that will 'eval'uate to a 'ssl.SSLContext' object.
            Supports SSL security access to https endpoint.
            For details and additional options, see: https://docs.python.org/library/ssl.html#ssl.SSLContext

* Note * When credentials are provided and a Login Token or Cookie is created, any API request made after the Login
         expiration will AUTOMATICALLY issue a request for a new Token or Cookie before issueing original request!
         This will ensure that once you've made a valid connection, your connection will stay valid!

Return:
    True if successful
    False when Unknown site
Exception thrown on failure"""
        me = self._name + "." + traceback.extract_stack()[-1][-2]

        # Get API version
        if not (username and password):
            username = ""
            password = ""

        if not siteUrl:
            siteUrl = "http://localhost:6080/arcgis"

        if not token:
            token = ""

        rootUrl = siteUrl

        sys.stderr.write( "\nInterrogating: {0}\n".format( rootUrl))

        #######################
        # Setup urllib opener #
        #######################

        # Add Cookie Jar
        cj = cookielib.CookieJar()
        authHandlers = []

        # Add Password Manager
        if username or password:
            uri = rootUrl[0:(rootUrl+"/").index("/",8)].split("//")[1]  # Specify authentication uri based on URL

            pwMgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
            pwMgr.add_password(realm=None,
                            uri=uri,
                            user=username,
                            passwd=password)

            authHandlers.append( urllib2.HTTPBasicAuthHandler( pwMgr))
            authHandlers.append( urllib2.HTTPDigestAuthHandler( pwMgr))

        # Add SSL handler
        sslContext = self.getContext( sslContext)
        if sslContext:
            authHandlers.append( urllib2.HTTPSHandler( ** sslContext))

        # Add Cookie Handler
        authHandlers.append( urllib2.HTTPCookieProcessor(cj))

        urllib2.install_opener( urllib2.build_opener( * authHandlers))

        ####################

        try:
            response = self.getResponse( rootUrl + "/rest/info", useCache=False)    # Try info for version 10.0+ without polling services!
            if isinstance( response, dict) and "error" in response:
                response = self.getResponse( rootUrl + "/rest/services", useCache=False)    # Try service directory

            if isinstance( response, dict) and "currentVersion" in response:
                apiVersion = float( response["currentVersion"])
                sys.stderr.write( "  API version: {0}\n".format( apiVersion))

                if apiVersion < 10.1:
                    adminFolder = "/rest/admin"
                else:
                    adminFolder = "/admin"

                adminUrl = rootUrl + adminFolder

                sys.stderr.write( " Admin folder: {0}\n".format( adminFolder))

                authInfo = response.get( "authInfo", {})
                tokenValidity = int( authInfo.get( "shortLivedTokenValidity", 60))
                tokenSecurity = authInfo.get( "isTokenBasedSecurity", False)

                tokenUrl = authInfo.get( "tokenServicesUrl", adminUrl)
                if not tokenUrl:    # Check if not an empty string
                    tokenUrl = adminUrl

                sys.stderr.write( "    Token URL: {0}\n".format( tokenUrl))

                # Setup other default variables
                if not expiration:
                    expiration = tokenValidity
                expirationDate = datetime.datetime.now()
                cookies = ""
                client = ""

                if not (token or username):
                    sys.stderr.write( "\n * No username/password or token given, using Anonymous user *\n")
                else:
                    # Setup connection and Log in!
                    if apiVersion < 10.0:
                        # Use Login page
                        response = self.generateCookies( username, password, tokenUrl, tokenValidity)

                        cookies = response[ "cookies"]
                        token = ""
                        client = ""
                        referer = ""
                        ip = ""
                        expirationMinutes = response[ "expirationMinutes"]
                        expirationDate = response[ "expirationDate"]
                    else:
                        if token:
                            data = {"token": token}
                            if referer:
                                data[ "referer"] = referer
                                ip = ""
                                client = "referer"
                            elif ip:
                                data[ "ip"] = ip
                                referer = ""
                                client = "ip"
                            else:
                                ip = ""
                                referer = ""
                                client = "requestip"

                            data[ "client"] = client

                            # Verify existing token
                            response = self.getResponse( adminUrl + "/system", data, useCache=False)
                        else:
                            # Use Admin 'generateToken' request
                            try:
                                response = self.generateToken( username, password, tokenUrl, referer, ip, expiration)
                            except Exception as e:
                                if tokenUrl == adminUrl:
                                    sys.stderr.write( "\n * Token Acquisition FAILED *\n")
                                    raise
                                else:
                                    try:
                                        response = self.generateToken( username, password, adminUrl, referer, ip, expiration)
                                    except Exception as e:
                                        sys.stderr.write( "\n * Token Acquisition FAILED Twice *\n")
                                        raise

                        if isinstance( response, dict) and ("error" in response or ("status" in response and response["status"] == "error")):
                            raise Exception( response)

                        cookies = ""

                        if token:
                            expiration = 0
                        else:
                            token = response[ "token"]
                            client = response[ "client"]
                            referer = response[ "referer"]
                            ip = response[ "ip"]
                            expirationMinutes = response[ "expiration"]
                            expirationDate = response[ "expires"]

                self.cookies = cookies
                self.token = token
                self.client = client
                self.referer = referer
                self.ip = ip
                self.expirationMinutes = expiration
                self.expirationDate = expirationDate
                self.apiVersion = apiVersion
                self.username = username
                self.password = password
                self.rootUrl = rootUrl
                self.adminUrl = adminUrl
                self.tokenUrl = tokenUrl
                self.isAdmin = False
                self.services = {}

                if token or cookies:
                    # Test administrative access by checking if Admin page returns a user/password login request
                    try:
                        response = self.getResponse( "", data={"f": "html"})

                        if isinstance( response, dict) and "params" in response and "password" not in response[ "params"]:
                            # Valid response and not the login page!
                            self.isAdmin = True
                        else:
                            self.isAdmin = False

                    except:
                        self.isAdmin = False

                if self.isAdmin:
                    sys.stderr.write( " -  Access: Administrative\n\n")
                    # Acquire Service list by folder!
                    response = self.getResponse( "services")
                    for folder in ["/"] + response.get( "folders", []):
                        if folder != "/":
                            response = self.getResponse( "services/" + folder)

                        if "services" in response:
                            self.services[ folder] = response[ "services"]
                else:
                    sys.stderr.write( " -  Access: General User\n\n")

                return True
            else:
                sys.stderr.write( "\n * API version unknown *\n\n")

        except Exception as e:
            sys.stderr.write( "\n * '{0}' FAILED, {1} *\n".format( me, e))
            raise

##############
# Main logic #
##############

if __name__ == "__main__":
    try:
        if not os.access( configFilename, os.F_OK):
            createConfig()

        syncInterval = 0.0

        while True:
            startCycle = datetime.datetime.now()

            totSections = 0
            totSkipped = 0
            totErrors = 0
            totUpdated = 0
            totChanges = 0

            try:
                setupEnvironment()

                # Get Machine's network details
                netDetails = ALFlib.getNetworkDetails()

                # Make substitutions
                newConnections = {}
                for key, value in agsConnections.iteritems():
                    newConnections[ substitute( key, netDetails)] = value

                agsConnections = newConnections
                defaultClearRestCacheList = substitute( defaultClearRestCacheList, netDetails)
                defaultStopServiceList = substitute( defaultStopServiceList, netDetails)
                defaultStartServiceList = substitute( defaultStartServiceList, netDetails)
                defaultRestartServiceList = substitute( defaultRestartServiceList, netDetails)
                defaultRefreshServiceList = substitute( defaultRefreshServiceList, netDetails)

                if agsConnections and defaultStopServiceList:
                    # Check for Stop Service directive and Stop services if needed
                    print( "\n * Initiating DEFAULT section 'Stop Service' option *")
                    totErrors += restartService( "DEFAULT", defaultStopServiceList, "stop")

                # Check if Scrubbing destination required
                if defaultScrubDestination:
                    try:
                        if defaultDestination and os.access( defaultDestination, os.F_OK):
                            shutil.rmtree( defaultDestination)
                        os.makedirs( defaultDestination)

                    except Exception as e:
                        print( "\n * Failed to Scrub destination folder on initialization: '{0}'\n".format( e))

                multiprocessing = (workers > 1)
                if multiprocessing:
                    # Setup worker Pool
                    pool = ALFlog.createWorkerPool( initializeWorker, args=[agsConnections], description="Deployment", processCount=workers)
                    print( "")

                # Loop through each Sync Request Section

                for section in ConfigFile.orderedSections:
                    #section in ConfigFile.sections():
                    totSections += 1

                    if multiprocessing:
                        print( "Submitting: '{0}'".format( section))
                    else:
                        print( "\n{0}\n\nProcessing: '{1}'".format( "-" * 75, section))

                    try:
                        validateConfig( section)

                        haveRequired = True    # Set by 'getOption'

                        sectionOptions = {}

                        for item, value in ConfigFile.items( section):
                            sectionDefault, defaultValue, getFunc, formatFunc, required = options[ item]
                            sectionOptions[ item] = substitute( getOption( item, section, required), netDetails)

                        # Update section paths if relative to default
                        sectionOptions[ "source"] = checkRealPaths( defaultSource, sectionOptions[ "source"])
                        sectionOptions[ "destination"] = checkRealPaths( defaultDestination, sectionOptions[ "destination"])
                        sectionOptions[ "work_area"] = checkRealPaths( defaultWorkArea, sectionOptions[ "work_area"])
                        sectionOptions[ "extract_area"] = checkRealPaths( defaultExtractArea, sectionOptions[ "extract_area"])

                        if not haveRequired:
                            print( " * Missing required options, skipping! *")
                            ALFlog.archive( "  Skipped: '{0}', missing required options...".format( section))
                            totSkipped += 1
                        elif sectionOptions[ "do_not_sync"]:
                            print( " * 'do_not_sync' detected, skipping! *")
                            ALFlog.archive( "  Skipped: '{0}', set not to sync...".format( section))
                            totSkipped += 1
                        else:
                            if multiprocessing:
                                pool.apply_async( processItem, args=[ section, sectionOptions], callback=callback) # Include a callback function to handle outcome
                            else:
                                results = processSection( section, sectionOptions)
                                totErrors += results[0]
                                totSkipped += results[1]
                                totChanges += results[2]
                                totUpdated += results[3]

                    except KeyboardInterrupt:
                        raise

                    except URLError as e:
                        print( "   {0}".format( e))
                        if hasattr( e, 'reason') and e.reason[0] == 11001:
                            print( "   <Server not found - Check URL!>")
                        ALFlog.archive( "    Error: '{0}', see log...".format( section))
                        totErrors += 1

                    except Exception as e:
                        print( " * Encountered exception: {0}".format( e))
                        ALFlog.archive( "    Error: '{0}', see log...".format( section))
                        totErrors += 1

                if multiprocessing:
                    # Close Pool to new items of work and start processing!
                    pool.close()

                    print( "\nWaiting for workers...")
                    ALFlog.waitForWorkers( timeout=downloadTimeout)

                if agsConnections:
                    if defaultStartServiceList:
                        # Check for Start Service directive and Start services if needed
                        print( "\n * Processing complete, initiating DEFAULT section 'Start Service' option *")
                        totErrors += restartService( "DEFAULT", defaultStartServiceList, "start")

                    if totUpdated:
                        # Check for Clear Rest Cache directive and Reset if needed
                        if defaultClearRestCacheList:
                            print( "\n * Updates detected, initiating DEFAULT section 'Clear Rest Cache' option *")
                            totErrors += clearCache( "DEFAULT", defaultClearRestCacheList)

                        # Check for Restart Service directive and Reset if needed
                        if defaultRestartServiceList:
                            print( "\n * Updates detected, initiating DEFAULT section 'Restart Service' option *")
                            totErrors += restartService( "DEFAULT", defaultRestartServiceList)

                        # Check for Refresh Service directive and Reset if needed
                        if defaultRefreshServiceList:
                            print( "\n * Updates detected, initiating DEFAULT section 'Refresh Service' option *")
                            totErrors += restartService( "DEFAULT", defaultRefreshServiceList)

            except KeyboardInterrupt:
                raise

            except Exception as e:
                logError( " * Encountered exception: {0}".format( e))
                totErrors += 1
                if 'ALFlog' in globals():
                    ALFlog.setError( str( e))

            if 'ALFlog' in globals():
                if (totErrors or totSkipped) and not ALFlog.getError():
                    ALFlog.setError( "Encountered {0} errors and {1} processes skipped".format( totErrors, totSkipped))
                print("")
                ALFlog.archive( "Processed: {0}, Changed: {1}, Skipped: {2}, Errors: {3} - Data Sets Updated: {4}".format( totSections, totChanges, totSkipped, totErrors, totUpdated), True)
                # Drop Log if no activity found
                if not totUpdated:
                    ALFlog.keepActivity = False
                ALFlog.close()
                del ALFlog

            if syncInterval:
                print( "\nDone...")
                waitInterval( startCycle, syncInterval)
            else:
                break

    except KeyboardInterrupt:
        if 'ALFlog' not in globals():
            logError( " * User-interrupted via <ctrl-break> *", False)
        sys.exit( " * User-interrupted via <ctrl-break> *")
