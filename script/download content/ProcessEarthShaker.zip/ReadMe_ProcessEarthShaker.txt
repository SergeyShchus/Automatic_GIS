ProcessEarthShaker.py - USGS Earthquake/Shakemap Aggregated Live Feed routine v1.0.1
------------------------------------------------------------------------------------

The ProcessEarthShaker.py Python script is an Aggregated Live Feed routine designed
to download and maintain a record of the USGS past 7 days worth of Magnitude 1+
Earthquakes and past 30 days worth of Shakemap data in a File Geodatabase. This
FileGDB can then be used by ArcGIS Mapping clients directly or it can be served using
a Map Service through ArcGIS Server. Just schedule a job to run the script once every
15 minutes and it will automatically keep your data current. The final deployment of
the live FileGDB is up to you. Just review the Configuration File and change as
required. Maybe you want to zip up the contents and push to some remote server or
upload to Amazon's S3 environment.

Use the accompanying 'ProcessEarthShaker.cfg' configuration file to alter the default
behavior or output details. Be default, the configuration is set to maintain Magnitude
3 and above Earthquakes and Shakemaps on file for 30 days. All lesser intensity events
are dropped after 3 days

Storage Layout:
---------------

<Home>
|   ALFlib.py           (can be stored elsewhere, see importPath option)
|   ProcessEarthShaker.cfg
|   ProcessEarthShaker.py
+---LiveData           (can be located anywhere, see configuration file)
|   |   Earthquakes.lyr (sample Map Layer file for Live Earthquake data)
|   |   Shakemaps.lyr     (sample Map Layer file for Live Shakemap data)
|   \---EarthShaker.gdb
|           <Geodatabase Files>
+---Logs               (can be located anywhere, see configuration file)
|   |   EarthShaker_<YYYYMM>.txt         (Summary of activity for month)
|   |   EarthShaker_LastRun.txt                   (Details for Last Run)
|   \---EarthShaker_Errors
|           <YYYYMMDD_HHMI>.txt      (Details for Run if error detected)
\---Work               (can be located anywhere, see configuration file)
    \---EarthShaker.gdb
            <Geodatabase Files>

Process Workflow:
-----------------

- Read 'ProcessEarthShaker.cfg' file, set options
- Setup/Manage Logging, handled by 'ALFlib.py'
- Import ArcPy and other components
- Check for and download Earthquake catalog
- Prepare workspace
- Write/Update data
- Check for and download Shakemap catalog, download Shakemap Shapefiles
- Prepare workspace
- Write/Update data
- Insert missing Earthquake events for any Shakemaps found
- Invoke Deployment logic found in configuration file

Command-line usage:
-------------------

Simply enter 'ProcessEarthShaker.py' from a command-line console to launch.

Depenancies:
------------

This script relies on:
- esri ArcGIS 10.0+, ArcPy
- ALFlib.py v1.3.0+ helper script
