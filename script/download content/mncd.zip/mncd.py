##################
# Cell constants #
##################
__version__ = "1.1.1"

__doc__ = """Manage Notebook Code Dependencies (MNCD), v{}
    Designed to manage caching of Python 'Code Sample' and Notebooks for local
    Notebook import. Supporting a more modular code design and promoting reuse.

     Author: Paul Dodd, Living Atlas Team, Software Product Release, Esri
    Version: v1.1.1, August 20, 2021
    Version: v1.1.0, August 15, 2020
    Version: v1.0.0,   June 28, 2020

Usage:
    Call 'manageDependents' function to add/update cached item content
        For usage detail, enter: 'print( mncd.manageDependents.__doc__)'

    Call 'removeDependents' function to remove cached item content
        For usage detail, enter: 'print( mncd.removeDependents.__doc__)'

    Call 'checkUpdates' function to manually check for and update MNCD
""".format( __version__)

mncdScripts = "/arcgis/home/mncd/Notebook Dependencies" # Home storage location of cached Code items
mncdNotebooks = "Notebooks" # Sub folder in 'scripts' where Notebook cached items are stored
mncdItemId = "11c80dd72ea64f3b8779165fbc57cede" # Yourself, for auto upgrades

##############################
# Manage Dependents function #
##############################

def manageDependents( itemIds, password=None, allowUpdates=None, onlyCodeBlocks=True, autoReload=True):
    """Function: 'manageDependents( itemIds, password=None, allowUpdates=None, onlyCodeBlocks=True, autoReload=True)'
           itemIds = Single String or a List of Strings containing the Item Id(s) to cache content for.
          password = (optional) String password needed to open encrypted Zip File(s) if used by Source.
      allowUpdates = (optional) True, False, or None. Controls update of existing cached item content.
                     'True' resets update flag set by prior call using 'False', allowing item updates moving forward.
                     'False' sets update flag, blocking untimely updates. This will PERSIST until called using 'True'.
                     Default: 'None' allows an update if the update flag is not set.
    onlyCodeBlocks = (optional) True or False. Controls caching behavior of Notebook.
                     Default: 'True' just honor function and class Code Blocks, plus zero indention import commands.
                     'False' honors complete Notebook code caching.
        autoReload = (optional) True or False. Controls behavior of Module re-import action if Module is already
                     imported.
                     Default: 'True' re-import a Module if it was already imported before an update.
                     'False' do not re-import a Module if it was already imported before an update.

    Update Notebook Kernel with dependent Python code from online Items.
    Automatically reloads updated Module if already imported.
"""

    import os, json, sys, zipfile, shutil, inspect, importlib

    # Make arcgis connection
    from arcgis.gis import GIS
    gis = GIS("home")

    if not itemIds:
        raise Exception( "manageDependents: itemIds cannot be empty")

    def addPath( scriptPath):
        # Add Path to all '.py' containing folders
        for path, folders, files in os.walk( scriptPath):
            for filename in files:
                if filename.lower().endswith( ".py"):
                    if path not in sys.path:
                        sys.path.append( path)
                        print( " - Path Added: '{}'".format( path))
                    else:
                        print( " * No need to add Path, already includes: '{}'".format( path))
                    break

    issue = False
    modules = {} # store Id and modules that may already be loaded, for reloading after an update

    # Identify managed Modules that may already be loaded
    for value in sys.modules.values():
        if hasattr( value, "__file__") and value.__file__ and value.__file__.startswith( mncdScripts):
            #id = value.__file__.split( mncdScripts, 1)[-1].split("/")[1]
            filepath, filename = os.path.split( value.__file__)
            # Get Notebook Id or Code Sample Id
            id = os.path.splitext( filename)[0].strip( "_") if filepath.endswith( mncdNotebooks) else os.path.split( filepath)[-1]
            modules[id] = modules.get( id, [])
            modules[id].append( value)

    # Process dependent item id(s)
    for id in (itemIds if isinstance( itemIds, list) else [itemIds]):
        print( "\nProcessing Dependent Item: https://www.arcgis.com/home/item.html?id={}".format( id), flush=True)

        item = gis.content.get( id)
        isNotebook = all( [key in item.typeKeywords for key in ["Notebook", "Python"]])

        scriptPath = os.path.join( mncdScripts, mncdNotebooks if isNotebook else id) # Use notebook folder or item id folder
        notebookName = "_{}".format( id)
        detailsFile = os.path.join( scriptPath, "{}.json".format( notebookName) if isNotebook else "itemDetails.json")
        notebookFile = os.path.join( scriptPath, "{}.py".format( notebookName)) if isNotebook else ""

        if not item:
            print( " * Dependent item is Missing or is no longer Accessible!")
            if not os.path.exists( detailsFile):
                issue = True
                print( " * No cached item available!")
                continue
            print( " - Using cached item!")
            addPath( scriptPath)
            if isNotebook:
                print( " * NOTE * Be sure to Import using Module name: '{}'".format( notebookName))

        else:
            print( " - {} Titled: '{}'".format( item.type, item.title))
            if not (isNotebook or all( [key in item.typeKeywords for key in ["Code", "Sample", "Python"]])):
                issue = True
                print( " * Incorrect item type, should be a Python 'Code Sample or Notebook' *")
                continue

            details = {}
            blockUpdates = (allowUpdates == False)
            if os.path.exists( detailsFile):
                details = json.load( open( detailsFile, "r"))
                blockUpdates = False if allowUpdates else (blockUpdates or details.get( "blockUpdates", False))

                if not blockUpdates == details.get( "blockUpdates", False):
                    # Save changes to Block Updates property in details file
                    details[ "blockUpdates"] = blockUpdates
                    json.dump( details, open( detailsFile, "w"), indent=2)

                if details.get( "lastModified", 0) >= item.modified:
                    if "codeBlocksOnly" in details and details[ "codeBlocksOnly"] != onlyCodeBlocks:
                        print( " - Cached item is current, {} codeBlocksOnly!".format( "enabling" if onlyCodeBlocks else "disabling"))
                    else:
                        print( " - Cached item is current, {}!".format( "but update is BLOCKED" if blockUpdates else "no update required"))
                        addPath( scriptPath)
                        if isNotebook:
                            print( " * NOTE * Be sure to Import using Module name: '{}'".format( notebookName))
                        continue

                elif blockUpdates:
                    print( " * Item updates available, but they are BLOCKED!")
                    continue

            # Re-Create item cache folder
            if not isNotebook:
                removeDependents( id, False) # Clear Code Sample folder
            if not os.path.exists( scriptPath):
                os.makedirs( scriptPath)

            if isNotebook:
                print( " - Updating item")
                # Download item and parse, saving code to Python Script file
                tmpScript = notebookFile + ".tmp"
                with open( tmpScript, "wb") as oFP:
                    for cell in json.load( open( item.download(), "r")).get( "cells", []):
                        markdown = cell[ "cell_type"] == "markdown"
                        if markdown or cell[ "cell_type"] == "code":
                            inBlock = False     # 'class' or 'def'
                            for line in ("\n" + cell[ "source"]).split( "\n"):
                                comment = ""
                                if markdown:
                                    comment = "#" if line else ""
                                elif onlyCodeBlocks:
                                    if line.startswith( "def ") or line.startswith( "class "):
                                        inBlock = True
                                    elif (not line) or line.startswith( "import ") or line.startswith( "from ") or line.strip().startswith( "#"):
                                        pass # accept line breaks, import commands, comments
                                    elif not inBlock:
                                        comment = "#"
                                    elif line[0] not in [" ", "\t"] and not line.startswith( '"""'):
                                        inBlock = False
                                        comment = "#"

                                oFP.write( bytearray( comment + line + "\n", "utf-8"))

                # Replace notebookFile with Tmp file
                if os.path.exists( notebookFile):
                    os.remove( notebookFile)
                os.rename( tmpScript, notebookFile)

                # Add Script path
                addPath( scriptPath)
                print( " * NOTE * Be sure to Import using Module name: '{}'".format( notebookName))

            else:
                # Download item and store
                ZipFile = zipfile.ZipFile( item.download(), "r")
                if password:
                    ZipFile.setpassword( password)

                # Unpack zip file contents
                members = 0
                for info in ZipFile.infolist():
                    ZipFile.extract( info.filename, scriptPath)
                    if not info.filename.endswith("/"): # Not a Folder
                        members += 1

                ZipFile.close()

                if members:
                    print( " - Item content members unZipped: {}".format( members))
                    addPath( scriptPath)
                else:
                    issues = True
                    print( " * Nothing to extact, check the Item Download content for issues!")

            # Save/update details
            details = {
                "id": item.id,
                "title": item.title,
                "lastModified": details.get( "lastModified", 0) if blockUpdates else item.modified,
                "blockUpdates": blockUpdates
            }

            if isNotebook: # Add Code level indicator
                details["codeBlocksOnly"] = onlyCodeBlocks

            json.dump( details, open( detailsFile, "w"), indent=2)

            # Reload updated Module(s)
            for module in modules.get( id, []):
                if not autoReload:
                    print( " * Unable to Reload updated Module: '{}', autoReload turned off!".format( module.__name__))
                    continue
                print( " - Reloading Module: '{}'".format( module.__name__))
                importlib.reload( module)

    if issue:
        raise Exception( "Unable to continue, one or more dependents are not available!")

def removeDependents( itemIds, verbose=True):
    """Function: 'removeDependents( itemIds, verbose=True)' will remove the local cache depentent item used by a Notebook.
            itemIds = Single String or a List of Strings containing the Item Id(s) to remove
            verbose = (optionl) True or False, indicating if function should report removal
                      Default: True, show removal detail
"""

    import os, shutil, sys

    if not itemIds:
        raise Exception( "removeDependents: itemIds cannot be empty")

    notebooks = os.path.join( mncdScripts, mncdNotebooks)
    removed = set()

    for id in (itemIds if isinstance( itemIds, list) else [itemIds]):
        scriptPath = os.path.join( mncdScripts, id)
        if os.path.exists( scriptPath):
            if scriptPath in sys.path:
                del sys.path[ sys.path.index( scriptPath)]          # Remove from system path
                print( " - Path Removed: '{}'".format( scriptPath))
            shutil.rmtree( scriptPath)                              # Prune limb
            removed.add( id)
        else:
            # Check Notebook Cache
            for path, folders, files in os.walk( notebooks, topdown=False):
                for index in range( len( files), 0, -1):
                    filename = files[ index-1]
                    filePath = os.path.join( path, filename)
                    if id in filename and os.path.exists( filePath):
                        os.remove( filePath)                        # Drop file
                        del files[ index-1]                         # Remove from file list
                        removed.add( id)

                if not files:
                    # Folder no longer has files
                    for index in range( len(folders), 0, -1):
                        folderPath = os.path.join( path, folders[ index-1])
                        if not os.path.exists( folderPath):
                            del folders[ index-1]                   # Remove from folders list

                    # Folder no longer has sub folders, drop it!
                    if not folders:
                        if path in sys.path:
                            del sys.path[ sys.path.index( path)]    # Remove from system path
                            print( " - Path Removed: '{}'".format( path))
                        os.rmdir( path)                             # Drop folder

    if verbose:
        for id in removed:
            print( "Removed Dependent Item Id: {}".format( id))
        if not removed:
            print( "Nothing to Remove!")

def checkUpdates( initialLoad=False):
    """Function: 'checkUpdates()' checks for and applies updates to MNCD tool.
"""

    import os, sys, importlib, zipfile

    print( "\nMNCD Loaded, checking for updates...")
    from arcgis.gis import GIS
    gis = GIS("home")
    item = gis.content.get( mncdItemId)

    mncdModule = sys.modules[ "home.mncd.mncd"] # Get MNCD Module details
    mncdPath = os.path.split( mncdModule.__file__)[0]
    lastmodified = int( os.stat( mncdModule.__file__).st_mtime) * 1000 if os.path.exists( mncdModule.__file__) else 0

    if not (lastmodified < item.modified):
        print( " - MNCD is up to date!")

        if initialLoad:
            print( "\n" + __doc__)
    else:
        # Download item and extract
        ZipFile = zipfile.ZipFile( item.download(), "r")

        # Make Directories if they don't exist
        if not os.path.exists( mncdPath):
            os.makedirs( mncdPath)

        # Unpack zip file contents or use as inventory to remove
        members = 0
        print( "")
        for info in ZipFile.infolist():
            filename = os.path.join( mncdPath, info.filename)
            # install
            if not filename.endswith( "/"): # Not a Folder
                print( " - Updating: '{}'".format( filename))
                members += 1

            ZipFile.extract( info.filename, mncdPath)

        ZipFile.close()

        print( "{}Total members Updated: {}".format( "\n" if members else "", members))

        if mncdModule:
            global mncdReload
            mncdReload = True
            # Reload Module
            print( "\nReloading Module...")
            importlib.reload( mncdModule)

# Check for updates following import
if "mncdReload" in globals():
    # Already updated by checkUpdates, no need to check again!
    del mncdReload
    # Show updated module details
    print( "\n" + __doc__)
else:
    # Only check for updates if newly imported, display details if no updates
    checkUpdates( True)
