#####################################################################
# ProcessEarthShaker.py - USGS Earthquake/Shakemap Reader Routine   #
#            Aggregated Live Feed processor                         #
#                                                                   #
# Created by: Paul Dodd - esri, Technical Marketing                 #
#                                                                   #
#      Build: 1.0.1, June 2012                                      #
#          - Patched Shakemap update detection issue                #
#          - Added Data Processing error notation on exit logic     # 
#      Build: 1.0.0, June 2012                                      #
#                                                                   #
# Depends on: ALFlib.py - v1.3+                                     #
#####################################################################

#########################
# Import base libraries #
#########################

import collections, csv, datetime, os, shutil, sys, time, xml.dom.minidom, zipfile

# Setup initial variables

home, scriptFilename = os.path.split( os.path.realpath(__file__))
scriptName = scriptFilename.split( '.')[0]

###############################
# Load config file if present #
###############################

configFilename = scriptName + '.cfg'

class ConfigFileLoader( object):
	# Class provides code issolation for configFile contents
	
	def logMessage( self, message):
		# Call 'self.logMessage' from ConfigFile to Log a message in Archive Log
		ALFlog.archive( message)
	
	if not os.access( configFilename, os.R_OK):
		sys.exit( " * Error * Unable to access configFile '{0}'!".format( configFilename))
	
	# Load config file
	try:
		# Content loaded will be local to this Class
		execfile( configFilename)	# configFilename MUST be defined before load process,
		#                               or class user-defined methods will NOT be accessible!
	
	except Exception as e:
		sys.exit( " * Error * Failure during configFile load: {0}".format(e))

ConfigFile = ConfigFileLoader()

# Assign variables

filegdbName = getattr( ConfigFile, 'fileGDB', scriptName)
if not filegdbName.endswith( '.gdb'):
	filegdbName += '.gdb'

earthquakeFeatureclassName = getattr( ConfigFile, 'earthquakeFeatureclass', 'Earthquakes')
shakemapFeatureclassName = getattr( ConfigFile, 'shakemapFeatureclass', 'Shakemaps')
nickName = getattr( ConfigFile, 'nickName', scriptName)
logRetention = getattr( ConfigFile, 'logRetention', 3)
minMagnitude = float( getattr( ConfigFile, 'minMagnitude', 3))
ageOutMin = datetime.datetime.utcnow() - datetime.timedelta( days=int(getattr( ConfigFile, 'daysToKeepMin', 90)))
ageOutOther = datetime.datetime.utcnow() - datetime.timedelta( days=int(getattr( ConfigFile, 'daysToKeepOther', 3)))
logPath = os.path.realpath( getattr( ConfigFile, 'logPath', 'Logs'))
workPath = os.path.realpath( getattr( ConfigFile, 'workPath', 'Work'))
importPath = os.path.realpath( getattr( ConfigFile, 'importPath', ''))
outputSR = getattr( ConfigFile, 'outputCoordSys', 102100)	# WGS 1984 Web Mercator Auxiliary Sphere
outputTR = getattr( ConfigFile, 'outputTransformation', '')
spatialIndexGrid = getattr( ConfigFile, 'outputSpatialIndexGrid', [ 2500000, 0, 0])	# In units of output CoordSys
addRegistration = getattr( ConfigFile, 'addRegistration', True)

###########################
# Import custom libraries #
###########################

if importPath:
	# Add path to import
	sys.path.append( importPath)

import ALFlib

# Verify ALFlib version, need at least v1.3
if not (hasattr( ALFlib, 'minVersion') and ALFlib.minVersion( 1, 3)):
	print "\n * Error: Found incompatible version of 'ALFlib.py' script, need at least v1.3.0 *\n"
	sys.exit(1)

ALFlog = ALFlib.Logger( nickName, logPath, logRetention, singleton=True)
Progress = ALFlib.Progress()

# Make sure Work area is available
if workPath and not os.access( workPath, os.F_OK):
	try:
		os.makedirs( workPath)
	
	except Exception as e:
		sys.exit( " * Failed to create workPath '{0}': {1}".format( workPath, e))

eqSourceURL = "http://earthquake.usgs.gov/earthquakes/catalogs/eqs7day-M1.txt"
smSourceURL = "http://earthquake.usgs.gov/earthquakes/catalogs/shakerss.xml"
sourceSR = 4326	# WGS 1984
errLimit = 0.10	# Error percent limit
boundaryProjection = ALFlib.Constants.ProjectionExtents[ sourceSR]

# Import ArcPy library, retry if failure to initialize
importTrys = 3
importWait = 5

print "\nImporting ArcPy..."
while importTrys:
	try:
		import arcpy
		# Set Script arguments
		arcpy.gp.logHistory = False		# Turn off GP function logging
		arcpy.env.overwriteOutput = True	# Allow GP commands to overwrite GDB content
		
		if outputTR:
			# Set Tranformation
			arcpy.env.geographicTransformations = outputTR
		break
	
	except Exception as e:
		importTrys -= 1
		print "* Failed to import 'arcpy' library: {0}".format( e)
		if importTrys:
			print "Waiting {0} seconds...".format( importWait)
			time.sleep( importWait)
			print "Retrying..."

if not importTrys:
	sys.exit(1)

#######################################################
# Setup output Column details, maintaining column order

Field = collections.namedtuple( 'Field', ['aliasName', 'domain', 'isNullable', 'length', 'name', 'precision', 'required', 'scale', 'type', 'createIndex'])

eqFields = ALFlib.OrderedDict()
smFields = ALFlib.OrderedDict()

# Change Order of or most any detail for columns below without needing to alter any other code!
eqFields[ 'colMagnitude'] =		Field( name='Magnitude', type='DOUBLE', precision=None, scale=None, length=None, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=True)
eqFields[ 'colDepth'] =			Field( name='Depth', type='DOUBLE', precision=None, scale=None, length=None, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=False)
eqFields[ 'colLocation'] =		Field( name='Location', type='TEXT', precision=None, scale=None, length=255, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=False)
eqFields[ 'colSource'] =		Field( name='Source', type='TEXT', precision=None, scale=None, length=25, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=False)
eqFields[ 'colEqid'] =			Field( name='Eqid', type='TEXT', precision=None, scale=None, length=25, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=True)
eqFields[ 'colVersion'] =		Field( name='Version', type='TEXT', precision=None, scale=None, length=2, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=False)
eqFields[ 'colUTC_DateTime'] =	Field( name='UTC_DateTime', type='DATE', precision=None, scale=None, length=None, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=True)
eqFields[ 'colURL'] =			Field( name='URL', type='TEXT', precision=None, scale=None, length=255, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=False)

# Add fields to Shakemap definition
smFields[ 'colPGAPOL_'] =		Field( name='PGAPOL_', type='DOUBLE', precision=None, scale=None, length=None, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=False)
smFields[ 'colPGAPOL_ID'] =		Field( name='PGAPOL_ID', type='DOUBLE', precision=None, scale=None, length=None, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=False)
smFields[ 'colGRID_CODE'] =		Field( name='GRID_CODE', type='DOUBLE', precision=None, scale=None, length=None, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=True)
smFields[ 'colVALUE'] =			Field( name='VALUE', type='DOUBLE', precision=None, scale=None, length=None, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=False)
smFields[ 'colMagnitude'] =		Field( name='Magnitude', type='DOUBLE', precision=None, scale=None, length=None, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=True)
smFields[ 'colSource'] =		Field( name='Source', type='TEXT', precision=None, scale=None, length=25, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=False)
smFields[ 'colEqid'] =			Field( name='Eqid', type='TEXT', precision=None, scale=None, length=25, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=True)
smFields[ 'colPUB_DateTime'] =	Field( name='PUB_DateTime', type='DATE', precision=None, scale=None, length=None, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=False)
smFields[ 'colUTC_DateTime'] =	Field( name='UTC_DateTime', type='DATE', precision=None, scale=None, length=None, aliasName=None, isNullable='NULLABLE', required='NON_REQUIRED', domain=None, createIndex=True)

##########################################################
# Create Featureclass and open Insert and Update Cursors #
##########################################################

def openCursors( home, filegdbName, featureclassName, shapeType, inputSR, outputSR, spatialGrid, columns, update=False):
	workspace = os.path.join( home, filegdbName)
	featureclass = os.path.join( workspace, featureclassName)
	
	##########
	print "\nPreparing Workspace '{0}'...".format( filegdbName)
	if arcpy.Exists( workspace):
		if not update:
			try:
				# Delete Workspace
				shutil.rmtree( workspace)
			
			except Exception as e:
				print "  * Failed to remove existing FileGDB Workspace '{0}': {1}".format( workspace, e)
				sys.exit( 1)
	else:
		update = False
	
	if not update:
		try:
			# Create new Workspace
			arcpy.CreateFileGDB_management( home, filegdbName, 'CURRENT')
		
		except Exception as e:
			print "  * Failed to create FileGDB: {0}".format( e)
			sys.exit( 1)
	
	##########
	update = arcpy.Exists( featureclass)
	
	if update:
		rowCount = long(arcpy.GetCount_management( featureclass).getOutput(0))
	else:
		rowCount = 0
	
	if not update:
		print "  Creating Template In-Memory Featureclass..."
		try:
			tempFC = arcpy.CreateFeatureclass_management( 'in_memory', featureclassName, shapeType, None, None, None, outputSR, None, spatialGrid[0], spatialGrid[1], spatialGrid[2])
		
		except Exception as e:
			print "  * Failed to create Template Featureclass: {0}".format( e)
			sys.exit( 1)
		
		try:
			colNum = 0.0
			for col in columns:
				colNum += 1
				sys.stdout.write( "\r    Adding fields...({0:3d}%)".format( int( colNum / len(columns) * 100)))
				arcpy.AddField_management( tempFC, col.name, col.type, col.precision, col.scale, col.length, col.aliasName, col.isNullable, col.required, col.domain)
		
		except Exception as e:
			print "\r    * Failure adding fields: {0}".format( e)
			sys.exit( 1)
		
		##########
		print "\r  Creating Output Featureclass '{0}' from Template...".format( featureclassName)
		try:
			arcpy.CreateFeatureclass_management( workspace, featureclassName, shapeType, tempFC, None, None, outputSR, None, spatialGrid[0], spatialGrid[1], spatialGrid[2])
		
		except Exception as e:
			print "  * Failed to create Featureclass: {0}".format( e)
			sys.exit( 1)
		
		##########
		# Check for and add attribute indexes
		try:
			for col in columns:
				if col.createIndex:
					indexName = col.name + "_IDX"
					sys.stdout.write( "    Adding index: '{0}'\n".format( indexName))
					arcpy.AddIndex_management( featureclass, col.name, indexName)
		
		except Exception as e:
			print "  * Failed to add Index: '{0}', {1}".format( indexName, e)
			sys.exit( 1)
		
		# Release objects
		del tempFC
		
		# Return Insert Cursor and None
		return arcpy.InsertCursor( featureclass, inputSR), None, rowCount
	else:
		# Return Insert and Update Cursors
		return arcpy.InsertCursor( featureclass, inputSR), arcpy.UpdateCursor( featureclass, None, inputSR), rowCount

#################################
# Set row values for Earthquake #
#################################

def setEarthquakeRow( row, item):
	
	if 'Magnitude' in item and item['Magnitude'] != None:
		row.setValue( eqFields.colMagnitude.name, float( item['Magnitude']))
	else:
		row.setNull( eqFields.colMagnitude.name)
	
	if 'Depth' in item and item['Depth'] != None:
		row.setValue( eqFields.colDepth.name, float( item['Depth']))
	else:
		row.setNull( eqFields.colDepth.name)
	
	if 'Region' in item and item['Region'] != None:
		row.setValue( eqFields.colLocation.name, item['Region'][0: eqFields.colLocation.length])
	else:
		row.setNull( eqFields.colLocation.name)
	
	if 'Src' in item and item['Src'] != None:
		row.setValue( eqFields.colSource.name, item['Src'][0: eqFields.colSource.length])
		source = item['Src'].strip()
	else:
		row.setNull( eqFields.colSource.name)
		source = ""
	
	if 'Eqid' in item and item['Eqid'] != None:
		row.setValue( eqFields.colEqid.name, item['Eqid'][0: eqFields.colEqid.length])
		eqid = item['Eqid'].strip()
	else:
		row.setNull( eqFields.colEqid.name)
		eqid = ""
	
	if 'Version' in item and item['Version'] != None:
		version = "{0:>{1}}".format( item['Version'].strip(), eqFields.colVersion.length)
		row.setValue( eqFields.colVersion.name, version[-eqFields.colVersion.length:])
	else:
		row.setNull( eqFields.colVersion.name)
	
	if 'Datetime' in item and item['Datetime'] != None:
		if isinstance( item['Datetime'], datetime.datetime):
			row.setValue( eqFields.colUTC_DateTime.name, item['Datetime'])
		else:
			datetimeFormat = '%A, %B %d, %Y %H:%M:%S %Z'
			row.setValue( eqFields.colUTC_DateTime.name, datetime.datetime.strptime( item['Datetime'], datetimeFormat))
	else:
		row.setNull( eqFields.colUTC_DateTime.name)
	
	if source and eqid:
		eventURL = "http://earthquake.usgs.gov/earthquakes/recenteqsww/Quakes/{0}{1}.php".format( source, eqid).strip()
		row.setValue( eqFields.colURL.name, eventURL[0: eqFields.colURL.length])
	else:
		row.setNull( eqFields.colURL.name)
	
	if 'Lat' in item and item['Lat'] != None and 'Lon' in item and item['Lon'] != None:
		row.setValue( 'Shape', arcpy.PointGeometry( arcpy.Point( float( item['Lon']), float( item['Lat']))))
	else:
		row.setNull( 'Shape')

###################################
# Add Boundary Features to output #
###################################

def addBoundary( cursor, extent):
	point = arcpy.Point()
	array = arcpy.Array()
	newRow = cursor.newRow()
	rowsAdded = 0
	
	for shape in extent:
		array.removeAll()
		points = len( shape)
		
		for coordinate in shape:
			point.X = coordinate[0]
			point.Y = coordinate[1]
			array.add( point)
		
		if points > 3:
			# Polygon
			newRow.setValue( 'Shape', arcpy.Polygon( array))
		elif points > 1:
			# Line
			newRow.setValue( 'Shape', arcpy.Polyline( array))
		else:
			# Point
			newRow.setValue( 'Shape', arcpy.PointGeometry( point))
		
		cursor.insertRow( newRow)
		rowsAdded += 1
	
	# Release objects
	del newRow
	del array
	del point

	return rowsAdded

#######################
# Process Earthquakes #
#######################

def processEarthquakes():
	
	try:
		print "\nChecking for Earthquake updates..."
		step = "download"
		if not ALFlib.getDownload( eqSourceURL, workPath):
			ALFlog.archive( " * No Earthquake updates found *")
			return
		
		download = os.path.join( workPath, os.path.split( eqSourceURL)[1])
		
		print "\nPreparing Earthquake data..."
		step = "prepare "
		input = csv.DictReader( open( download, 'rb'))
	
	except:
		print "  * Failed to {0} new Earthquake data *".format( step)
		raise
	
	rowErrs = 0
	rowsReg = 0
	
	rowsIn = 0
	rowsSkipped = 0
	rowDups = 0
	rowUpdates = 0
	rowInserts = 0
	rowDeletes = 0
	
	# Build Dictionary of incoming records indexed by Eqid
	
	datetimeFormat = '%A, %B %d, %Y %H:%M:%S %Z' # as in 'Monday, July 9, 2012 20:49:17 UTC'
	eqItems = {}
	
	for row in input:
		eqid = row['Eqid']
		#version = row['Version']
		version = "{0:>{1}}".format( row['Version'].strip(), eqFields.colVersion.length)[-eqFields.colVersion.length:]
		row['Version'] = version
		magnitude = float( row['Magnitude'])
		utcDate = datetime.datetime.strptime( row['Datetime'], datetimeFormat)
		
		rowsIn += 1

		if utcDate:
			if (magnitude < minMagnitude) and (utcDate < ageOutOther):
				rowsSkipped += 1
				sys.stderr.write( " - Skipped event: {0}, age too old for Other Magnitude\n".format( eqid))
				continue
			elif utcDate < ageOutMin:
				rowsSkipped += 1
				sys.stderr.write( " - Skipped event: {0}, age too old\n".format( eqid))
				continue
	
		if eqid in eqItems:
			rowDups += 1
			if version <= eqItems[ eqid][ 'Version']:
				continue
		
		# Add or Update newest version
		eqItems[ eqid] = row
	
	# Release input object
	del input
	
	totalRows = len( eqItems)
	
	# Create Insert Feature Cursor (iFC) and Update Feature Cursor (uFC)
	iFC, uFC, existingRows = openCursors( workPath, filegdbName, earthquakeFeatureclassName, 'POINT', sourceSR, outputSR, spatialIndexGrid, eqFields, True)
	
	# Process available input
	
	if totalRows:
		print "\nProcessing Earthquake data..."
		row = None
		if uFC:
			rowCount = 0.0
			
			# Update/Remove existing Rows if available
			for row in uFC:
				rowCount += 1
				
				eqid = row.getValue( eqFields.colEqid.name)

				if not eqid:
					continue	# Skip record if no eqid available, registration feature?

				version = row.getValue( eqFields.colVersion.name)
				utcDate = row.getValue( eqFields.colUTC_DateTime.name)
				magnitude = row.getValue( eqFields.colMagnitude.name)
				
				try:
					if Progress.willDisplay():
						# Only show feedback once a second
						Progress.display( " * Scanning Earthquakes...({0:3d}%)".format( int( rowCount / existingRows * 100)))
					
					if eqid in eqItems:
						if eqItems[ eqid][ 'Version'] > version:
							setEarthquakeRow( row, eqItems[ eqid])
							uFC.updateRow( row)
							rowUpdates += 1
							sys.stderr.write( " - Updated event: {0}\n".format( eqid))
						
						eqItems[ eqid][ 'Processed'] = True
					
					elif utcDate:
						# Only check and remove if not in Input, to avoid re-inserting.
						if (magnitude < minMagnitude) and (utcDate < ageOutOther):
							uFC.deleteRow( row)
							rowDeletes += 1
							sys.stderr.write( " - Deleted event: {0}, age too old for Other Magnitude\n".format( eqid))
						elif utcDate < ageOutMin:
							uFC.deleteRow( row)
							rowDeletes += 1
							sys.stderr.write( " - Deleted event: {0}, age too old\n".format( eqid))
				
				except Exception as e:
					rowErrs += 1
					
					# Don't process record any further
					if eqid in eqItems:
						eqItems[ eqid][ 'Processed'] = True
					
					print " * Failed to update Earthquake data for event '{0}':\n  '{1}'".format( eqid, e)
					if (float(rowErrs) / totalRows) > errLimit:
						raise Exception( "\n * Exceeded Error Limit percentage, giving up!")
			else:
				sys.stderr.write( "\n ************\n")
				Progress.clear( " * Updated {0} Earthquake(s)...".format( rowUpdates))
				print " * Deleted {0} Earthquake(s)...".format( rowDeletes)
		
		# Insert unprocessed records
		rowCount = 0.0
		row = iFC.newRow()
		
		for eqid in eqItems:
			rowCount += 1
			
			try:
				if Progress.willDisplay():
					# Only show feedback once a second
					Progress.display( " * Inserting Earthquakes...({0:3d}%)".format( int( rowCount / totalRows * 100)))
				
				# Insert Row if not already processed
				if not 'Processed' in eqItems[ eqid]:
					setEarthquakeRow( row, eqItems[ eqid])
					iFC.insertRow( row)
					if not rowInserts:
						sys.stderr.write( "\n")
					sys.stderr.write( " - Inserted event: {0}\n".format( eqid))
					rowInserts += 1
			
			except Exception as e:
				rowErrs += 1
				print " * Failed to insert Earthquake data for event '{0}':\n  '{1}'".format( eqid, e)
				if (float(rowErrs) / totalRows) > errLimit:
					raise Exception( "\n * Exceeded Error Limit percentage, giving up!")
		else:
			sys.stderr.write( "\n ************\n")
			Progress.clear( " * Inserted {0} Earthquake(s)...".format( rowInserts))
	
	# Add Extent Boundary features (Registration Marks)
	
	if addRegistration and not uFC:
		print "\nAdding Extent Boundary..."
		rowsReg = addBoundary( iFC, boundaryProjection[ 'pointLayer'])
		rowInserts += rowsReg
	
	# Any changes?
	if rowUpdates or rowDeletes or rowInserts:
		changeMsg = ""
		hasChanges = True
	else:
		changeMsg = " * No Changes"
		hasChanges = False
	
	ALFlog.archive( "EQs In:{0}, Skip:{1}, Dups:{2}, Errs:{3}, Upd:{4}, Ins:{5}, Del:{6}, Avail:{7}{8}".format( rowsIn, rowsSkipped, rowDups, rowErrs, rowUpdates, rowInserts, rowDeletes, existingRows - rowDeletes + rowInserts, changeMsg))
	
	print "\n Updates Received:  {0: 6d}".format( rowsIn)
	print "          Skipped:  {0: 6d}".format( rowsSkipped)
	print "       Duplicates:  {0: 6d}".format( rowDups)
	print "           Errors:  {0: 6d}".format( rowErrs)
	print "           Unique:  {0: 6d}".format( totalRows)
	print "\n Available Earthquakes on file:"
	if rowUpdates:
		print "          Initial:  {0: 6d} (Updated: {1})".format( existingRows, rowUpdates)
	else:
		print "          Initial:  {0: 6d}".format( existingRows)
	print "          Deleted: -{0: 6d}".format( rowDeletes)
	if rowsReg:
		print "         Inserted: +{0: 6d} (Boundary: {1})".format( rowInserts, rowsReg)
	else:
		print "         Inserted: +{0: 6d}".format( rowInserts)
	print "                    ------"
	print "            Total: ={0: 6d}".format( existingRows - rowDeletes + rowInserts)
	
	# Close and dispose of objects
	try:
		del iFC
		del row
		del uFC
	except:
		pass
	
	# Save Error report
	if rowErrs:
		ALFlog._exitValue = " * Data Processing Error(s) detected, please review *"

	return hasChanges

##############################
# Validate Shakemap data row #
##############################

def validateShakemap( item, datetimeFormat):
	
	eqid = None
	magnitude = None
	link = None
	utcDate = None
	pubDate = None
	source = None
	depth = None
	lat = None
	long = None
	location = None
	
	if item:
		if 'link' in item:
			link = item.link.text	# Used to extract 'eqid' and for data download path
			eqid = os.path.split( link[:-1])

			if len( eqid) > 1 and eqid[1]:
				eqid = eqid[1]
			else:
				raise Exception( "invalid Link field")
		else:
			raise Exception( "missing Link field")

		if 'title' in item:
			title = item.title.text.split( ' - ')
			try:
				magnitude = float( title[0])
				location = title[1]
			except:
				raise ALFlib.DataError( " - Skipped Shakemap event: {0}, invalid or missing Magnitude in Title".format( eqid))
		else:
			raise ALFlib.DataError( " - Skipped Shakemap event: {0}, missing Title field".format( eqid))

		if 'eq:seconds' in item:
			utcDate = item['eq:seconds'].text
			if utcDate.isdigit():
				utcDate = datetime.datetime.utcfromtimestamp( int( utcDate))
			else:
				raise ALFlib.DataError( " - Skipped Shakemap event: {0}, invalid Date/Time (eq:seconds field)".format( eqid))
		else:
			raise ALFlib.DataError( " - Skipped Shakemap event: {0}, missing Date/Time (eq:seconds field)".format( eqid))

		if 'pubDate' in item:
			try:
				pubDate = datetime.datetime.strptime( item.pubDate.text.replace( '+0000', 'UTC'), datetimeFormat)
			except Exception as e:
				raise ALFlib.DataError( " - Skipped Shakemap event: {0}, invalid Publication Date/Time (pubDate field)\n * {1}".format( eqid, e))
		else:
			raise ALFlib.DataError( " - Skipped Shakemap event: {0}, missing Publication Date/Time (pubDate field)".format( eqid))

		if 'eq:region' in item:
			source = item['eq:region'].text
			if source == 'global':
				source = 'us'
			eventURL = "http://earthquake.usgs.gov/earthquakes/recenteqsww/Quakes/{0}{1}.php".format( source, eqid).strip()
		else:
			sys.stderr.write( " - Note, Shakemap event: {0}, missing Source (eq:region field)".format( eqid))

		if 'eq:depth' in item:
			depth = float( item['eq:depth'].text)
		else:
			sys.stderr.write( " - Note, Shakemap event: {0}, missing Depth (eq:depth field)".format( eqid))
	
		if 'geo:lat' in item:
			lat = float( item['geo:lat'].text)
		else:
			sys.stderr.write( " - Note, Shakemap event: {0}, missing Latitude (geo:lat field)".format( eqid))
	
		if 'geo:long' in item:
			long = float( item['geo:long'].text)
		else:
			sys.stderr.write( " - Note, Shakemap event: {0}, missing Longitude (geo:long field)".format( eqid))
	
	return eqid, magnitude, link, utcDate, pubDate, source, depth, lat, long, location

#########################################################
# Download and Append Shakemap to Insert Feature Cursor #
#########################################################

def appendShakemap( iFC, item):
	downloadTrys = 3
	zipFilename = 'shape.zip'
	shapefileMask = 'mi.'
	shapefileName = None	# Set at extraction time
	sourceURL = os.path.join( item[ 'Link'], 'download/' + zipFilename)

	for attempt in range( 1, downloadTrys + 1, 1):
		try:
			rows = 0
			cursor = None
			
			if attempt > 1:
				print " * Trying Attempt: {0} of {1} *".format( attempt, downloadTrys)
			
			if ALFlib.getDownload( sourceURL, workPath, timeStamping=False):
				sys.stderr.write( " - Successful download...\n")
				
				# Clean off any existing Shapefile files first
				sys.stderr.write( " - Cleaning workspace...\n")
				for filename in os.listdir( workPath):
					if filename.find( shapefileMask) > -1:
						try:
							os.remove( os.path.join( workPath, filename))
						except Exception as e:
							if not filename.find( '.lock') > -1: # Ignore if a Lock file
								sys.stderr.write( " * Unable to remove file '{0}': {1}\n".format( filename, e))
				
				# Open Zip file
				sys.stderr.write( " - Opening Zip file...\n")
				zipFile = zipfile.ZipFile( os.path.join( workPath, zipFilename), 'r')
				
				# Extract Shapefile files
				for filename in zipFile.namelist():
					if filename.find( shapefileMask) > -1:
						if not filename.find( '.lyr') > -1:	# Extract if not the Layer file
							if filename.find( '.shp') > -1:
								shapefileName = filename	# Save Shapefile name
								sys.stderr.write( " - Extracting Shapefile: {0}\n".format( shapefileName))
							
							zipFile.extract( filename, workPath)
		
				# Close Zip file
				zipFile.close()
				del zipFile
				
				# Load Shapefile
				if not shapefileName:
					sys.stderr.write( " * No matching Shapefile found, cannot load *\n")
				else:
					featureclass = os.path.join( workPath, shapefileName)
					totalRows = long(arcpy.GetCount_management( featureclass).getOutput(0))
					sys.stderr.write( " - Total Features: {0}\n".format( totalRows))
					if not totalRows:
						sys.stderr.write( " * Shapefile is empty, no reason to load *\n")
					else:
						# Open a Cursor on Shapefile 
						cursor = arcpy.SearchCursor( featureclass)
						
						# Create new Row in Shakemap FC
						newRow = iFC.newRow()
						
						# 'item' field to store in what 'smFields' field
						commonFields = [
							['Magnitude','colMagnitude'],
							['Src','colSource'],
							['Eqid','colEqid'],
							['Datetime','colUTC_DateTime'],
							['pubDatetime','colPUB_DateTime']]
						
						# Initialize values for common fields
						for field, column in commonFields:
							if field in item and item[ field] != None:
								newRow.setValue( smFields[column].name, item[field])
							else:
								newRow.setNull( smFields[column].name)
						
						# Shapefile field to store in what 'smFields' field
						uniqueFields = [
							['PGAPOL_','colPGAPOL_'],
							['PGAPOL_ID','colPGAPOL_ID'],
							['GRID_CODE','colGRID_CODE'],
							['VALUE','colVALUE']]
						
						# Copy rows
						rowNum = 0
						for row in cursor:
							rowNum += 1
							try:
								# Initialize unique field values
								for field, column in uniqueFields:
									newRow.setValue( smFields[column].name, row.getValue(field))
								
								newRow.setValue( 'Shape', row.getValue( 'Shape'))
								
								# Insert Row
								iFC.insertRow( newRow)
								# Track successful rows inserted
								rows += 1
							
							except Exception as e:
								sys.stderr.write( " * Failed to process row {0}, error: '{1}'\n".format( rowNum, e))
						
						# Clean up
						del cursor, row
						del newRow
			
			break
		
		except Exception as e:
			if not downloadTrys - attempt:
				raise
			else:
				rows = 0
				print " * Encountered Error: '{0}' *".format( e)
	
	return rows

#####################
# Process Shakemaps #
#####################

def processShakemaps():
	
	try:
		print "\nChecking for Shakemap updates..."
		step = "download"
		if not ALFlib.getDownload( smSourceURL, workPath):
			ALFlog.archive( " * No Shakemap updates found *")
			return
		
		download = os.path.join( workPath, os.path.split( smSourceURL)[1])
		
		print "\nPreparing Shakemap data..."
		step = "prepare "
		
		input = ALFlib.xmlNormalizer( xml.dom.minidom.parse( open( download, 'rb')))
	
	except:
		print "  * Failed to {0} new Shakemap data *".format( step)
		raise
	
	# Verify RSS content
	
	if 'rss' not in input or 'channel' not in input.rss or 'item' not in input.rss.channel:
		raise ALFlib.DataError( " * Error: Input does not contain expected RSS content *")
	
	rowsReg = 0
	rowErrs = 0
	rowInserts = 0
	rowDeletes = 0
	
	eventsIn = 0		# Count events read in
	eventsSkipped = 0		# Count events were skipped
	eventsDeleted = 0		# Count 'Deleted' events
	eventsUpdated = 0		# Count 'Updated' events
	eventsInserted = 0	# Count 'Inserted' events
	eventDups = 0		# Count duplicate events
	eventErrs = 0		# Count event load errors
	
	# Build Dictionary of incoming records indexed by Eqid
	
	datetimeFormat = '%a, %d %b %Y %H:%M:%S %Z' # as in 'Mon, 09 Jul 2012 19:43:06 UTC'
	smItems = {}
	
	if not isinstance( input.rss.channel.item, list):
		items = [input.rss.channel.item]
	else:
		items = input.rss.channel.item

	for item in items:
		eventsIn += 1

		try:
			eqid, magnitude, link, utcDate, pubDate, source, depth, lat, long, location = validateShakemap( item, datetimeFormat)
		
			if (magnitude < minMagnitude) and (utcDate < ageOutOther):
				raise ALFlib.DataError( " - Skipped event: {0}, age too old for Other Magnitude".format( eqid))

			elif utcDate < ageOutMin:
				raise ALFlib.DataError( " - Skipped event: {0}, age too old".format( eqid))
			
			event = {
				'Eqid': eqid,
				'Magnitude': magnitude,
				'Link': link,
				'Datetime': utcDate,
				'pubDatetime': pubDate,
				'Src': source,
				'Depth': depth,
				'Lat': lat,
				'Lon': long,
				'Region': location
			}
			
			if eqid not in smItems:
				smItems[ eqid] = event
			else:
				eventDups += 1
		
		except ALFlib.DataError as e:
			eventsSkipped += 1
			sys.stderr.write( "{0}\n".format( e))
			continue
		
		except Exception as e:
			eventsSkipped += 1
			sys.stderr.write( " - Skipped event at row {0}: {1}\n".format( eventsIn, e))
			continue
		
	totalEvents = len( smItems)
	
	# Create Insert Feature Cursor (iFC) and Update Feature Cursor (uFC)
	iFC, uFC, existingRows = openCursors( workPath, filegdbName, shakemapFeatureclassName, 'POLYGON', sourceSR, outputSR, spatialIndexGrid, smFields, True)
	
	# Process existing FC data
	
	events = {}	# Track events on file
	
	if totalEvents:
		print "\nProcessing Shakemap data..."
		row = None
		if uFC:
			rowCount = 0.0
			ageLimit = datetime.timedelta( seconds=60)
			
			# Update/Remove existing Rows if available
			for row in uFC:
				rowCount += 1
				
				eqid = row.getValue( smFields.colEqid.name)

				if not eqid:
					continue	# Skip record if no eqid available, registration feature?

				pubDate = row.getValue( smFields.colPUB_DateTime.name)
				utcDate = row.getValue( smFields.colUTC_DateTime.name)
				magnitude = row.getValue( smFields.colMagnitude.name)
				
				# Record event
				if eqid not in events:
					events[ eqid] = False	# True = Delete records for Update or Removal
				
				try:
					if Progress.willDisplay():
						# Only show feedback once a second
						Progress.display( " * Scanning Shakemaps...({0:3d}%)".format( int( rowCount / existingRows * 100)))
					
					# If event not already flagged for Update or Delete, check it
					if not events[ eqid]:
						actionText = None
					
						if eqid in smItems:
							if 'Processed' not in smItems[ eqid]:
								# Compute age difference in seconds
								# 'arcpy.getValue( <date field>)' can report time +-1 second of actual
								if smItems[ eqid][ 'pubDatetime'] > pubDate:
									deltaAge = smItems[ eqid][ 'pubDatetime'] - pubDate
								else:
									deltaAge = pubDate - smItems[ eqid][ 'pubDatetime']

								# If event data is newer, mark for Update 
								if deltaAge >= ageLimit:
									smItems[ eqid][ 'Update'] = True
									events[ eqid] = True
									eventsUpdated += 1
									eventsDeleted += 1
									actionText = " - Flagging event: {0} for Update\n   Was: {1}, Now: {2}, Diff: {3}".format( eqid, pubDate, smItems[ eqid][ 'pubDatetime'], deltaAge)
								else:
									# Flag event as processed, no need to Update
									smItems[ eqid][ 'Processed'] = True
						else:
							# Check Minimum acceptable ranges for event
							if (magnitude < minMagnitude) and (utcDate < ageOutOther):
								events[ eqid] = True
								eventsDeleted += 1
								actionText = " - Deleted event: {0}, age too old for Other Magnitude".format( eqid)
							elif utcDate < ageOutMin:
								events[ eqid] = True
								eventsDeleted += 1
								actionText = " - Deleted event: {0}, age too old".format( eqid)

						if actionText:
							sys.stderr.write( "{0}\n".format( actionText))
					
					# Check if event is flagged for Update or Delete, remove row
					if events[ eqid]:
						uFC.deleteRow( row)
						rowDeletes += 1
				
				except Exception as e:
					rowErrs += 1
					
					# Don't process record any further
					if eqid in smItems:
						smItems[ eqid][ 'Processed'] = True
					
					print " * Failed to update data for event '{0}':\n  '{1}'".format( eqid, e)
					if (float( rowErrs) / existingRows) > errLimit:
						raise Exception( "\n * Exceeded Error Limit percentage, giving up!")
			else:
				sys.stderr.write( "\n ************\n")
				Progress.clear( " * Flagged {0} Shakemap(s) for Update...".format( eventsUpdated))
				print " * Deleted {0} rows for {1} Shakemap(s)...".format( rowDeletes, eventsDeleted)
		
		# Insert Events that were unprocessed or flagged for update
		rowCount = 0.0
		eventsUpdated = 0	# Clear Update count
		
		for eqid in smItems:
			rowCount += 1
			
			try:
				# Insert Shakemap if not already processed
				if not 'Processed' in smItems[ eqid]:
					sys.stderr.write( "\n************")
					print "\nProcessing event: {0}".format( eqid)
					
					rowInserts += appendShakemap( iFC, smItems[ eqid])
					
					if 'Update' in smItems[ eqid]:
						eventsUpdated += 1
						sys.stderr.write( " * Update Successful *\n")
					else:
						eventsInserted += 1
						sys.stderr.write( " * Insert Successful *\n")
			
			except Exception as e:
				eventErrs += 1
				print " * Failed to insert Shakemap data for '{0}':\n  '{1}'".format( eqid, e)
				if (float( eventErrs) / totalEvents) > errLimit:
					raise Exception( "\n * Exceeded Error Limit percentage, giving up!")
		else:
			sys.stderr.write( "\n ************\n")
			print " * Updated {0} Shakemap(s)...      ".format( eventsUpdated)
			print " * Inserted {0} Shakemap(s)...     ".format( eventsInserted)
	
	# Add Extent Boundary features (Registration Marks)
	
	if addRegistration and not uFC:
		print "\nAdding Extent Boundary..."
		rowsReg = addBoundary( iFC, boundaryProjection[ 'polygonLayer'])
		rowInserts += rowsReg
	
	# Check Earthquake Events, add if missing
	if smItems:
		print "\nChecking for missing Earthquakes detected by Shakemap process..."
		
		# Create Insert Feature Cursor (iFC) and Update Feature Cursor (uFC)
		iFC, uFC, eqExistingRows = openCursors( workPath, filegdbName, earthquakeFeatureclassName, 'POINT', sourceSR, outputSR, spatialIndexGrid, eqFields, True)
	
		for row in uFC:
			eqid = row.getValue( eqFields.colEqid.name)
			if eqid in smItems:
				del smItems[ eqid] # Remove event
		
		eqsAdded = 0

		if smItems:
			newRow = iFC.newRow()
			
			# Insert remaining entries, they are missing from Earthquake FC
			for eqid in smItems:
				setEarthquakeRow( newRow, smItems[ eqid])
				iFC.insertRow( newRow)
				eqsAdded += 1

		print " * Added {0} Earthquake(s) *".format( eqsAdded)

	# Add Extent Boundary features (Registration Marks) for Earthquakes
	
	if addRegistration and not uFC:
		print "\nAdding Extent Boundary..."
		rowsReg = addBoundary( iFC, boundaryProjection[ 'pointLayer'])
	
	# Any changes?
	if eventsUpdated or eventsDeleted or eventsInserted:
		changeMsg = ""
		hasChanges = True
	else:
		changeMsg = " * No Changes"
		hasChanges = False

	# Report outcome
	eventsDeleted -= eventsUpdated # Adjust Deleted count by the actual number that was updated
	ALFlog.archive( "SMs In:{0}, Skip:{1}, Dups:{2}, Errs:{3}, Upd:{4}, Ins:{5}, Del:{6} (rows: {7}), Avail:{8}{9}".format( eventsIn, eventsSkipped, eventDups, eventErrs, eventsUpdated, eventsInserted, eventsDeleted, rowDeletes, len( events) - eventsDeleted + eventsInserted, changeMsg))
	
	print "\n Updates Received:  {0: 6d}".format( eventsIn)
	print "          Skipped:  {0: 6d}".format( eventsSkipped)
	print "       Duplicates:  {0: 6d}".format( eventDups)
	print "           Errors:  {0: 6d}".format( eventErrs)
	print "           Unique:  {0: 6d}".format( totalEvents)
	print "\n Available Shakemaps on file:"
	if eventsUpdated:
		print "          Initial:  {0: 6d} (Updated: {1})".format( len( events), eventsUpdated)
	else:
		print "          Initial:  {0: 6d}".format( len( events))
	print "          Deleted: -{0: 6d}".format( eventsDeleted)
	if rowsReg:
		print "         Inserted: +{0: 6d} (Boundary rows added: {1})".format( eventsInserted, rowsReg)
	else:
		print "         Inserted: +{0: 6d}".format( eventsInserted)
	print "                    ------"
	print "            Total: ={0: 6d}".format( len( events) - eventsDeleted + eventsInserted)
	
	# Close and dispose of objects
	try:
		del iFC
		del row
		del uFC
	except:
		pass
	
	# Save Error report
	if rowErrs or eventErrs:
		ALFlog._exitValue = " * Data Processing Error(s) detected, please review *"

	return hasChanges

##############
# Main logic #
##############

try:
	# Set initial exit state
	hadUpdates = False
	
	step = "Earthquakes"
	
	if processEarthquakes():
		hadUpdates = True
	else:
		print "\n * No changes to {0} *".format( step)
	
	step = "Shakemaps"
	
	if processShakemaps():
		hadUpdates = True
	else:
		print "\n * No changes to {0} *".format( step)
	
	if hadUpdates:
		workSpace = os.path.join( workPath, filegdbName)
	
		# Invoke Analysis logic
		
		step = "Analysis logic"
	
		if hasattr( ConfigFile, 'analyze') and callable( ConfigFile.analyze):
			print "\nRunning Analysis..."
			
			ConfigFile.analyze( workSpace)
		
		# Compact GeoDatabase before Deployment
		
		step = "Geodatabase Compact operation"
	
		print "\nCompacting Workspace..."
		arcpy.Compact_management( workSpace)
		
		# Invoke Deployment logic
		
		step = "Deployment logic"
	
		if hasattr( ConfigFile, 'deploy') and callable( ConfigFile.deploy):
			print "\nRunning Deployment..."
			
			ConfigFile.deploy( workSpace)
	else:
		print "\n * No changes were made *"
	
except:
	print " * Encountered exception while processing '{0}' *".format( step)
	raise
