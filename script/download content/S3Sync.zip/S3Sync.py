######################################################
# S3Sync.py - Use to synchronize local file system   #
#             folders with Amazon S3 buckets. Only   #
#             initiates 'S3cmd.py sync' operation    #
#             when file system changes are detected  #
#             or when last sync is not today.        #
#                                                    #
# Created by: Paul Dodd - esri, Technical Marketing  #
#      Build: 1.0.0, May 2012                        #
#                                                    #
# Depends on: Python v2.6+, ALFlib.py v1.1+, and     #
#             included v1.0.2 patch of 's3cmd.py',   #
#             v1.0.1 from 'http://s3tools.org/s3cmd' #
#                                                    #
# Version History:                                   #
#      Build: 1.0.0 - Initial Release                #
######################################################

#########################
# Import base libraries #
#########################

import datetime, errno, os, stat, sys
import ConfigParser as configparser

# Setup initial variables

home, scriptName = os.path.split( os.path.realpath(__file__))

headerComments = """
##########################################################################
# Synchronize local or S3 content to/from Amazon S3 Buckets and folders  #
# Supports (Local to S3), (S3 to Local), and (S3 to S3) sync operations. #
##########################################################################

"""

footerComments = \
"""##################################################################################
# Add or modify sections above to control what content will be Synchronized.     #
# Any section name other than 'DEFAULT' will initiate a sync operation.          #
#                                                                                #
# Settings found in 'DEFAULT' section will apply to all sections.                #
# Settings found in other sections override default settings for that section.   #
#                                                                                #
# Uniquely name each section by including text between brackets. And add desired #
# Options as needed. Ex:                                                         #
#                                                                                #
# [Local to S3]                                                                  #
# source = \\\\MyServer\\TestShare\\Data\\          # Copy Local Folder contents      #
# destination = s3://MyBucket/TestData/        # to this Bucket and Folder!      #
# <option> = <value>                                                             #
# <option> = <value>                                                             #
#                                                                                #
# [S3 to Local]                                                                  #
# source = s3://MyBucket/TestData/MyFile.ext   # Copy this File                  #
# destination = C:\\TestDirectory\\Data\\         # to this Folder!                 #
# <option> = <value>                                                             #
# <option> = <value>                                                             #
#                                                                                #
# [S3 to S3]                                                                     #
# source = s3://MyBucket/TestData/             # Copy Folder contents            #
# destination = s3://MyOtherBucket/TestData/   # to this Bucket and Folder!      #
# <option> = <value>                                                             #
# <option> = <value>                                                             #
#                                                                                #
# * Note * Any comments added or altered in this file will NOT persist!          #
#                                                                                #
# Available options for DEFAULT section (ignored by other sections):             #
# ------------------------------------------------------------------------------ #
#      nickname = (required) Name of process, recorded in log files and general  #
#                            feedback. Default is name of script less extension. #
# log_retention = (required) Number of log file months to keep on-hand.          #
#                            Default is 3.                                       #
#      log_path = (required) File system path where log files will be stored.    #
#                            Default is 'Logs', relative to location of script.  #
#   import_path = (required) Additional file system path to aid search for       #
#                            'ALFlib.py' and 's3cmd.py' routines. Default search #
#                            path is the location of this script, followed by    #
#                            Python 'sys.path' folder list.                      #
# keep_activity = (optional) True or False. Retain error log when sync activity  #
#                            is detected and no errors reported. Allows you to   #
#                            track updates using the log files. Error log file   #
#                            is renamed to include '_activity' as an indicator.  #
#                                                                                #
# Available options for all sections:                                            #
# ------------------------------------------------------------------------------ #
#        source = (required) String containing Relative, Absolute, or UNC file   #
#                            system path with optional filename. (local to S3)   #
#                            Or: A case-sensitive S3 Bucket with optional folder #
#                            and optional filename. (S3 to local) or (S3 to S3)  #
#                            The file, or folder contents, will be synchronized. #
#   destination = (required) String containing Relative, Absolute, or UNC file   #
#                            system path. (S3 to local) If the Folder does not   #
#                            exist, it will be created. Or: A Case-sensitive S3  #
#                            Bucket and optional folder where content will be    #
#                            synchronized to. (local to S3) or (S3 to S3)        #
#                            The S3 Bucket MUST exist!                           #
#   do_not_sync = (optional) True or False. Setting this to True will skip the   #
#                            sync process for a given section. Default is False. #
# last_modified = (auto generated) Last Date/Time <folder> content was modified. #
#     last_sync = (auto generated) Last Date/Time <folder> content was Sync'ed.  #
#       sync_it = (auto generated) True or False. Tracking flag indicating a     #
#                                  sync operation is needed. User can override.  #
#                                                                                #
# Optional and relevant 's3cmd.py' options available to all sections:            #
# (see 's3cmd.py' Config file for additional options)                            #
# ------------------------------------------------------------------------------ #
#         access_key = (string containing security Access Key) s3cmd Default or  #
#                      use this to override for each 'sync' operation.           #
#         secret_key = (string containing security Secret Key) s3cmd Default or  #
#                      use this to override for each 'sync' operation.           #
#         acl_public = (True or False) s3cmd Default or use this to Grant/Revoke #
#                      'public' access to objects in S3.                         #
#     delete_removed = (True or False) s3cmd Default or use this to Delete       #
#                      destination files with no corresponding source file.      #
#            encrypt = (True or False) s3cmd Default or use this to Encrypt      #
#                      files before uploading.                                   #
# reduced_redundancy = (True or False) s3cmd Default or use this to Store        #
#                      objects with S3 Reduced Redundancy.                       #
#      skip_existing = (True or False) s3cmd Default or use this to Skip         #
#                      uploading objects that already exist in the S3 Bucket.    #
#            exclude = Comma separated list of GLOB entries used to exclude      #
#                      files from transfer process.                              #
#       exclude_from = Comma separated list of filenames containing GLOB entries #
#                      used to exclude files from transfer process.              #
#            include = Comma separated list of GLOB entries used to include      #
#                      files in the transfer process.                            #
#       include_from = Comma separated list of filenames containing GLOB entries #
#                      used to include files in the transfer process.            #
#                                                                                #
##################################################################################
"""

###############################
# Load config file if present #
###############################

configFilename = os.path.realpath( scriptName.split( '.')[0] + '.cfg')

# Reserved options that shouldn't make it to the s3cmd routine!
reservedOptions = [
	'nickname',
	'log_retention',
	'log_path',
	'import_path',
	'do_not_sync',
	'keep_activity',
	'source',
	'destination',
	'last_sync',
	'last_modified',
	'sync_it',
	'progress_meter'
]

# DEFAULT section, 'default' options
defaults = {
	reservedOptions[0]: scriptName.split( '.')[0],
	reservedOptions[1]: '3',
	reservedOptions[2]: 'Logs',
	reservedOptions[3]: '',
	reservedOptions[4]: False,
	reservedOptions[5]: False
}

ConfigFile = configparser.SafeConfigParser( defaults)

# Custom Config Option get/save routines

def saveConfig():
	oFP = open( configFilename, 'wb')
	if headerComments:
		oFP.write( headerComments)

	ConfigFile.write( oFP)

	if footerComments:
		oFP.write( footerComments)
	oFP.close()

def getFloatOption( section, option):
	try:
		return ConfigFile.getfloat( section, option)
	except:
		pass

def getIntOption( section, option):
	try:
		return ConfigFile.getint( section, option)
	except:
		pass

def getBooleanOption( section, option):
	try:
		return ConfigFile.getboolean( section, option)
	except:
		pass

def getDatetimeOption( section, option):
	try:
		value = ConfigFile.get( section, option)
		if value:
			return datetime.datetime.strptime( value, datetimeMask)
	except:
		pass

def getCommaList( section, option):
	try:
		return ConfigFile.get( section, option).split( ',')
	except:
		pass

def getFileList( section, option):
	value = []
	try:
		for file in ConfigFile.get( section, option).split( ','):
			if os.access( file, os.F_OK):
				value.append( file)
	except:
		pass
	return value

def applyOptions( section):
	sys.stdout.echo = False	# Echo console off!
	ops = {
		'exclude': None,
		'exclude_from': None,
		'include': None,
		'include_from': None
	}
	
	spacer = "\n"
	# Convert and apply options
	for key, value in ConfigFile.items( section):
		if key in optionTypes:
			value = optionTypes[ key]( section, key)

		# Exclude reserved options, these are not for s3cmd
		if key not in reservedOptions:
			if key in ops:
				print spacer + " * Setting s3cmd option: {0} to '{1}'".format( key, value)
				ops[ key] = value
			else:
				# Set or Ignore option
				if hasattr( cfg, key):		# Verify option
					print spacer + " * Setting s3cmd option: {0} to '{1}'".format( key, value)
					setattr( cfg, key, value)	# Set new value
				else:
					print spacer + " * Ignoring s3cmd option: {0}, does not exist".format( key)
			spacer = ""
	
	if ops['exclude'] or ops['exclude_from']:
		## Process --exclude and --exclude-from
		patterns_list, patterns_textual = process_patterns( ops['exclude'], ops['exclude_from'], is_glob = True, option_txt = "exclude")
		cfg.exclude.extend(patterns_list)
		cfg.debug_exclude.update(patterns_textual)

	if ops['include'] or ops['include_from']:
		## Process --include and --include-from
		patterns_list, patterns_textual = process_patterns( ops['include'], ops['include_from'], is_glob = True, option_txt = "include")
		cfg.include.extend(patterns_list)
		cfg.debug_include.update(patterns_textual)

	sys.stdout.echo = True	# Echo console on!

def getOption( section, option):
	try:
		if ConfigFile.has_section( section):
			if ConfigFile.has_option( section, option):
				return ConfigFile.get( section, option)
	except:
		pass

def getLocation( section, option):
	isS3 = False
	location = getOption( section, option)

	if location and type( location) == type( ''):
		if location.lower().startswith( 's3://'):
			isS3 = True
			if not (location.endswith( '/') or os.path.splitext( location)[1]):
				location += '/'	# Append / to end if folder, but not if a file
		else:
			# Must be a File or Folder
			location = os.path.realpath( location)
	
	return location, isS3

# s3cmd and local options by name and type, all others are considered string options
optionTypes = {
	'do_not_sync': getBooleanOption,
	'keep_activity': getBooleanOption,
	'acl_public': getBooleanOption,
	'delete_removed': getBooleanOption,
	'dry_run': getBooleanOption,
	'encrypt': getBooleanOption,
	'follow_symlinks': getBooleanOption,
	'force': getBooleanOption,
	'get_continue': getBooleanOption,
	'guess_mime_type': getBooleanOption,
	'human_readable_sizes': getBooleanOption,
	'list_md5': getBooleanOption,
	'preserve_attrs': getBooleanOption,
	'progress_meter': getBooleanOption,
	'recursive': getBooleanOption,
	'reduced_redundancy': getBooleanOption,
	'skip_existing': getBooleanOption,
	'use_https': getBooleanOption,
	'sync_it': getBooleanOption,
	'proxy_port': getIntOption,
	'recv_chunk': getIntOption,
	'send_chunk': getIntOption,
	'socket_timeout': getIntOption,
	'last_modified': getDatetimeOption,
	'last_sync': getDatetimeOption,
	'exclude': getCommaList,
	'exclude_from': getFileList,
	'include': getCommaList,
	'include_from': getFileList
}

# Read and Assign Default variables from config file

try:
	ConfigFile.read( configFilename)
	defaults = ConfigFile.defaults()
	
	nickName =		defaults.get( 'nickname')
	logRetention =	defaults.get( 'log_retention')
	logPath =		defaults.get( 'log_path')
	importPath =	defaults.get( 'import_path')

	if defaults.get( 'keep_activity'):
		keepActivity = True
	else:
		keepActivity = False

	if nickName:
		if type( nickName) != type( ''):
			print " * Invalid 'nickname' value in Config File, using default *"
			nickName = scriptName.split( '.')[0]
	else:
		nickName = scriptName.split( '.')[0]

	if logRetention:
		if logRetention.isdigit():
			logRetention = int(logRetention)
		
		if type( logRetention) != type( 0):
			print " * Invalid 'log_retention' value in Config File, using default *"
			logRetention = 3
	else:
		logRetention = 3
	
	if logPath:
		if type( logPath) == type( ''):
			logPath = os.path.realpath( logPath)
		else:
			print " * Invalid 'log_path' value in Config File, using default *"
			logPath = os.path.realpath( 'Logs')
	else:
		logPath = os.path.realpath( 'Logs')

	if importPath:
		if type( importPath) == type( ''):
			importPath = os.path.realpath( importPath)
		else:
			print " * Invalid 'import_path' value in Config File, using default *"
			importPath = os.path.realpath( '.')
	else:
		importPath = os.path.realpath( '.')

except Exception as e:
	sys.exit( " * Encountered exception: {0}".format( e))

#############
# Functions #
#############

def recursePath( path):
	# Returns 4-item Tuple containing most recently modified item Path, and Date,
	# plus total counts for Folders, and Files found in Directory
	try:
		newestPath = path
		newestModified = 0
		folders = 0
		files = 0

		# Try to gather stats on path, it may fail if we don't have access
		newestModified = datetime.datetime.fromtimestamp( os.stat( path).st_mtime)
		# Strip microseconds from datetime
		newestModified -= datetime.timedelta( microseconds=newestModified.microsecond)

		for item in os.listdir( path):
			try:
				lastPath = os.path.join( path, item)
				lastStat = os.stat( lastPath)
				lastMode = lastStat.st_mode
				lastModified = datetime.datetime.fromtimestamp( lastStat.st_mtime)
				
				# Strip microseconds from datetime
				lastModified -= datetime.timedelta( microseconds=lastModified.microsecond)
				
				# Query item type
				isFile = stat.S_ISREG( lastMode)
				isDir = stat.S_ISDIR( lastMode)

				if isDir or isFile:
					if isDir:
						lastPath, lastModified, lastFolders, lastFiles = recursePath( lastPath)
						folders += lastFolders + 1
						files += lastFiles
					else:
						files += 1

					# Check if this is the most recently modified File or Folder
					if newestModified < lastModified:
						newestModified = lastModified
						newestPath = lastPath

			except EnvironmentError as e:
				sys.stderr.write( " * Skipping: '{0}', {1}\n".format( e.filename, e.args[1]))

	except EnvironmentError as e:
		sys.stderr.write( " * Skipping: '{0}', {1}\n".format( e.filename, e.args[1]))

	except Exception as e:
		global errorExit
		
		errorExit = 1
		print( "\n * Exception running 'recusePath' on: '{0}', {1}".format( path, e))

	finally:
		return newestPath, newestModified, folders, files

def validate( source, destination):
	# Validate Source and Destination values

	if not source:	# Verify Source was specified
		if destination:
			return "'source' is unspecified"
		else:
			return "'source' and 'destination' are unspecified"

	elif not destination:	# Verify Destination was specified
		return "'destination' is unspecified"
		
	elif type( source) != type( ""):
		return "invalid 'source' name"
	
	elif not (source.lower().startswith( "s3://") or os.access( source, os.F_OK)):
		# Invalid source if not S3 and path not found
		return "path to 'source' not found"

	elif type( destination) != type( ""):
		return "invalid 'destination' name"

	elif not destination.lower().startswith( "s3://"):
		# Check for valid destination path if not S3
		if os.access( destination, os.F_OK):
			if not stat.S_ISDIR( os.stat( destination).st_mode):
				return "'destination' is not a folder"
		else:
			try:
				# Create destination folder
				os.mkdir( destination)
			except Exception as e:
				return "failed to create 'destination': {0}".format( e)
	
	if not (source.lower().startswith( "s3://") or destination.lower().startswith( "s3://")):
		return "'source' and 'destination' CANNOT both be files/folders"

class StdOverride( object):
	# Class designed to override sys.stdout and sys.stderr (output) handlers
	def __init__(self, origFp):
		self._origFp = origFp
	
	@property
	def echo( self):
		if hasattr( self._origFp, 'echo'):
			return self._origFp.echo
		
	@echo.setter
	def echo( self, value):
		if hasattr( self._origFp, 'echo'):
			self._origFp.echo = value
	
	@property
	def log( self):
		if hasattr( self._origFp, 'log'):
			return self._origFp.log
		
	@log.setter
	def log( self, value):
		if hasattr( self._origFp, 'log'):
			self._origFp.log = value
	
	def write(self, string):
		global s3stored
		global s3deleted
		
		echo = self.echo
		log = self.log
		
		if string.startswith( "File ") and string.count( 'stored as'):
			# Handle progress feedback for Local to S3
			s3stored += 1
			val = string.rsplit('[')[1][0:-2].split()
			if isinstance( val, list) and len(val) == 3 and int(val[2]) > 1:
				self.echo = True
				self.log = False
				self._origFp.write( "\r{0: 4.0%} complete...\r".format( float(val[0]) / float(val[2])))
				self.log = log
			self.echo = False		# Don't echo to console
		elif string.startswith( "File ") and string.count( 'copied to'):
			# Handle progress feedback for S3 to ??, no progress available!
			self.echo = False		# Don't echo to console
		elif string.startswith( "deleted: "):
			self.echo = False		# Don't echo to console
			s3deleted += 1
		elif string.startswith( "Summary: "):
			words = string.split()
			if len(words) > 6 and words[ 1].isdigit() and words[ 6].isdigit():
				s3stored = int( words[ 1]) 
				s3deleted = int( words[ 6]) 
			self.echo = False		# Don't echo to console
		elif string.startswith( "WARNING: "):
			self.echo = False		# Don't echo to console
		elif string.startswith( "Done. "):
			self.echo = False		# Don't echo to console
		
		self._origFp.write( string)
		
		self.echo = echo
		self.log = log
	
	def writelines(self, sequence):
		self._origFp.writelines( sequence)

	def flush(self):
		self._origFp.flush()

###########################
# Import custom libraries #
###########################

if importPath:
	# Add path to import
	sys.path.insert( 0, importPath)

import ALFlib

##############
# Main Logic #
##############

datetimeMask = '%Y-%m-%d %H:%M:%S'
newestModified = 0
newestPath = ""
errorExit = None
configSaved = False
cfg = None

# Verify ALFlib version, need at least v1.1
if not (hasattr( ALFlib, 'minVersion') and ALFlib.minVersion( 1, 1)):
	print "\n * Error: Found incompatible version of 'ALFlib.py' script, need at least v1.1.0 *\n"
	sys.exit(1)

ALFlog = ALFlib.Logger( nickName, logPath, logRetention, singleton=True)

# Override StdOut and StdErr to trap s3cmd messages
sys.stdout = StdOverride( sys.stdout)
sys.stderr = StdOverride( sys.stderr)

# import s3cmd.py
try:
	s3cmdFile = 's3cmd.py'
	for path in (['.'] + sys.path):	# Locate script in path
		if os.access( os.path.join( path, s3cmdFile), os.F_OK):
			s3cmdFile = os.path.join( path, s3cmdFile)
			break
	
	sys.stderr.log = False	# Expecting an error, turn off logging!
	execfile( s3cmdFile)

except IOError as e:
	sys.stderr.log = True	# Turn logging back on!
	ALFlog.archive( " * Error: Unable to locate 's3cmd.py' in import_path *", True)
	sys.exit( 1)

except:
	ALFlog._exitValue = None	# Clear the exit error

finally:
	sys.stderr.log = True	# Turn logging back on!
	sys.stderr.echo = False	# Echo errors to console!

# Success, now check s3cmd version
if PkgInfo.version != '1.0.2':
	ALFlog.archive( " * Error: Found incompatible script '{0}' *\n\n   Requires: v1.0.2\n      Found: v{1}\n".format( s3cmdFile, PkgInfo.version), True)
	sys.exit( 1)

# Check for s3cmd configuration
if not cfg:
	ALFlog.archive( " * Error: 's3cmd.py' has not been configured for this user *\n\n     Run: 's3cmd.py --configure' or apply config file, then retry!\n", True)
	sys.exit( 1)

# Turn off s3cmd Progress Meter, needed to trap progress!
cfg.progress_meter = False

# Loop through each Sync Request Section
for section in ConfigFile.sections():
	# Get source
	source, srcS3 = getLocation( section, 'source')

	# Get destination
	destination, destS3 = getLocation( section, 'destination')

	# Apply options
	applyOptions( section)

	# Check initial conditions
	if getBooleanOption( section, 'do_not_sync'):
		# User wishes NOT to sync this entry
		message = "do_not_sync = True"
	else:
		# Verify Source and Destination
		message = validate( source, destination)

	if not message and srcS3:
		sys.stdout.echo = False
		print "\nChecking for content in: '{0}'".format( source)

		try:
			s3content = fetch_remote_list( source, True, True)
		
		except Exception as e:
			message = e

		if not message:
			s3files = 0
			s3folders = 0
			for key in s3content:
				if key and not key.endswith( '/'):
					s3files += 1
				else:
					s3folders += 1
			
			print " * Found {0} files and {1} folders *".format( s3files, s3folders)
		
		sys.stdout.echo = True
	if message:
		message = " * Skipping '{0}': {1} *".format( section, message)
		print "\n" + message + "\n\n----"
		ALFlog.archive( message)
		continue
	else:
		lastModified = getDatetimeOption( section, 'last_modified')
		lastSync = getDatetimeOption( section, 'last_sync')
		syncIt = getBooleanOption( section, 'sync_it')
	
		# Reset counters
		s3stored = 0
		s3deleted = 0
		newestPath = None
		newestModified = None
		
		# Check for most recent update to source if not S3
		if not srcS3:
			newestPath, newestModified, folders, files = recursePath( source)
		
		# Check if time to Sync
		if srcS3:
			message = "Source is S3"
		elif not (lastModified and lastSync):
			message = "First run or Missing sync times"
		elif (syncIt and newestModified == lastModified):
			message = "Post-Lull or User initiated"
		elif (lastSync.date() != datetime.date.today()):
			message = "New day true-up"
		else:
			message = None
			
		if message:
			sys.stdout.echo = False	# Echo to console off!
			print "\n * Time to sync '{0}': {1} *".format( section, message)
			sys.stdout.echo = True	# Echo to console on!

			print "\nSyncing: '{0}'\n        Source: '{1}'\nto\n   Destination: '{2}'\n".format( section, source, destination)
			
			# Ok time to Sync!
			try:
				# Change working folder
				if not srcS3:
					# Source is a File or Folder
					try:
						os.chdir( source)
						# Success, source is a directory!
						cmd_sync_local2remote( [ '.', destination])
					except:
						# Failed, source must be a File!
						cmd_sync_local2remote( [ source, destination])
				elif not destS3:
					# Destination is a Folder
					os.chdir( destination)
					cmd_sync_remote2local( [ source, '.'])
				else:
					# Destination is S3
					cmd_sync_remote2remote( [ source, destination])
				
				# Update sync details
				if srcS3:
					# Don't need last_modified and sync_it for S3 sources, remove!
					if ConfigFile.has_option( section, 'last_modified'):
						ConfigFile.remove_option( section, 'last_modified')
					if ConfigFile.has_option( section, 'sync_it'):
						ConfigFile.remove_option( section, 'sync_it')
				else:
					ConfigFile.set( section, 'last_modified', newestModified.strftime( datetimeMask))
					ConfigFile.set( section, 'sync_it', "False")
				
				ConfigFile.set( section, 'last_sync', datetime.datetime.now().strftime( datetimeMask))
				
				# Report details
				if s3stored:
					# Reflect change, keep Log activity
					ALFlog.keepActivity = keepActivity
					if s3deleted:
						message = "Sync file total: {0} stored, {1} deleted for '{2}'...".format( s3stored, s3deleted, section)
					else:
						message = "Sync file total: {0} stored for '{1}'...".format( s3stored, section)
				else:
					if s3deleted:
						# Reflect change, keep Log activity
						ALFlog.keepActivity = keepActivity
						message = "Sync file total: {0} deleted for '{1}'...".format( s3deleted, section)
					else:
						message = "No changes for '{0}'...".format( section)
			
			except Exception as e:
				errorExit = 1
				message = " * Failed to Sync '{0}' *".format( section)
				sys.stderr.write( " * Error: {0}\n".format( e))

			# Change working folder back to Home
			os.chdir( home)
				
		else:
			print	# Add newline
			
			# Compute sync change
			syncIt = not (lastModified and lastModified == newestModified)
			
			# Update sync details
			ConfigFile.set( section, 'last_modified', newestModified.strftime( datetimeMask))
			ConfigFile.set( section, 'sync_it', "{0}".format( syncIt))
			
			# Report details
			if syncIt:
				message = "Waiting for lull on '{0}'...".format( section)
			else:
				message = "No changes found for '{0}'...".format( section)
		
		if message:
			print message + "\n\n----"
			ALFlog.archive( message)
		
		# Save Config details
		saveConfig()
		configSaved = True
		
	# Clear options in Config Dictionary
	cfg.__dict__.clear()

if not configSaved:
	saveConfig()

# End routine, pass along any error
sys.stderr.echo = True

try:
	sys.exit( errorExit)
except Exception as e:
	ALFlog.archive( "\n * Unexpected error on exit: {0}\n".format( e), True)
