ALFdeployer.py - Aggregated Live Feed archive download and deployment routine v2.2.1
------------------------------------------------------------------------------------

The ALFdeployer.py Python script is an Aggregated Live Feed routine designed to
download, unpack, and deploy archived File Geodatabases created by ALF-Lite processing
routines. Use the configuration file to direct what Zip archives to download and where
they should be deployed.

Can be used for other types of content as well, not just Archived File Geodatabases!

Launch once to generate a new configuration file that can then be altered as needed.
Create multiple configuration files to spawn alternate processes. Then, use Windows
scheduler or Unix cron job to launch one or more ALFdeployer routines to handle
downloads.

Archive Zip files are unpacked using 7Zip compressor/decompressor. If 7z routine is
not found in the path, the script will fallback to using the internal (but slower)
Python unzip libraries. Therefore, it is strongly recommended that 7z is installed!

Storage Layout:
---------------

<Home>
|   ALFlib.py                       (can be stored elsewhere, see import_path option)
|   ALFdeployer.cfg                       (can be any filename with '.cfg' extension)
|   ALFdeployer.err                         (Error file used when Logs not available)
|   ALFdeployer.py
+---Live                           (can be anywhere you like, see configuration file)
|   \---<FileGeodatabaseFolder>.gdb
|           <Geodatabase Files>
+---Logs                           (can be anywhere you like, see configuration file)
|   |   ALFdeployer_<YYYYMM>.txt                      (Summary of activity for month)
|   |   ALFdeployer_LastRun.txt                                (Details for Last Run)
|   \---ALFdeployer_Errors
|           <YYYYMMDD_HHMI>.txt                   (Details for Run if error detected)
\---Work                           (can be anywhere you like, see configuration file)
    |   <ArchivedFileGeodatabaseFolder>.zip
    \---<UnpackedFileGeodatabaseFolder>.gdb
            <Geodatabase Files>

Process Workflow:
-----------------

- Read '<configFile>.cfg' file, set options
- Setup/Manage environment and Logging, handled by 'ALFlib.py'
- Loop through sections in configuration file
	- Check source for updates
		- Download
		- Unpack archive
		- Create or Overrite File Geodatabase with new content
- If sync_interval defined, wait before starting process again, else terminate

Command-line usage:
-------------------

Simply enter 'ALFdeployer.py' from a command-line console to launch. A new configuration
file will be generated for you, just modify as needed. If you already have a
configuration file, just enter 'ALFdeployer.py <configFile>.cfg' to start the download
and deployment process.

If a configuration file is specified, the script will use the configuration file location
as the root location for the process. Otherwise, it will use the current location where
the script was launch. All 'relative' paths within the configuration file will reference
this location!

Depenancies:
------------

This script relies on:
- ALFlib.py v2.3.0+ helper script
- Python v2.6, v2.7 (v3 coming soon)
