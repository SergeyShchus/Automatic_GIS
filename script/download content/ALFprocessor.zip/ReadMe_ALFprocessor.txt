ALFprocessor.py - Aggregated Live Feed processor routine v1.7.0
------------------------------------------------------------------------------------

The ALFprocessor.py Python script is an Aggregated Live Feed processor designed to
ingest and process Aggregated Live Feed Configuration files. These files are user-
defined ALF/ALF-Lite processing routines that can download, process, and distribute
near Real-Time data. When launched, the ALFprocessor will manage the environment
and details related to a 'Feed', allowing the configuration file to concentrate on
the details and logic of how to process the data.

The ALFprocessor provides:
	- Log file creation and management with integrated Multiprocessing (new at v1.1.0)
	  See: 'MultiProcessingSample.cfg' for example usage!
	- Error handling and reporting if not already trapped by the user's logic
	- Prior run failure detection and reporting
	- Integrated SMTP E-mail functionality for Alert notifications
	- Arcpy import management with retry, wait options, and product specification
	- Version management for ALFlib, ALFprocessor, and arcpy components
	- Functions to support common Feed processing tasks
	- Heartbeat file generation to support remote monitoring
	- A common Feed design platform for all of your Live Feed Routines

Storage Layout:
---------------

<System_Path_Accessible_Folder or Feed_Home_Folder>
|   ALFlib.py                    (can be stored elsewhere, but recommend Python home, 
|                                                            see 'importPath' option)
|   ALFprocessor.py
|   ALFlib_env.py (optional)               ('Global' Environment script, will provide
|                                                  default settings for all routines)

<Feed_Home_Folder>
|   <configFile>.cfg                      (can be any filename with '.cfg' extension)
|   <configFile>.err                     (Error file created when Logs not available)
|   ALFlib_env.py (optional)                 ('Local' Environment script, will add to
|                                     'Global' settings for any routine in this home)
|   <Feed_nickName>_env.py (optional) 'Feed-Specific' Environment script, will add to
|                                'Global' and 'Local' settings for this routine only)
+---Live                           (can be anywhere you like, see configuration file)
|   \---<FileGeodatabaseFolder>.gdb
|           <Geodatabase Files>
+---Logs                           (can be anywhere you like, see configuration file)
|   |   <Feed_nickName>_<YYYYMM>.txt                  (Summary of activity for month)
|   |   <Feed_nickName>_Details.json            (Detailed activity tracked by Logger)
|   |   <Feed_nickName>_EmailLog_<YYYYMM>.txt             (E-mail activity for month)
|   |   <Feed_nickName>_LastRun.txt                            (Details for Last Run)
|   \---<Feed_nickName>_Errors
|           <YYYYMMDD_HHMI>.txt                   (Details for Run if error detected)
\---Work                           (can be anywhere you like, see configuration file)
    |   <ArchivedFileGeodatabaseFolder>.zip
    \---<UnpackedFileGeodatabaseFolder>.gdb
            <Geodatabase Files>

Process Workflow:
-----------------

- Processing 'Loop' (using a Scheduled Task, cron job, or by setting 'syncInterval')
	- Locate and ingest '<configFile>.cfg' file, set options
	- Setup/Manage environment and Logging (handled by 'ALFlib.py')
	- Call 'main' function in configuration file
	- If 'syncInterval' is defined
		- Wait for the specified time interval, or a configuration file change
		- Start the Processing Loop again 
	- Else
		- Terminate process

Command-line usage:
-------------------

'[python[.exe]] ALFprocessor.py [-c] [<drive and path>]<configFile>[.cfg]'

Launch using '-c' option to generate a template configuration file in the location
and name specified, which can then be altered as needed.

Launch without the '-c' option to run the feed process using the specified
configuration file.

Use a Windows task scheduler or Unix cron job to launch ALFprocessor routine on a
scheduled basis.

The ALFprocessor script will use the configuration file location as the root location
for the process. All 'relative' paths within the configuration file will reference
this root location!

Unix tips:
----------

This script can be called directly as a batch routine by doing the following:
	- Copy script to system 'path' accessible location.
        So it can be found from anywhere
	- Include '#!<path and name of python executable>' as the first line in the
        script. Allowing the operating system to call the executable to handle the
        file. This is synonymous to specifying 'python ALFprocessor.py' at the
        command prompt.
	- Add execution permissions to the script by using the 'chmod' command

Dependencies:
------------

This script relies on:
- ALFlib.py v2.1+ helper script
- Python v2.6+
