Exercise 5
==========

.. image:: https://img.shields.io/badge/launch-CSC%20notebook-blue.svg
   :target: https://notebooks.csc.fi/#/blueprint/d189695c52ad4c0d89ef72572e81b16c

.. admonition:: Start your assignment

    You can start working on your copy of Exercise 5 by `accepting the GitHub Classroom assignment <https://classroom.github.com/a/9qn_zwxv>`__.

**Exercise 5 is due by Thursday the 3rd of December at 5pm** (day before the next practical session).


You can also take a look at the open course copy of `Exercise 5 in the course GitHub repository <https://github.com/AutoGIS-2020/Exercise-5>`__ (does not require logging in).
Note that you should not try to make changes to this copy of the exercise, but rather only to the copy available via GitHub Classroom.

Exercise 5 hints
---------------------

