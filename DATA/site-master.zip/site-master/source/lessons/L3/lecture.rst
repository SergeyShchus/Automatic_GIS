Lecture
=======

.. admonition:: Lesson 3.1 - Geocoding addresses; Point in Polygon queries

    .. raw:: html

        <iframe width="560" height="315" src="https://www.youtube.com/embed/-ELys6BpBwQ?start=1" frameborder="0" allowfullscreen></iframe>
        <p>Henrikki Tenkanen, University of Helsinki <a href="https://www.youtube.com/channel/UCGrJqJjVHGDV5l0XijSAN1Q/playlists">@ AutoGIS channel on Youtube</a>.</p>


.. admonition:: Lesson 3.2 - Spatial join; Nearest neighbor analysis; Exercise 3 overview

    .. raw:: html

        <iframe width="560" height="315" src="https://www.youtube.com/embed/HV-5Es40UMs?start=1" frameborder="0" allowfullscreen></iframe>
        <p>Henrikki Tenkanen, University of Helsinki <a href="https://www.youtube.com/channel/UCGrJqJjVHGDV5l0XijSAN1Q/playlists">@ AutoGIS channel on Youtube</a>.</p>
