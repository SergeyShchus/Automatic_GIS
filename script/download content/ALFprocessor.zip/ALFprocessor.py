
################################################################################
# ALFprocessor.py - Aggregated Live Feed processor                             #
#                                                                              #
# Core ALF processing routine. Manages all common operations. Will ingest an   #
# ALF configuration file designed to download and process a given set of data, #
# producing a final output data set that can be deployed using the ALF         #
# architecture.                                                                #
#                                                                              #
# Created by: Paul Dodd - esri, Software Product Release, Content Team         #
#    Contact: pdodd@esri.com                                                   #
#                                                                              #
#       Build: 1.7.0, October 2016                                             #
#            - Patched internal 'ConfigFileLoader' class to report and raise   #
#              general error during load, to allow traceback logic.            #
#            - Updated internal 'getArgs' function to set errorlevel outcome   #
#              on exit when input parameter checks fail.                       #
#            - Updated to support Timestamp logging update in ALFlib v2.3.0.   #
#            - Added deprecation notice to 'createBoundaryLayer' and           #
#              'addRegistrationFeatures' functions in 'ConfigFileLoader' class.#
#              Included notice when setting e-mail options from Configuration  #
#              file, encouraging use of 'ALFlib_Env.py' script.                #
#            - Added recognition of 'delayArcpyLoad' parameter to enhance      #
#              delayed import of ArcPy.                                        #
#            - Updated to set ALFlog.keepActivity and ALFlog.setFlag based on  #
#              Config.main return outcome.                                     #
#            - Updated importArcpy function to handle specified product load   #
#              failure, reporting issue then defaulting to installed product.  #
#              Also set default 'workspace' to 'scratchWorkspace'. Included    #
#              'scratchPath' variable to allow custom scratch path to be set.  #
#            - Restuctured to remove Tab indentions in code.                   #
#       Build: 1.6.0, December 2015                                            #
#            - Patched Arcpy message reporting to skip logic if having issues. #
#            - Added 'ALFprocessor_Enabled' environment logic.                 #
#            - Added logic to clear Timeout in the event of an exception.      #
#            - Added logic for catching and reporting new Flag conditions.     #
#            - Altered distribute logic to accept a category for other sources.#
#            - Added internal Heartbeat file and Environment logic.            #
#       Build: 1.5.1, October 2015                                             #
#            - Patched syncInterval logic so we return to ConfigFile 'home'    #
#              folder when starting the next 'cycle'. Only an issue when       #
#              launched from location other than Feed's home folder and the    #
#              'syncInterval' value is used.                                   #
#            - Augmented 'import Arcpy' function to include ArcGIS product     #
#              license specification, leveraging the Environment Variable      #
#              'ALFarcpy_Product' as a default. Allowing you greater control   #
#              over the product level that should be used for scripting.       #
#       Build: 1.5.0, May 2015                                                 #
#            - Enhanced 'importArcpy' function, setting temporary environment  #
#              variables to the process scratch workspace. Issolating each     #
#              Arcpy instance from one another by seperating their temporary   #
#              workspace areas, further improving reliability.                 #
#            - Fixed syncInterval usage issue with multiprcoessing work pools. #
#              Logger and Pool class overrides were creating compound classes. #
#            - Added ConfigFile home to Python path to ensure search for local #
#              scripts are first priority, followed by existing paths.         #
#            - Set minimum ALFlib version dependency to 2.0.0                  #
#            - Altered 'ConfigFileLoader.distribute' method to leverage Logger #
#              to store last distribution details.                             #
#            - Set default ALFlog.exitReturnError based on use of syncInterval.#
#            - Removed e-mail options declaration section from Template Config #
#              file creation. Opting for use of 'ALFlib_env.py' instead.       #
#       Build: 1.4.0, March 2015                                               #
#            - Add Arcpy 'in_memory' object cleanup when sync interval is used.#
#            - Altered 'ConfigFileLoader.distribute' method to leverage new    #
#              'S3cmd.getInfo' retry logic. Also refined logic to tolerate a   #
#              delay in S3 upload file registration.                           #
#       Build: 1.3.0, October 2014                                             #
#            - Altered 'importArcpy', redirecting worker pool scratchspace     #
#              directory to live under current 'ScratchSpace' directory.       #
#            - Added 'Process ID' to details displayed by '_setupEnvironment'. #
#            - Altered 'version' and 'minALFlib' variables to reduce conflict  #
#              with 'from ALFprocessor import *' usage.                        #
#            - Added Keyword Argument and logSuccess support to 'retryIt' func.#
#            - Altered '_waitFormat' function to use larger time value when    #
#              countdown is greater or equal to divisor. Like 1 min vs.60 secs #
#            - Altered verbage of import failure message in 'importArcpy' func.#
#       Build: 1.2.1, July 2014                                                #
#            - Patched '_setupEnvironment' function to properly handle ALFmail #
#              options.                                                        #
#       Build: 1.2.0, May 2014                                                 #
#            - Added 'timeout' property to ConfigFile, allowing self timeout   #
#              checking for process. If processing time takes too long, a      #
#              timeout exception is thrown, terminating the process.           #
#            - Patched environment setup to allow version test for minimum     #
#              ALFlib and ALFprocessor, even when already present.             #
#            - Added support for setting E-mail parameters in ConfigFile.      #
#            - Enhanced Exception reporting for E-mail update.                 #
#       Build: 1.1.0, January 2014                                             #
#            - Altered to recursively create directory tree for Paths if they  #
#              do not exist. For 'work', 'log', and 'live' Paths.              #
#            - Updated 'ConfigFileLoader.logResults' to handle newline changes #
#              in 'ALFlog.log' function.                                       #
#            - Added 'Python' and 'Platform' identification reporting to       #
#              Activity Log.                                                   #
#            - Added Multiprocessing support for config files. Adding logic to #
#              support worker pool creation and asynchronous work assignment.  #
#              Added logic to 'importArcpy' func to create a Multiprocessing   #
#              'scratchPath' unique to each process, also setting              #
#              'arcpy.env.scratchWorkspace' to match.                          #
#            - Added logic to log any remaining arcpy messages on exit, if not #
#              otherwise trapped or displayed.                                 #
#            - Added logic to set arcpy.env.scratchWorkspace to dedicated      #
#              'ScratchSpace' folder in 'workPath'.                            #
#            - Added logic to 'ConfigFile.prepWorkspace' to support workspace  #
#              Directory deletion/creation.                                    #
#            - Enhanced error logging to include Trackeback details!           #
#            - Added 'retryIt' function.                                       #
#       Build: 1.0.1, May 2013                                                 #
#            - Patched issue applying user alterations to the 'work', 'live',  #
#              and 'log' Path variables in a configuration file when they are  #
#              set as globals.                                                 #
#            - Patched 'S3cmdObject.getInfo' logic to allow for 's3cmd info'   #
#              failure in some Python versions.                                #
#       Build: 1.0.0, April 2013                                               #
#                                                                              #
#  Depends on: ALFlib.py - v1.11+                                              #
#       Input: Filename of user-defined ALF configuration file to process.     #
################################################################################

#########################
# Import base libraries #
#########################

import atexit, datetime, multiprocessing, os, platform, shutil, sys, tempfile, time, threading, traceback

# Setup initial variables

_version = "1.7.0"
_creation = "October 2016"
_minALFlib = "2.1.0"
root, scriptName = os.path.split( os.path.realpath(__file__))
errLogFilename = os.path.join( root, scriptName.split( ".")[0] + ".err")

#
# Template Configuration file contents
#

configurationTemplate = """############################################################################################
#      Purpose: Aggregated Live Feed - 'ALFprocessor' feed configuration file
#  Description: <add your description here>
# Developed by: <add your name here>, <add your company name here>
# Date created: {0}
##########
#
# When altering: Keep in mind that the contents of this file are ingested by a Python
# Class at execution time, so please follow standard Python coding practices.
# For coding help, please see: http://docs.python.org/index.html
#

nickName = "{1}"    # Name used to identify routine for logging.

logRetention = 3    # Number of Months to keep log files.
                # Default is '3'

syncInterval = 0    # Update cycle time in minutes. A value other than 0
                # (Zero) allows execution to repeat using a timed cycle.
                # Default is 0 (off, one cycle then exit). Supports
                # fractional minutes. Ex: '2.5'
                # ALFlog.exitOnError is set to 'False' if syncInterval is set!

version = "1.0.0"        # Indicate version of this configuration file. Specify in
                # the form of: version = "<major>.<minor>.<bug-fix>"

# Change History
# v1.0.0, <your initials> - <description of change, like: Initial build>

minALFprocessor = "{2}"    # Indicate minimum version of 'ALFprocessor' required
                    # to process this configuration file. Specify in the form
                    #   of: minALFprocessor = "<major>.<minor>.<bug-fix>"

minALFlib = "{3}"    # Indicate minimum version of 'ALFlib' library required
                # by this configuration file. Specify in the form of:
                #   of: minALFlib = "<major>.<minor>.<bug-fix>"
                # If version-specific components of 'ALFlib' are not
                # required, set to empty string, None, or comment entire line.
                # Specify in the form of: minALFlib = ""
                #                     or: minALFlib = None

delayArcpyLoad = True # True or False to delay loading ArcPy
#minArcpy = "10.4" # Indicate minimum version of 'arcpy' to import for this
                # configuration file. Specify in the form
                #   of: minArcpy = "<major>.<minor>.<bug-fix/SP/Update>"
                # If 'arcpy' is NOT required or a delayed import is desired,
                # set to empty string, None, comment entire line, or use
                # 'delayArcpyLoad=True'.
                # Specify in the form of: minArcpy = ""
                #                     or: minArcpy = None
                # For delayed import, use global function 'importArcpy'.
                # Specify in the form of: importArcpy( [<minArcpy>="10.0.1"])
                #                     or: importArcpy( self.minArcpy)

timeout = 120    # Time, in minutes, to wait for routine to finish before throwing
                # a timeout exception.
                # Set to '0' or None for no timeout.
                # Default is '120'
#
##########
#
# Folder Paths support Relative, Absolute, and UNC file system paths.
# (if backslash required, remember to use double backslash '\\' in Python strings)
#

global livePath, logPath, workPath

workPath = "Work"        # Folder used for general processing.
logPath = "Logs"        # Folder used for activity and error log storage.
livePath = "Live"        # Shared folder where updated data is stored.
importPath = ""        # If required, specify the User-defined Python utility folder
                # where 'ALFlib.py' and other required scripts can be found.
#
##########
#
# Define Feed-specific variables and libraries here. From functions, access variables by
# using 'self.<variable>'. For libraries, define each as global and then import.
#
# The ALFprocessor imports the following libraries by default:
# (ALFlib, atexit, datetime, multiprocessing, os, platform, shutil, sys, time, traceback)
#

#
##########
#
# Define Feed-specific functions here. Be sure to include 'self' as first property.
# The function 'main' is required as a starting point for processing. Feel free to
# add your own functions and call then from 'main' to handle work as needed.
#
# Pre-Defined Local functions include (must reference using 'self.'):
#   prepWorkspace( <directory>, <gdbName>[, <recreate>=False])
#      "Create or Re-create File Geodatabase or workspace Directory.
#       Returns a string containing the Workspace path."
#
#   createSpatialReference( <spatialReference>)
#      "Create a Spatial Reference object from a projection number, string, existing
#       dataset or projection file.
#       Returns the arcpy.SpatialReference object."
#
#   createFeatureDataset( <workspace>, <dataset>[, <spatialReference>=""])
#      "Create a Feature Dataset within the Workspace. <spatialReference> can
#       be an existing Spatial Reference object or, a projection number; string; or filename.
#       Returns a string containing the Workspace path."
#
#   createBoundaryLayer( <workspace>, <minX>, <minY>, <maxX>, <maxY>[, spatialReference=""])
#      * NOTE * Deprecation planned at ALFprocessor v2.0.0
#      "Create a Polygon Featureclass containing a single feature that reflects the data extent
#       provided by the min and max extent values. Use to generate a boundary layer within a
#       Feature Dataset that includes other Live data, setting the data extent for all."
#
#   addRegistrationFeatures( <featureclass>, <minX>, <minY>, <maxX>, <maxY>)
#      * NOTE * Deprecation planned at ALFprocessor v2.0.0
#      "Add Registration Features to the Lower-Left and Upper-Right of the Featureclass using the
#       min and max extent values provided. Sets the data extent for the Featureclass."
#
#   logResults( <results>)
#      "Log 'arcpy.Result' object (or other) content to ALFlog. Use this to record details from
#       arcpy and other calls.
#       Usage: 'self.logResults( arcpy.CreateFileGDB_management( 'mydata', 'my.gdb', 'CURRENT'))'"
#
#   distribute( <source>, <destination>[, <expiration>=datetime.timedelta()[, <S3cmdObject>=None
#            [, <reducedRedundancy>=False[, <makePublic>=False[, <category>=""]]]])
#      "Manage distribution of an archive file or other to UNC; local; or S3 path. Records creation
#       date and file size details identified by <category> for comparison during next copy operation.
#       If destination does not match recorded details, it is assumed to be managed by another
#       system. In this case, check creation date to see if it exceeds <expiration> time delta. If
#       so, it is probably safe to take over distribution management. If destination is 'S3:', the
#       ALFlib.S3cmd object; reduced redunacy; and make public options can also be included. Be sure
#       that <destination> includes a trailing '/' if location is a 'S3:' directory and not a file.
#       Returns True when source has been copied, False when nothing is copied, and an Exception
#       is raised when a critical issue is detected."
#
#       See 'http://docs.python.org/2/library/datetime.html#timedelta-objects' for time delta use.
#
# Pre-Defined Global functions and objects include:
#   importArcpy( [<minArcpy>=None[, importTrys=3[, importWait=5[, product=None]]]])
#      "Initiate import of Arcpy. <minArcpy> accepts String in the form of: '<major>.<minor>.<bug>'
#       <product> accepts a String that indicates what ArcGIS product level to load, can be: 'arcview',
#       'arceditor', 'arcinfo', 'arcengine', or'arcenginegeodb'. Defaults to loading product level
#       set by 'ALFarcpy_Product' Environment Varible, falling back to the product install.
#       Returns version of Arcpy that was imported."
#
#   minVersion( [<major>=0[, <minor>=0[, <bug>=0]]])
#      "Check version of ALFprocessor script. <major>, <minor>, and <bug> are optional values that
#       reflect the minimum version level you require.
#       Returns True if the version is at least the minimum specified, False otherwise."
#
#   minArcpyVersion( [<major>=0[, <minor>=0[, <bug>=0]]])
#      "Check version of Arcpy. <major>, <minor>, and <bug> are optional values that
#       reflect the minimum version level you require.
#       Returns True if the version is at least the minimum specified, False otherwise."
#
#   retryIt( <function>[, <args>=()[, <attempts>=3[, <pause>=2[, cancelRetry=""|["", ...][, logSuccess=True[, kwargs={4}]]]]]])
#      "Retry call to a Function or Method. Employs call to ALFlib.retryIt and includes 'retryHook'
#       to handle recording of any arcpy specific error messages.
#       Returns outcome of <function> to calling routine."
#
#   ALFlog: The 'ALFlib.Logger' object created by the ALFprocessor to handle log operations
#           for this feed routine. See: 'ALFlib.py -h Logger' for full features
#
# And don't forget the available functions and classes found in the 'ALFlib' library!
# See: 'ALFlib.py -h' for full details

import ALFlib                          # For intellisense access to main library during development
from ALFlib import Logger as ALFlog    # For intellisense access to ALFlog during development
from ALFprocessor import *             # For intellisense access to Global objects during development

def main( self):
    # Start of Main feed logic
    pass
"""

#
# Custom Exceptions
#

class Flag( Exception):
    """Class: Flag( <flag text>)

    Custom Base Exception that can be used to derive other "Flag" exceptions.
    This would allow for condition notation without triggering a true Exception.
    It would also allow for Logger to flag a run without recording as a failure.

    Where:
        <flag text> = (optional) text description of the flagged event.
"""
    def __init__( self, message='General'):
        BaseException.__init__( self, message)

class NoDataFlag( Flag):
    """Class: NoDataFlag( <flag text>)

    Custom Flag Exception that can be Raised when No Data was available for processing.

    Where:
        <flag text> = (optional) text description of the flagged event.
"""

    def __init__( self, message='No Data available'):
        BaseException.__init__( self, message)

class NoDataUpdatesFlag( Flag):
    """Class: NoDataUpdatesFlag( <flag text>)

    Custom Flag Exception that can be Raised when No Data Updates were made.

    Where:
        <flag text> = (optional) text description of the flagged event.
"""

    def __init__( self, message='No Data updates'):
        BaseException.__init__( self, message)

#
# Check for and process input argument(s)
#

def _getArgs():
    """Internal function, not intended for general consumption!"""
    global configFilename, configName, errLogFilename, home
    showUsage = False
    createTemplate = False
    configName = ""
    home = "."
    outcome = 1

    if len(sys.argv) < 2:
        showUsage = True
    else:
        for arg in sys.argv[1:]:
            if arg.startswith("-"):
                if arg.lower() == "-c":
                    createTemplate = True
                elif arg.lower() == "-h":
                    showUsage = True
                else:
                    print( "\n\a * Invalid option '{0}' *".format( arg))
            else:
                # Use Argument 1 to define Configuration file to use
                if not configName:
                    configFilename = os.path.realpath( arg)
                    home, configName = os.path.split( configFilename)
                    if "." not in configName and os.access( home, os.F_OK):
                        # No extension specified, go find the right file
                        for file in os.listdir( home):
                            if file.startswith( configName + ".") and file.lower().endswith( ".cfg"):
                                configFilename += file[-4:]
                                configName += file[-4:]
                                break

                        # Did we find a 'CFG' file?
                        if "." not in configName:
                            configFilename += ".cfg"
                            configName += ".cfg"

        if configName:
            if not os.access( home, os.F_OK):
                showUsage = True
                createTemplate = False
                print( "\n\a * Unable to locate path to <configFile>: '{0}' *".format( arg))
            elif not configName.lower().endswith( ".cfg"):
                showUsage = True
                print( "\n\a * Invalid extension for <configFile>: '{0}'\n   Filename must end with '.cfg' *".format( arg))
            elif not os.access( configFilename, os.F_OK):
                if createTemplate:
                    createTemplate = False
                    nickname = os.path.basename( configFilename).split( ".")[0]

                    try:
                        with open( configFilename, 'wb') as oFP:
                            oFP.write( configurationTemplate.format( datetime.date.today().strftime( "%b %d, %Y"), nickname, _version, _minALFlib, "{}"))

                    except Exception as e:
                        raise Exception( "\a * Failed to create Template file: {0}".format( e))

                    print( "\n * Successfully created template configuration file:\n   '{0}'".format( configFilename))
                    outcome = 0
                    if not showUsage:
                        return False, 0
                else:
                    showUsage = True
                    print( "\n\a * Unable to locate <configFile>: '{0}' *".format( arg))
            else:
                if createTemplate:
                    print( "\n * Configuration file already exists, template creation ignored!")
                    createTemplate = False

    # Setup usage details and display if required

    if createTemplate:
        print( "\n\a * Forget something?")

    if showUsage or createTemplate:
        verText = "{0}, v{1}, {2}, Paul Dodd - esri".format( scriptName, _version, _creation)
        print( """
{0}
{1}

Aggregated Live Feed processor tool.

Usage: {2} -h | [-c] <configFile>

              -h = Show this usage.
              -c = Create template <configFile> if it doesn't
                   already exist.
    <configFile> = File path and/or name of ALF configuration
                   file to process. Will only read file with
                   '.cfg' extension, specification of which is
                   not required here.
""".format( verText, "-" * len( verText), scriptName))
        return False, outcome
    else:
        # Navigate to config file location as root starting point
        os.chdir( home)
        # v1.5.0 - Add Home path to Python search path
        if home not in sys.path:
            sys.path.insert( 0, home)

    errLogFilename = os.path.join( home, configName.split( ".")[0] + ".err")

    return True, 0

###############################
# Load config file if present #
###############################

def _loadConfigFile( configFilename):
    """Internal function, not intended for general consumption!"""
    class ConfigFileLoader( object):
        """Class provides code issolation for configFile contents"""

        #####################################################
        # Prepare Workspace (File Geodatabase or Directory) #
        #####################################################

        def prepWorkspace( self, directory, gdbName, recreate=False):
            """Create or Re-create File Geodatatbase or workspace Directory"""

            workspace = os.path.join( directory, gdbName)
            fileExt = os.path.splitext( gdbName)[1].lower()

            print( "\nPreparing Workspace...")
            ALFlog.log( "  <directory>: '{0}'\n    <gdbName>: '{1}'\n   <recreate>: {2}\n".format( directory, gdbName, recreate))

            if os.access( workspace, os.F_OK):
                if recreate:
                    try:
                        if os.path.isdir( workspace):
                            if fileExt == ".gdb":
                                # Delete file-based Geodatabase
                                print( "  Removing File Geodatabase...")
                            else:
                                # Delete workspace Directory
                                print( "  Removing workspace Directory...")
                            shutil.rmtree( workspace)
                        else:
                            print( " * Caution * Unable to remove and recreate workspace: not a File Geodatabase or Directory!")
                            recreate = False

                    except Exception as e:
                        raise Exception( "Failed to remove existing workspace: {0}".format( e))
            else:
                recreate = True

            if recreate:
                try:
                    if not os.access( workspace, os.F_OK):
                        if fileExt == ".gdb":
                            # Create File Geodatabase
                            print( "  Creating File Geodatabase...")
                            arcpy.CreateFileGDB_management( directory, gdbName, 'CURRENT')
                        else:
                            print( "  Creating workspace Directory...")
                            os.makedirs( workspace)
                    else:
                        raise Exception( "Workspace already exists: '{0}'".format( workspace))

                except Exception as e:
                    raise Exception( "Failed to create workspace: {0}".format( e))

            ALFlog.log( "     Returned: {0}".format( workspace))

            return workspace

        #####################################
        # Create a Spatial Reference object #
        #####################################

        def createSpatialReference( self, spatialReference):
            if not spatialReference:
                return ""

            if isinstance( spatialReference, arcpy.SpatialReference) or type( spatialReference) == 'geoprocessing spatial reference object':
                return spatialReference

            print( "\n  Creating Spatial Reference...")
            ALFlog.log( "    <spatialReference>: '{0}'".format( spatialReference))
            if hasattr( spatialReference, "isdigit"):
                # Is a string
                if os.access( spatialReference, os.F_OK) and spatialReference.lower().endswith( ".prj"):
                    # Create from projection File
                    sr = arcpy.SpatialReference( spatialReference)
                elif arcpy.Exists( spatialReference):
                    # Create from Dataset object (Shapefile, Featureclass, FeatureDataset, ...)
                    sr = arcpy.Describe( spatialReference).spatialReference
                else:
                    # Create from Projection string
                    sr = arcpy.SpatialReference()
                    sr.loadFromString( spatialReference)
            else:
                # Is a number?
                sr = arcpy.SpatialReference()
                sr.factoryCode = spatialReference
                sr.create()

            ALFlog.log( "              Returned: arcpy.SpatialReference object( srid:{0}, name:'{1}')".format( sr.factoryCode, sr.name))

            return sr

        ###################################
        # Create Feature Dataset function #
        ###################################

        def createFeatureDataset( self, workspace, dataset, spatialReference=""):
            """Create Feature Dataset using optional Spatial Reference (supply projection number, dataset, projection filename, or string)"""

            print( "\nCreating Feature Dataset...")
            ALFlog.log( "           <workspace>: '{0}'\n             <dataset>: '{1}'\n    <spatialReference>: '{2}'\n".format( workspace, dataset, spatialReference))

            try:
                if not workspace:
                    raise Exception( "'workspace' cannot be empty!")
                if not dataset:
                    raise Exception( "'dataset' cannot be empty!")

                # Create Feature Dataset using Spatial Reference
                arcpy.CreateFeatureDataset_management( workspace, dataset, self.createSpatialReference( spatialReference))

            except Exception as e:
                raise Exception( "Failed to create dataset: {0}".format( e))

            result = os.path.join( workspace, dataset)
            ALFlog.log( "              Returned: {0}".format( result))

            return result

        #####################################
        # Create Data Extent Boundary Layer #
        #####################################

        def createBoundaryLayer( self, workspace, minX, minY, maxX, maxY, spatialReference=""):
            """Create Boundary Layer using min and max extent values to generate a feature to match."""

            print( "\nCreating Boundary Layer...")
            print( "\n * NOTICE * This function 'createBoundaryLayer' is slated for Deprecation as of ALFprocessor v2.0.0!\n\a")
            ALFlog.log( "           <workspace>: '{0}'\n                <minX>: '{1}'\n                <minY>: '{2}'\n                <maxX>: '{3}'\n                <maxY>: '{4}'\n    <spatialReference>: '{5}'\n".format( workspace, minX, minY, maxX, maxY, spatialReference))
            iFC = None
            featureclassName = "Boundary"

            try:
                if not workspace:
                    raise Exception( "'workspace' cannot be empty!")
                if not arcpy.Exists( workspace):
                    raise Exception( "Workspace '{0}' does not exist!".format( workspace))
                if not (minX and minY and maxX and maxY):
                    raise Exception( "min and max Extent values cannot be empty!")

                ALFlog.log( "  Creating Polygon Featureclass...")
                self.logResults( arcpy.CreateFeatureclass_management( workspace, featureclassName, "POLYGON", None, None, None, self.createSpatialReference( spatialReference)))

                featureclass = workspace + os.sep + featureclassName

                ALFlog.log( "  Opening Insert Cursor...")
                iFC = arcpy.InsertCursor( featureclass)

                # Create new row
                newRow = iFC.newRow()

                # Add Shape
                newRow.setValue( "Shape", arcpy.Array([
                    arcpy.Point( minX, minY),
                    arcpy.Point( minX, maxY),
                    arcpy.Point( maxX, maxY),
                    arcpy.Point( maxX, minY),
                    arcpy.Point( minX, minY)
                    ]))

                ALFlog.log( "  Inserting Feature...")
                iFC.insertRow( newRow)

                del iFC

            except Exception as e:
                del iFC
                raise Exception( "Failed to create Boundary Layer: {0}".format( e))

        #############################################
        # Add Registration Features to Featureclass #
        #############################################

        def addRegistrationFeatures( self, featureclass, minX, minY, maxX, maxY):
            """Add Registration Features to Featureclass using min and max extent values"""

            print( "\nAdding Registration Features...")
            print( "\n * NOTICE * This function 'addRegistrationFeatures' is slated for Deprecation as of ALFprocessor v2.0.0!\n\a")
            ALFlog.log( "  <featureclass>: '{0}'\n          <minX>: '{1}'\n          <minY>: '{2}'\n          <maxX>: '{3}'\n          <maxY>: '{4}'\n".format( featureclass, minX, minY, maxX, maxY))
            iFC = None

            try:
                if not featureclass:
                    raise Exception( "'featureclass' cannot be empty!")
                if not arcpy.Exists( featureclass):
                    raise Exception( "Featureclass '{0}' does not exist!".format( featureclass))
                if not (minX and minY and maxX and maxY):
                    raise Exception( "min and max Extent values cannot be empty!")

                shapeType = arcpy.Describe( featureclass).shapeType
                xyTolerance = 50 * arcpy.Describe( featureclass).spatialReference.XYTolerance

                ALFlog.log( "  Opening Insert Cursor...")
                iFC = arcpy.InsertCursor( featureclass)

                # Create new row
                newRow = iFC.newRow()

                # Create shape arrays
                lowerLeft = arcpy.Array()
                upperRight = arcpy.Array()

                if shapeType.find( "Point") > -1:
                    # Setup lower left Shape
                    lowerLeft.add( arcpy.Point( minX, minY))

                    # Setup upper right Shape
                    upperRight.add( arcpy.Point( maxX, maxY))

                elif shapeType == "Polyline":
                    # Setup lower left Shape
                    lowerLeft.add( arcpy.Point( minX, minY))
                    lowerLeft.add( arcpy.Point( minX + xyTolerance, minY + xyTolerance))

                    # Setup upper right Shape
                    upperRight.add( arcpy.Point( maxX - xyTolerance, maxY - xyTolerance))
                    upperRight.add( arcpy.Point( maxX, maxY))

                elif shapeType == "Polygon":
                    # Setup lower left Shape
                    lowerLeft.add( arcpy.Point( minX, minY))
                    lowerLeft.add( arcpy.Point( minX, minY + xyTolerance))
                    lowerLeft.add( arcpy.Point( minX + xyTolerance, minY + xyTolerance))
                    lowerLeft.add( arcpy.Point( minX + xyTolerance, minY))
                    lowerLeft.add( arcpy.Point( minX, minY))

                    # Setup upper right Shape
                    upperRight.add( arcpy.Point( maxX - xyTolerance, maxY - xyTolerance))
                    upperRight.add( arcpy.Point( maxX - xyTolerance, maxY))
                    upperRight.add( arcpy.Point( maxX, maxY))
                    upperRight.add( arcpy.Point( maxX, maxY - xyTolerance))
                    upperRight.add( arcpy.Point( maxX - xyTolerance, maxY - xyTolerance))

                else:
                    print( " * Cannot add Registration to unknown Shape Type: {0}".format( shapeType))
                    return

                ALFlog.log( "  Inserting Upper-Right Feature...")
                newRow.setValue( "Shape", lowerLeft)
                iFC.insertRow( newRow)

                ALFlog.log( "  Inserting Upper-Right Feature...")
                newRow.setValue( "Shape", upperRight)
                iFC.insertRow( newRow)

                del iFC, newRow, lowerLeft, upperRight
                return True

            except Exception as e:
                del iFC
                raise Exception( "Failed to create Boundary Layer: {0}".format( e))

        ######################################
        # Log results of arcpy function call #
        ######################################

        def logResults( self, results="", severity=2):
            """Report Messages (arcpy or other) to ALFlog.
    Where:
         <results> = (optional) Text or specific arcpy.Result.
                     By default, function will check arcpy Messages

        <severity> = (optional) arcpy.Result severity.
                     Where: 0 = report all arcpy messages
                            1 = report only when warnings or errors exist
                  (default) 2 = report only when errors exist"""

            # Report existing Messages, ignore otherwise
            try:
                if "arcpy" in globals() and isinstance( results, arcpy.Result):
                    if arcpy.GetMaxSeverity() >= severity:
                        ALFlog.log( "\n-------------")
                        ALFlog.log( results.getMessages())
                        ALFlog.log( "-------------")
                elif results:
                    ALFlog.log( "\n-------------")
                    ALFlog.log( results)
                    ALFlog.log( "-------------")
                else:
                    if "arcpy" in globals() and arcpy.GetMaxSeverity() >= severity:
                        ALFlog.log( "\n-------------")
                        if arcpy.GetMessageCount():
                            ALFlog.log( arcpy.GetMessages())
                        else:
                            ALFlog.log( " * No results available *")
                        ALFlog.log( "-------------")
            except Exception as e:
                print( " * Ignoring 'logResults' issue: {0}".format( e))

        ###############################
        # Manage archive distribution #
        ###############################

        def distribute( self, source, destination, expiration=datetime.timedelta(), S3cmdObject=None, reducedRedundancy=False, makePublic=False, category=""):
            desc = " '{0}' ".format( category) if category else " "
            print( "\nStarting{0}distribution...".format( desc))

            #####################
            # Private functions #
            #####################

            def getEpoch( timedelta):
                return (timedelta.microseconds + (timedelta.seconds + timedelta.days * 24 * 3600) * 10**6) / 10**6

            # Get Destination details, if any!
            def getDestDetails( attempts=1, pause=10):

                # Returns Touple containing Epoch and Size of destination

                destFile = os.path.join( destination, sourceFilename)

                if destIsS3:
                    destFile = destFile.replace( "\\", "/")

                    # Check for S3 object
                    try:
                        result = S3cmdObject.getInfo( destFile, verbose=False, attempts=attempts, pause=pause)
                    except:
                        result = None

                    if result:
                        if result.objectType == "file":
                            # Calc Time Delta of file u sing Epoch, then compute UTC Total Seconds
                            return getEpoch( result.lastModified - epoch), result.size
                else:
                    if os.access( destFile, os.F_OK):
                        if os.path.isfile( destFile):
                            return int( os.path.getmtime( destFile)), os.path.getsize( destFile)

                return 0, 0

            #####

            if not source:
                raise Exception( "Unable to copy - unspecified 'source'")
            if not os.access( source, os.R_OK):
                raise Exception( "Unable to copy - cannot locate 'source': '{0}'".format( source))
            if not os.path.isfile( source):
                raise Exception( "Unable to copy - 'source' must be a file: '{0}'".format( source))

            if not destination:
                raise Exception( "Unable to copy - unspecified 'destination'")

            destIsS3 = False
            if destination[:3].upper() == "S3:":
                destIsS3 = True
                # Verify S3cmd object and create if not!
                if not isinstance( S3cmdObject, ALFlib.S3cmd):
                    S3cmdObject = ALFlib.S3cmd( verbose=False)

            if not isinstance( expiration, datetime.timedelta):
                expiration = datetime.timedelta()
            expirationDelta = getEpoch( expiration)

            epoch = datetime.datetime.utcfromtimestamp( 0)

            nowEpoch = getEpoch( datetime.datetime.utcnow() - epoch)

            sourceEpoch = int( os.path.getmtime( source))
            sourceSize = os.path.getsize( source)
            sourceFilename = os.path.split( source)[1]

            lastEpoch = 0
            lastSize = 0
            detail = {}

            destEpoch, destSize = getDestDetails()

            # Get last distribution details
            try:
                detail = ALFlog.loadDetail( category)

            except Exception as e:
                sys.stderr.write( "\n * IGNORED - {0} *\n".format( e))

            managementRecord = os.path.join( workPath, "LastDistribution.txt")

            if detail:
                # Last Distribution details stored in Logger Details file!
                value = detail.get( "lastEpoch", 0)
                if value and (isinstance( value, int) or isinstance( value, long)):
                    lastEpoch = value

                value = detail.get( "lastSize", 0)
                if value and (isinstance( value, int) or isinstance( value, long)):
                    lastSize = value

            elif os.access( managementRecord, os.F_OK):
                try:
                    # Load last distribution details
                    with open( managementRecord, "r") as iFP:
                        for record in iFP.readlines():
                            data = record.split( "#")[0].strip().split( "=")
                            if len( data) >= 2:
                                if data[0] == "lastEpoch" and data[1].isdigit():
                                    lastEpoch = int( data[1])
                                elif data[0] == "lastSize" and data[1].isdigit():
                                    lastSize = int( data[1])

                except Exception as e:
                    print( " * Warning - Failed to read from '{0}' detail file: '{1}'".format( managementRecord, e))

            # Need to copy?
            if not (destEpoch or destSize):
                print( "  Destination{0}does not exist...".format( desc))
            elif (lastEpoch or lastSize) and (lastEpoch <> destEpoch or lastSize <> destSize):
                # Last upload was successful but the current Destination file is not owned by me
                ALFlog.archive( "  Destination{0}is NOT managed by me...".format( desc), True)
                if (destEpoch + expirationDelta) > nowEpoch:
                    ALFlog.archive( "    Not time to take over!", True)
                    return
                else:
                    ALFlog.archive( "    Grace period has expired, time to take over!", True)
            else:
                ALFlog.archive( "  Destination{0}is managed by me...".format( desc), True)
                if destEpoch >= sourceEpoch and destSize == sourceSize:
                    ALFlog.archive( "  Destination matches Source, no need to copy!", True)
                    return

            print( "  Starting copy...")

            # Perform copy based on destination type
            try:
                if destIsS3:
                    S3cmdObject.putFile( source, destination, reducedRedundancy=reducedRedundancy, makePublic=makePublic, verbose=False)
                else:
                    ALFlib.copyFiles( source, destination, overwrite=True, verbose=False)

            except Exception as e:
                raise Exception( "Failed to distribute '{0}': '{1}'".format( source, e))

            print( "  Verifying details...")
            destEpoch, destSize = getDestDetails( attempts=3)    # Get updated details

            if not (destEpoch or destSize):
                print( "\n ***********\n * Warning * Failed to retrieve confirmation of upload!\n ***********\n")
                ALFlog.archive( "  * Failed Upload Confirmation!", False)

            try:

                detail[ "lastEpoch"] = destEpoch
                detail[ "lastEpochDate"] = "UTC {0}".format( datetime.datetime.utcfromtimestamp( destEpoch))
                detail[ "lastSize"] = destSize

                ALFlog.saveDetail( detail, category)

                if os.access( managementRecord, os.F_OK):
                    os.remove( managementRecord)

            except Exception as e:
                print( "\n * Warning - Failed to update distribution details: '{0}'\n".format( e))

            return True

        #######

        if not os.access( configFilename, os.R_OK):
            raise Exception( " * Error * Unable to access <configFile> '{0}'!".format( configFilename))

        # Load config file
        try:
            # Content loaded will be local to this Class
            execfile( configFilename)    # configFilename MUST be defined before load process,
            #                               or class user-defined methods will NOT be accessible!

        except Exception as e:
            _logError( " * Error * Failure during configFile load: {0}".format(e))
            raise

    return ConfigFileLoader()

def importArcpy( minArcpy=None, importTrys=3, importWait=5, product=None, scratchPath=None):
    """Import Arcpy ensuring minimum version is loaded.

    Returns:
        Version of arcpy and description
        Or an Exception is raised if arcpy version is not minumum or if it
        fails to load.

    Where:
         <minArcpy> = (optional) String containing 'major.minor.bug' details for
                       minimum version to load.
                       Default is None, accept any version available

        <importTrys> = (optional) Number of import retrys to attempt on failure.
                       Default is 3

        <importWait> = (optional) Number of seconds to wait between attempts.
                       Default is 5 seconds

           <product> = (optional) String indicating which ArcGIS product should
                       be loaded. Can be 'arcview', 'arceditor', 'arcinfo',
                       'arcengine', or 'arcenginegeodb'
                       Default is No specific product, load the installed default.

       <scratchPath> = (optional) String indicating desired path to a Scratch
                       Workspace. Can be relative to 'workPath' or real path.
                       Default is 'ScratchSpace' folder relative to 'workPath'.
"""
    # Import ArcPy library, retry if failure to initialize

    global arcpy, arcpyVer

    arcpyVer = ""

    if "arcpy" in globals():
        print( "\nImporting ArcPy...already imported!")
    else:
        print( "\nImporting ArcPy...")

        try:
            # Setup Scratch Workspace folder first...
            if scratchPath:
                scratchPath = os.path.realpath( scratchPath)
            else:
                scratchPath = os.path.join( workPath, "ScratchSpace")

            if isinstance( ALFlog, ALFlib.dummyLogger):
                scratchPath = os.path.join( scratchPath, multiprocessing.current_process().name)

            ALFlog.log( " ScratchSpace: {0}".format( scratchPath))

            if os.path.exists( scratchPath):
                shutil.rmtree( scratchPath, True)

            tries = 3
            while tries:
                tries -= 1
                try:
                    if os.access( scratchPath, os.F_OK):
                        os.environ[ "TMPDIR"] = tempfile.gettempdir()   # v1.5.0 - Set Temporary Directory value to current System Temp (NOT USED by Arcpy, but is first default for Python)
                        os.environ[ "TEMP"] = scratchPath   # v1.5.0 - Set 'TEMP' directory value to discrete path, increasing multi-session and multi-processing reliability of Arcpy
                        os.environ[ "TMP"] = scratchPath    # v1.5.0 - Set 'TEMP' directory value to discrete path, increasing multi-session and multi-processing reliability of Arcpy
                        break

                    sys.stderr.write( "\n Creating ScratchSpace...")
                    os.makedirs( scratchPath)
                    ALFlog.log( "Success!")
                    tries += 1 # v1.7.0 - Increment tries to ensure temporary environment variables are set if last try is successful!
                except Exception as e:
                    ALFlog.log( "Failed: {0}\n{1}".format( e, " * Retrying..." if tries else " * Giving up!"))
                    if tries:
                        time.sleep( 2.5)

        except Exception as e:
            ALFlog.log( " * Failed to setup ScratchSpace: {0}".format( e))

        # Validate specific ArcGIS 'product' selection
        if not product:
            # As a Default, use Environment Variable if it exists
            product = os.environ.get( "ALFarcpy_Product", None)

        if product:
            if not (isinstance( product, basestring) or product.lower() in [ 'arcview', 'arceditor', 'arcinfo', 'arcengine', 'arcenginegeodb']):
                ALFlog.log( " * Unknown product specified, ignoring: {0}".format( product))
                product = None
            else:
                product = product.lower()

        while importTrys:
            try:
                # Load specified ArcGIS product first...
                if product and product not in globals():
                    try:    # v1.7.0
                        __import__( product)
                    except Exception as e:
                        ALFlog.log( " * Failed to load '{0}' product, using default install. Error: {1}".format( product, e))

                import arcpy
                # Set Script arguments
                arcpy.gp.logHistory = False        # Turn off GP function logging
                arcpy.env.overwriteOutput = True    # Allow GP commands to overwrite GDB content

                try:
                    arcpy.env.scratchWorkspace = scratchPath
                    arcpy.env.workspace = scratchPath   # Set default Workspace too, v1.7.0
                except Exception as e:
                    ALFlog.log( " * Unable to set scratch workspace: {0}".format( e))

                if hasattr( ConfigFile, "outputTR") and ConfigFile.outputTR:
                    # Set Tranformation
                    arcpy.env.geographicTransformations = ConfigFile.outputTR

                break

            except Exception as e:
                importTrys -= 1
                _logError( "* Failed to import 'arcpy' library: {0}".format( e))
                if importTrys:
                    if importWait:
                        print( "Waiting {0} seconds...".format( importWait))
                        time.sleep( importWait)
                    print( "Retrying...")
                else:
                    raise Exception( "Failed to import 'arcpy', giving up...")

    if hasattr( arcpy, "GetInstallInfo"):
        arcpyVer = (arcpy.GetInstallInfo()["Version"] + "." + arcpy.GetInstallInfo()["SPNumber"]).strip(".N/A")

        # Verify arcpy version required by configuration file
        if not (arcpyVer and eval( "minArcpyVersion( {0})".format( str( minArcpy).replace(".", ",")))):
            del arcpy
            raise Exception( "Found incompatible version of 'arcpy', '{0}' requires at least v{1} *".format( configName, minArcpy))
        else:
            ALFlog.log( "        arcpy: v{0}, '{1}'".format( arcpyVer, arcpy.ProductInfo()))

    return arcpyVer

def _logError( message, showError=True):
    """Internal function, not intended for general consumption!"""
    # Record Errors to Non-ALFlib Log file when ALFlog not available!

    if showError:
        print( message)

    oFP = False

    try:
        if "ALFlog" not in globals():
            oFP = open( errLogFilename, "ab")
            oFP.write( "{0} : {1}\n".format( datetime.datetime.now().strftime( "%c"), message))
    except Exception as e:
        print( " * Failed to write Error Log:\n   '{0}' *".format( e))
    finally:
        if oFP:
            oFP.close()

# Report if version is at least the requested minimum
def minVersion( major=0, minor=0, bug=0):
    """Check Minimum ALFprocessor Version.

    Returns:
        True or False

    Where:
        <major> = (optional) Major version number
                  Default is zero

        <minor> = (optional) Minor version number
                  Default is zero

          <bug> = (optional) Bug level of version number
                  Default is zero
"""
    if major and hasattr( major, "isdigit") and major.isdigit():
        major = int(major)

    if minor and hasattr( minor, "isdigit") and minor.isdigit():
        minor = int(minor)

    if bug and hasattr( bug, "isdigit") and bug.isdigit():
        bug = int(bug)

    try:
        vMajor, vMinor, vBug = _version.split( ".")
        vMajor = int(vMajor)
        vMinor = int(vMinor)
        vBug = int(vBug)

        return (vMajor > major or (vMajor == major and \
            (vMinor > minor or (vMinor == minor and vBug >= bug))))
    except:
        return False

# Report if version of arcpy is at least the requested minimum
def minArcpyVersion( major=0, minor=0, bug=0):
    """Check Minimum arcpy Version.

    Returns:
        True or False

    Where:
        <major> = (optional) Major version number
                  Default is zero

        <minor> = (optional) Minor version number
                  Default is zero

          <bug> = (optional) Bug level of version number
                  Default is zero
"""
    if major and hasattr( major, "isdigit") and major.isdigit():
        major = int(major)

    if minor and hasattr( minor, "isdigit") and minor.isdigit():
        minor = int(minor)

    if bug and hasattr( bug, "isdigit") and bug.isdigit():
        bug = int(bug)

    try:
        version = [0,0,0]
        if arcpyVer:
            index = 0
            for dot in arcpyVer.split( "."):
                version[ index] = int( dot)
                index += 1

        return (version[ 0] > major or (version[ 0] == major and \
            (version[ 1] > minor or (version[ 1] == minor and version[ 2] >= bug))))
    except:
        return False

def _waitFormat( seconds):
    """Internal function, not intended for general consumption!"""
    output = ""
    sep = ""

    for verbage, divisor in [["day", 86400], ["hour", 3600], ["min", 60], ["sec", 1]]:
        whole = 0
        if seconds >= divisor:
            whole = int( seconds / divisor)
            seconds -= whole * divisor
            if whole:
                if whole > 1:
                    verbage += "s"
                output += sep + "{0} {1}".format( whole, verbage)
                sep = ", "
    return output

def _waitInterval( startCycle, intervalMinutes):
    """Internal function, not intended for general consumption!"""
    # Wait for interval time to elapse

    startCycle -= datetime.timedelta( microseconds=startCycle.microsecond)

    endCycle = datetime.datetime.now()
    endCycle -= datetime.timedelta( microseconds=endCycle.microsecond)

    waitDelta = (startCycle + datetime.timedelta( minutes=intervalMinutes)) - endCycle
    waitSeconds = (waitDelta.days * 86400) + waitDelta.seconds

    message = ""

    lastModified = os.stat( configFilename).st_mtime

    while (waitSeconds > 0):
        message = "Next cycle in {0}...".format( _waitFormat( waitSeconds))
        sys.stdout.write( message + " \r")
        sys.stdout.flush()

        if (waitSeconds - 10) > 10:
            delay = 10
        elif waitSeconds > 10:
            delay = waitSeconds - 10
        else:
            delay = 1

        time.sleep( delay)
        waitSeconds -= delay

        # Clear last message text
        sys.stdout.write( " " * len( message) + "\r")

        # Check for update to Config File
        if not lastModified == os.stat( configFilename).st_mtime:
            print( " * Detected Config file change - Exit Cycle Delay *\n")
            waitSeconds = 0

        sys.stdout.flush()

def _setupEnvironment():
    """Internal function, not intended for general consumption!"""
    # Setup working environment based on configuration read.

    global livePath, logPath, syncInterval, processTimeout, workPath

    if not os.access( configFilename, os.F_OK):
        if 'ConfigFile' in globals():
            _logError( " * Missing Config file:\n   '{0}'\n   Using cached Config! *".format( configFilename))
        else:
            raise Exception( " * Missing Config file:\n   '{0}' *".format( configFilename))
    else:
        global ConfigFile

        if not 'ConfigFile' in globals():
            # Load current configuration
            ConfigFile = _loadConfigFile( configFilename)

        # Set working variables
        nickName = getattr( ConfigFile, "nickName", configName.split( ".")[0])
        logRetention = getattr( ConfigFile, "logRetention", 3)
        workPath = os.path.realpath( getattr( ConfigFile, "workPath", globals().get( "workPath", "Work")))
        logPath = os.path.realpath( getattr( ConfigFile, "logPath", globals().get( "logPath", "Logs")))
        livePath = os.path.realpath( getattr( ConfigFile, "livePath", globals().get( "livePath", "Live")))
        importPath = getattr( ConfigFile, "importPath", "")
        syncInterval = getattr( ConfigFile, "syncInterval", 0)

        # v1.2.0, added 'processTimeout' logic
        defaultTimeout = 120
        comment, displayComment = "", True

        if not hasattr( ConfigFile, "timeout"):
            processTimeout = defaultTimeout
            comment = "\n * CAUTION * No process 'timeout' specified in Config file,\n             the {0} minute DEFAULT has been applied!".format( processTimeout)
        else:
            processTimeout = getattr( ConfigFile, "timeout", 0)

        if not processTimeout:
            comment, displayComment = "\n * Process 'timeout' disabled...", False
            processTimeout = None
        elif (isinstance( processTimeout, int) or isinstance( processTimeout, long) or isinstance( processTimeout, float)) and processTimeout >= 0.0:
            if not comment:
                comment, displayComment = "\n * Process 'timeout' set to {0} minute(s)...".format( processTimeout), False
            processTimeout = 60.0 * processTimeout    # Convert to seconds as float
        else:
            comment =  "\n * Invalid 'timeout' specified, {0} minute default used!".format( defaultTimeout)
            processTimeout = 60.0 * defaultTimeout
        #

        for pathName in [ 'workPath', 'logPath', 'livePath']:
            try:
                if not os.access( globals()[ pathName], os.F_OK):
                    os.makedirs( globals()[ pathName])
            except:
                _logError( " * Unable to access or create '{0}' *".format( pathName))
                raise

    # Import ALFlib
    if "ALFlib" not in globals():
        global ALFlib

        if root and root not in sys.path:
            sys.path.insert( 0, root)

        if importPath:
            importPath = os.path.realpath( importPath)
            if importPath not in sys.path:
                if os.access( importPath, os.F_OK):
                    sys.path.insert( 0, importPath)
                else:
                    raise Exception( "Invalid 'importPath', please correct! *")

        try:
            import ALFlib
        except Exception as e:
            raise Exception( "Unable to locate 'ALFlib.py' in Import Path *")

    # Verify ALFlib version required by this script
    if not (hasattr( ALFlib, "minVersion") and eval( "ALFlib.minVersion( {0})".format( _minALFlib.replace(".", ",")))):
        del ALFlib
        raise Exception( "Found incompatible version of 'ALFlib.py' script, '{0}' requires at least v{1} *".format( scriptName, _minALFlib))

    # Verify ALFlib version required by configuration file
    if hasattr( ConfigFile, "minALFlib") and ConfigFile.minALFlib:
        if not eval( "ALFlib.minVersion( {0})".format( str( ConfigFile.minALFlib).replace(".", ","))):
            del ALFlib
            raise Exception( "Found incompatible version of 'ALFlib.py' script, '{0}' requires at least v{1} *".format( configName, ConfigFile.minALFlib))

    # Verify ALFprocessor version required by configuration file
    if hasattr( ConfigFile, "minALFprocessor") and ConfigFile.minALFprocessor:
        if not eval( "minVersion( {0})".format( str( ConfigFile.minALFprocessor).replace(".", ","))):
            del ALFlib
            raise Exception( "Version of 'ALFprocessor.py' is NOT compatible with configuration script, '{0}' requires at least v{1} *".format( configName, ConfigFile.minALFprocessor))

    # Alter ALFlib Logger to work with ALFprocessor
    if "__main__" not in str( ALFlib.Logger):
        class Logger( ALFlib.Logger):
            # Update Pool creation to handle ALFprocessor specific environment
            def createWorkerPool( self, initFunction="", args=(), description="", processCount=0):
                if type( initFunction).__name__ == 'instancemethod':
                    initFunction = initFunction.__name__

                return super( Logger, self).createWorkerPool( _initWorkerPool, [ configFilename, initFunction, args], processCount=processCount, description=description)

        # Apply Logger class updates
        ALFlib.Logger = Logger

    if "ALFlog" not in globals():
        global ALFlog

        # Setup Logging
        ALFlog = ALFlib.Logger( nickName, logPath, logRetention, singleton=True)
        ALFlog.exitReturnError = (not syncInterval)

        # Turn off Timestamp
        if hasattr( ALFlog, "timestamp"):
            ALFlog.showTimestamp = False

        # Import Arcpy
        if "arcpy" not in globals() and hasattr( ConfigFile, "minArcpy"):
            if ConfigFile.minArcpy and not (hasattr( ConfigFile, "delayArcpyLoad") and ConfigFile.delayArcpyLoad):
                importArcpy( ConfigFile.minArcpy)
            else:
                ALFlog.log( " * Skipping 'arcpy' import...\n")

        if hasattr( ConfigFile, "version"):
            ALFlog.log( "Configuration: {0}, v{1}".format( configName, ConfigFile.version))

        if "_version" in globals():
            ALFlog.log( "    Processor: {0}, v{1}".format( scriptName, _version))

        ALFlog.log( "      Library: ALFlib.py, v{0}.{1}.{2}".format( ALFlib.major, ALFlib.minor, ALFlib.bug))
        ALFlog.log( "       Python: {0}, v{1}".format( platform.python_compiler(), platform.python_version()))
        ALFlog.log( "     Platform: {0} {1}, v{2}".format( platform.system(), platform.release(), platform.version()))
        ALFlog.log( "   Process ID: {0}".format( multiprocessing.current_process().pid))

        # v1.2.0
        if comment:
            if displayComment:
                print( comment)
            else:
                ALFlog.log( comment)

        # v1.2.0, Set/override Logger E-mail options if any found in ConfigFile
        # v1.2.1, Patched 'setMailOption' call to use split method instead of strip
        ALFlog.log( "\nChecking ConfigFile for available E-mail options:")
        optionsFound = False
        for key in dir( ConfigFile):
            value = getattr(ConfigFile, key)
            key = key.lower()
            if key.startswith( "alfmail_"):
                if ALFlog.setMailOption( key.split( "_")[-1], value):
                    optionsFound = True

        if optionsFound:
            ALFlog.log( "\n * NOTICE * Support for setting e-mail options within Configuration file will")
            ALFlog.log( "            be deprecated at ALFprocessor.py v2.0.0. Please use 'ALFlib_env.py'!\n")
        else:
            ALFlog.log( " * No valid 'ALFmail_' variables found...")

        # Turn on Timestamp
        if hasattr( ALFlog, "timestamp"):
            ALFlog.showTimestamp = True

    # Alter ALFlib Pool to work with ALFprocessor
    if "__main__" not in str( ALFlib._Pool):
        class _Pool( ALFlib._Pool):
            def apply_async(self, func, args=(), kwds={}, callback=None):
                if type( func).__name__ == 'instancemethod':
                    func = func.__name__

                if type( callback).__name__ == 'instancemethod':
                    callback = callback.__name__

                if not kwds:
                    # Make sure it's a Dictionary!
                    kwds = {}

                if not isinstance( kwds, dict):
                    raise Exception( "Invalid Keywords (kwds) argument: Not a Dictionary")

                return super( _Pool, self).apply_async( _asyncFunction, [func, callback, args, kwds], callback=_callbackFunction)

        # Apply _Pool class updates
        ALFlib._Pool = _Pool

#########################
# Multiprocessing logic #
#########################

def _asyncFunction( functionName, callbackName, args, kwds):
    """Internal function, not intended for general consumption!"""
    if hasattr( ConfigFile, functionName):
        function = getattr( ConfigFile, functionName)
        if callable( function):
            if "ALFlog" in globals():
                ALFlog.showTimestamp = False

            print( "\nCalling function: '{0}'...".format( functionName))

            if "ALFlog" in globals():
                ALFlog.showTimestamp = True

            try:
                result = function( *args, **kwds)

            except Exception as e:
                _logArcpyMessages()
                raise
        else:
            raise Exception( "User-Defined WORKER function '{0}' is NOT callable".format( functionName))
    else:
        raise Exception( "Unable to locate User-Defined WORKER function '{0}'".format( functionName))

    return callbackName, result

def _callbackFunction( functionName, args):
    """Internal function, not intended for general consumption!"""
    if functionName:
        if hasattr( ConfigFile, functionName):
            function = getattr( ConfigFile, functionName)
            if callable( function):
                try:
                    function( *args)

                except Exception as e:
                    _logArcpyMessages()
                    raise
            else:
                raise Exception( "User-Defined CALLBACK function '{0}' is NOT callable".format( functionName))
        else:
            raise Exception( "Unable to locate User-Defined CALLBACK function '{0}'".format( functionName))

def _initWorkerPool( filename, functionName, args):
    """Internal function, not intended for general consumption!"""

    global ALFlog, configFilename, configName, errLogFilename, home

    configFilename = filename
    home, configName = os.path.split( configFilename)
    errLogFilename = os.path.join( home, configName.split( ".")[0] + ".err")

    cwd = os.getcwd()

    if home:
        os.chdir( home)

    # Init ALFlog, so that setupEnvironment will not attempt to create it first!
    if "ALFlog" not in globals():
        ALFlog = getattr( sys.stdout, "loggerObject", "")

    # Turn off Timestamp
    ALFlog.showTimestamp = False

    print( "\nLoading environment...")
    _setupEnvironment()

    # Set dummy ALFlog if not already exists
    if not ALFlog:
        ALFlog = ALFlib.dummyLogger()

    if cwd:
        # Set working directory
        os.chdir( cwd)

    # Launch user defined function if specified!
    if functionName:
        if hasattr( ConfigFile, functionName):
            function = getattr( ConfigFile, functionName)
            if callable( function):
                print( "\nCalling initializer function: '{0}'".format( functionName))
                # Turn on Timestamp
                ALFlog.showTimestamp = True

                try:
                    function( *args)
                except:
                    _logArcpyMessages()
                    raise
            else:
                raise Exception( "User-Defined initializer function '{0}' is NOT callable".format( functionName))
        else:
            raise Exception( "Unable to locate User-Defined initializer function '{0}'".format( functionName))

def _logArcpyMessages():
    """Internal function, not intended for general consumption!"""
    try:
        # Report existing Arcpy Messages, ignore otherwise
        if "arcpy" in globals() and arcpy.GetMessageCount() and arcpy.GetMaxSeverity() == 2:
            sys.stderr.write( "\nLast arcpy messages:")
            sys.stderr.write( "\n-------------\n")
            sys.stderr.write( arcpy.GetMessages())
            sys.stderr.write( "\n-------------\n")
    except Exception as e:
        print( " * Ignored 'logArcpyMessages' issue: {0}".format( e))

def retryIt( function, args=(), attempts=3, pause=2, cancelRetry=[], logSuccess=True, kwargs={}):
    """Retry call to Function or Method if an Exception is thrown.

    Calls ALFlib.retryIt, setting 'retryHook' to record any arcpy messages!

    Returns:
        Outcome of function being called.
        Or original Exception is raised if try <attempts> is exceeded or
        <cancelRetry> text is detected in Exception.

    Where:
        <function> = Function or Method to call.

            <args> = (optional) List of arguments to pass to <function>.
                     Depends on requirements of <function>.
                     Default is None, nothing is passed in.

        <attempts> = (optional) Number of call attempts to make.

           <pause> = (optional) Number of seconds to pause between attempts.

     <cancelRetry> = (optional) Cancel retry if <cancelRetry> text or if any item
                      in List of text entries are detected in Exception text.

      <logSuccess> = (optional) True or False, Log successful retry to Archive Log

          <kwargs> = (optional) Dictionary containing Keyword Arguments and
                     values for <function>. Can be used with <args>.
"""
    def incCount( exception):
        setattr( incCount, "retries", getattr( incCount, "retries") + 1)
        _logArcpyMessages()

        for item in getattr( incCount, "cancelRetry"):
            if isinstance( item, basestring) and item and item in str( exception):
                return item

    incCount.retries = 0
    incCount.cancelRetry = cancelRetry if isinstance( cancelRetry, list) else [cancelRetry] if cancelRetry else []

    result = ALFlib.retryIt( function, args=args, attempts=attempts, pause=pause, retryHook=incCount, kwargs=kwargs)

    if incCount.retries and logSuccess:
        ALFlog.archive( "* Call to '{0}.{1}' succeeded on Retry {2} *".format( function.__module__, function.__name__, incCount.retries))

    return result

def _timeoutTrigger():
    """Internal function, not intended for general consumption!"""
    print( "\n\n * Execution time exceeded specified 'timeout' value!")
    print( "\n * Forceful shutdown initiated at: {0}\n".format( datetime.datetime.now()))

    try:
        if "ALFlog" in globals():
            ALFlog.setError( "'TimeoutError' - Execution time exceeded 'timeout' specification!")
            ALFlog.close()
    finally:
        os._exit(3)

def _enabled():
    """Check environment variable 'ALFprocessor_Enabled' to see if process is allowed to run."""
    enabled = str( os.environ.get( "ALFprocessor_Enabled", "True").lower().strip())

    if enabled == "false":
        print( "")
        ALFlog.archive( "* 'ALFprocessor_Enabled' is disabled, terminating run...", True)
        return False

    # Check for ISO date/time string 'YYYY/MM/DD HH:mm:ss.ms'
    elif enabled and enabled != "true":
        dt = eval( str( datetime.date.today().isoformat().split("-")).replace( "'", ""))    # Default day to today as [Y, M, D] list
        tm = []                                                # Default time to nothing
        ms = []                                             # Default microseconds to nothing

        for value in enabled.split():
            # Check for ISO Date
            if "-" in value:
                # Create integer list of values for Date
                dt = eval( str( value.split( "-")).replace( "'", ""))

            # Check for ISO Time
            elif ":" in value:
                # Check for microseconds in ISO Time
                for part in value.split( "."):
                    if ":" in part:
                        # Create integer list of values for Time
                        tm = eval( str( part.split( ":")).replace( "'", ""))
                    elif part.isdigit():
                        # Create list containing long value for Microseconds
                        ms = [long( part)]

        try:
            enableDate = datetime.datetime( * dt + tm + ms)
            ALFlog.log( "\nALFprocessor_Enabled date: {0}".format( enableDate))

            if datetime.datetime.now() < enableDate:
                print( "")
                ALFlog.archive( "* 'ALFprocessor_Enabled' time not reached, terminating run...", True)
                return False

        except Exception as e:
            print( "")
            ALFlog.archive( "* Unable to resolve 'ALFprocessor_Enabled = {0}', defaulting to Enabled: {1}".format( enabled, e), True)

    # Default to True
    return True

def _handleHeartbeat( lastError):
    """Check, generate, and distribute Heartbeat file if desired."""
    import json

    destination = os.environ.get( "ALFprocessor_HeartbeatPath", "").strip()
    if not destination:
        # Do NOT create Heartbeat file
        return

    msg = ""
    if lastError:
        # Do NOT create Heartbeat file if error condition present
        msg = " * Skipping Heartbeat, run encountered an error!"
    else:
        # Check for S3 destination bucket
        if destination.upper().startswith( "S3:") and destination[-1] not in [ "/", "\\"]:
            destination += "/"

        config = configName.split( ".")[0]
        nickName = getattr( ConfigFile, "nickName", config)
        fileFormat = os.environ.get( "ALFprocessor_HeartbeatFormat", "").lower().strip()
        filename = os.environ.get( "ALFprocessor_HeartbeatFilename", "{0}_LastUpdate".format( config)).strip()

        if not fileFormat:
            if "." in filename:
                # Set file format based on filename
                fileFormat = filename.split( ".")[-1].lower()
            else:
                # Use default file format
                print( " * No file format specified, defaulting to 'txt'!")
                fileFormat = "txt"

        if fileFormat not in ["txt", "csv", "json", "html"]:
            # Set default file format if not acceptable
            print( " * Invalid Heartbeat file format, defaulting to 'txt'!")
            fileFormat = "txt"

        if "." not in filename:
            # Set filename extension if missing
            filename = ".".join( [ filename, fileFormat])

        hostname = ALFlib.getNetworkDetails( verbose=False).get( "localName", "* Unknown *")
        completionTime = datetime.datetime.utcnow()
        timedelta = completionTime - datetime.datetime( 1970, 1, 1)
        timestamp = timedelta.seconds + timedelta.days * 24 * 3600        # in seconds since epoch
        runtime = str( completionTime).split( ".")[0]

        try:
            with open( filename, "wb") as oFP:
                if fileFormat == "json":
                    output = {
                        "UTCdatetime": runtime,
                        "UTCtimestamp": timestamp,
                        "Hostname": hostname,
                        "Routine": nickName
                    }
                    json.dump( output, oFP, indent=3, separators=(",", ": "))

                elif fileFormat == "txt":
                    oFP.write( "Routine: '{0}' completed at: {1} UTC from host: {2}\n".format( nickName, runtime, hostname))
                elif fileFormat == "csv":
                    oFP.write( "Routine, UTCdatetime, UTCtimestamp, Hostname\n")
                    oFP.write( '"{0}", "{1}", {2}, "{3}"\n'.format( nickName, runtime, timestamp, hostname))
                elif fileFormat == "html":
                    oFP.write(
                        """<!DOCTYPE html>
<html>
<head><title>Heartbeat file for routine '{0}'</title></head>
<body><p>
 <b>UTCdatetime:</b> {1}<br>
<b>UTCtimestamp:</b> {2}<br>
    <b>Hostname:</b> '{3}'
</p></body>
</html>""".format( nickName, runtime, timestamp, hostname)
                    )
        except Exception as e:
            msg = "* Failed to generate Heartbeat file, error: {0}".format( e)

        if not msg:
            fileIn = os.path.realpath( filename)
            fileOut = os.path.realpath( os.path.join( destination, filename))
            try:
                if not fileIn == fileOut:
                    # Distribute Heartbeat file
                    ConfigFile.distribute( filename, destination, reducedRedundancy=True, makePublic=True, category="heartbeat")
                    os.remove( filename)
                else:
                    msg = "* Heartbeat distribution ignored, source and destination are the same *"

            except Exception as e:
                msg = "* Failed to distribute Heartbeat file, error: {0}".format( e)

    if msg:
        print( "")
        if "ALFlog" in globals():
            ALFlog.archive( msg, True)
        else:
            print( msg)

##############
# Main logic #
##############

if __name__ == "__main__":

    # Save critical environment details
    startingLocation = os.getcwd()
    origStdout = sys.stdout
    origStderr = sys.stderr

    try:
        # Get initial Arguments, exit if incorrect or not included
        validCriteria, outcome = _getArgs()
        if not validCriteria:
            exit( outcome)

        syncInterval = 0.0

        while True:
            startCycle = datetime.datetime.now()

            totErrors = 0
            errorText = ""

            # Navigate back to config file home location as root starting point
            os.chdir( home)

            try:
                _setupEnvironment()

                if _enabled():   # Added v1.5.2
                    if hasattr( ConfigFile, "main") and callable( ConfigFile.main):
                        os.chdir( workPath)

                        if processTimeout:
                            # Enable Timeout timer
                            timeoutThread = threading.Timer( processTimeout, _timeoutTrigger)
                            timeoutThread.daemon = True
                            timeoutThread.start()

                        outcome = ConfigFile.main()
                        if isinstance( outcome, bool):
                            # v1.7.0, set keepActivity flag based on outcome of Config run
                            ALFlog.keepActivity = outcome
                        elif outcome:
                            # or setFlag if something other than boolean or None and turn off activity flag
                            ALFlog.setFlag( outcome)
                            ALFlog.keepActivity = False
                    else:
                        raise Exception( "Unable to locate 'main' function within configuration file!")

            except KeyboardInterrupt:
                raise

            except Flag as e:
                if "ALFlog" in globals():
                    ALFlog.setFlag( e)
                    ALFlog.keepActivity = False
                else:
                    print( " * Unable to set Caution Flag to '{0}': Log not available!".format( e))

            except Exception as e:
                if "ALFlog" in globals() and hasattr( ALFlog, "timestamp") and ALFlog.timestamp:
                    # Turn off logging timestamp
                    ALFlog.timestamp = ""

                errorText = Exception( str( e).strip())
                _logArcpyMessages() # Report any remaining ArcPy Error Messages that may still exist
                _logError( " * Encountered exception: '{0}'".format( errorText), False)
                print( "")
                traceback.print_exc()
                if "ALFlog" in globals():
                    ALFlog.setError( errorText)
                else:
                    totErrors += 1

            finally:
                arcpyErrors = []
                if "arcpy" in globals():
                    if syncInterval:
                        arcpy.env.workspace = "in_memory"
                        for item in arcpy.ListDatasets() + arcpy.ListFeatureClasses() + arcpy.ListTables():
                            try:
                                arcpy.Delete_management( "in_memory/" + item)
                            except Exception as e:
                                arcpyErrors.append( [item, e])
                    del arcpy

                if "ConfigFile" in globals():
                    _handleHeartbeat( errorText)
                    del ConfigFile

                try:
                    # Release Timer
                    if processTimeout:
                        # Disable Timeout timer
                        timeoutThread.cancel()
                except:
                    pass

                if "ALFlog" in globals():
                    if arcpyErrors:
                        ALFlog.log( "\n * Unable to clear 'in_memory' item(s):")
                        for item, err in arcpyErrors:
                            ALFlog.log( "   '{0}', error: {1}".format( item, err))

                    if ALFlog.getError():
                        totErrors += 1
                    elif totErrors:
                        ALFlog.setError( totErrors)

                    ALFlog.close()
                    del ALFlog

                if "ALFlib" in globals():
                    del ALFlib

                if totErrors:
                    print( "\nCompleted with errors, see log for details!\n")
                else:
                    print( "\nDone...\n")

                if syncInterval:
                    try:
                        # Restore critical environment details for next cycle
                        os.chdir( startingLocation)
                        sys.stdout = origStdout
                        sys.stderr = origStderr

                        _waitInterval( startCycle, syncInterval)

                    except Exception as e:
                        print( " * Received Exception during wait cycle: '{0}'".format( e))
                else:
                    break

    except KeyboardInterrupt:
        if "ALFlog" not in globals():
            _logError( " * User-interrupted via <ctrl-break> *", False)
        else:
            ALFlog.setError( " * User-interrupted via <ctrl-break>")
            ALFlog.exitReturnError = False
            ALFlog.close()
            sys.exit(1)

        sys.exit( " * User-interrupted via <ctrl-break> *")

    finally:
        # Restore critical environment details
        os.chdir( startingLocation)
        sys.stdout = origStdout
        sys.stderr = origStderr
